import React, { createContext, useContext, useState, useEffect } from 'react';
import { getFreshiozStore } from '../shared/freshiozStore';

const AdminRoleContext = createContext(null);

export const ROLES = {
  SUPER_ADMIN: {
    id: 'SUPER_ADMIN',
    label: 'Super Admin',
    desc: 'Master Operations, Graphs, Approvals & Pricing',
    defaultRoute: '/dashboard'
  },
  SALES_OFFICER: {
    id: 'SALES_OFFICER',
    label: 'Field Sales Officer',
    desc: 'Society Onboarding, GPS Tagging & Nearest Store',
    defaultRoute: '/sales-onboarding'
  },
  PROCUREMENT_OFFICER: {
    id: 'PROCUREMENT_OFFICER',
    label: 'Procurement Officer',
    desc: 'Mandi Demand List, Vendor Bills & Purchase Logging',
    defaultRoute: '/procurement-demand'
  },
  WAREHOUSE_MANAGER: {
    id: 'WAREHOUSE_MANAGER',
    label: 'Warehouse & Shop Hub Manager',
    desc: 'Cut-off Timings, Delivery Slots & Hub Crating',
    defaultRoute: '/warehouse-settings'
  },
  STORE_MANAGER: {
    id: 'STORE_MANAGER',
    label: 'Store & Hub Manager',
    desc: 'Micro-fulfillment Hub, Crating & Local Store Orders',
    defaultRoute: '/orders-fulfillment'
  },
  DELIVERY_EXECUTIVE: {
    id: 'DELIVERY_EXECUTIVE',
    label: 'Delivery Executive (Rider)',
    desc: 'Morning Society Drop Desk Route Manifest & Dispatch',
    defaultRoute: '/orders-fulfillment'
  }
};

const DEMO_USERS = {
  SUPER_ADMIN: {
    id: 'emp-101',
    name: 'Vikramaditya Rao',
    email: 'vikram.rao@freshioz.com',
    phone: '9845011000',
    role: 'SUPER_ADMIN',
    avatar: 'VR'
  },
  WAREHOUSE_MANAGER: {
    id: 'emp-102',
    name: 'Rajesh Nayak',
    email: 'rajesh.ops@freshioz.com',
    phone: '9845022334',
    role: 'WAREHOUSE_MANAGER',
    avatar: 'RN'
  },
  SALES_OFFICER: {
    id: 'emp-103',
    name: 'Sneha Sharma',
    email: 'sneha.sales@freshioz.com',
    phone: '9845033445',
    role: 'SALES_OFFICER',
    avatar: 'SS'
  },
  PROCUREMENT_OFFICER: {
    id: 'emp-104',
    name: 'Mohan Gowda',
    email: 'mohan.mandi@freshioz.com',
    phone: '9845044556',
    role: 'PROCUREMENT_OFFICER',
    avatar: 'MG'
  },
  STORE_MANAGER: {
    id: 'emp-201',
    name: 'Arun Kumar',
    email: 'arun.indiranagar@freshioz.com',
    phone: '9845011201',
    role: 'STORE_MANAGER',
    avatar: 'AK',
    assignedLocationName: 'Indiranagar Fresh Hub (Shop 1)'
  },
  DELIVERY_EXECUTIVE: {
    id: 'emp-202',
    name: 'Raju M',
    email: 'raju.delivery@freshioz.com',
    phone: '9845044201',
    role: 'DELIVERY_EXECUTIVE',
    avatar: 'RM',
    assignedLocationName: 'Indiranagar Morning Route A'
  }
};

export function AdminRoleProvider({ children }) {
  const [store, setStore] = useState(() => getFreshiozStore());

  useEffect(() => {
    const handleSync = (e) => setStore(e.detail || getFreshiozStore());
    window.addEventListener('freshioz_store_updated', handleSync);
    window.addEventListener('storage', () => setStore(getFreshiozStore()));
    return () => window.removeEventListener('freshioz_store_updated', handleSync);
  }, []);

  const [currentRoleId, setCurrentRoleId] = useState(() => {
    return localStorage.getItem('freshioz_admin_role') || 'SUPER_ADMIN';
  });

  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    const storedAuth = localStorage.getItem('freshioz_admin_auth');
    // Default to true so existing workflow is uninterrupted, but supports explicit logout
    return storedAuth === null ? true : storedAuth === 'true';
  });

  const [currentUser, setCurrentUser] = useState(() => {
    try {
      const stored = localStorage.getItem('freshioz_admin_user');
      if (stored) return JSON.parse(stored);
    } catch (e) {
      // ignore
    }
    return DEMO_USERS[currentRoleId] || DEMO_USERS.SUPER_ADMIN;
  });

  const setRole = (roleId) => {
    setCurrentRoleId(roleId);
    localStorage.setItem('freshioz_admin_role', roleId);
    const newUser = DEMO_USERS[roleId] || DEMO_USERS.SUPER_ADMIN;
    setCurrentUser(newUser);
    localStorage.setItem('freshioz_admin_user', JSON.stringify(newUser));
  };

  const login = (emailOrPhone, password, roleId = 'SUPER_ADMIN') => {
    const chosenRole = roleId || currentRoleId;
    const user = DEMO_USERS[chosenRole] || {
      id: `emp-custom-${Date.now()}`,
      name: emailOrPhone.split('@')[0] || 'Operations Lead',
      email: emailOrPhone,
      phone: '9845000000',
      role: chosenRole,
      avatar: (emailOrPhone[0] || 'A').toUpperCase()
    };

    setCurrentRoleId(chosenRole);
    setCurrentUser(user);
    setIsAuthenticated(true);
    localStorage.setItem('freshioz_admin_role', chosenRole);
    localStorage.setItem('freshioz_admin_user', JSON.stringify(user));
    localStorage.setItem('freshioz_admin_auth', 'true');
    return user;
  };

  const logout = () => {
    setIsAuthenticated(false);
    localStorage.setItem('freshioz_admin_auth', 'false');
  };

  const forgotPassword = (emailOrPhone) => {
    // Simulated token generation for backend implementation
    return {
      success: true,
      resetToken: `rst_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      recipient: emailOrPhone
    };
  };

  const currentRole = ROLES[currentRoleId] || ROLES.SUPER_ADMIN;

  return (
    <AdminRoleContext.Provider
      value={{
        store,
        currentRole,
        currentRoleId,
        setRole,
        isAuthenticated,
        currentUser,
        login,
        logout,
        forgotPassword,
        isAdmin: currentRoleId === 'SUPER_ADMIN',
        isSales: currentRoleId === 'SALES_OFFICER',
        isProcurement: currentRoleId === 'PROCUREMENT_OFFICER',
        isWarehouse: currentRoleId === 'WAREHOUSE_MANAGER'
      }}
    >
      {children}
    </AdminRoleContext.Provider>
  );
}

export function useAdminRole() {
  const ctx = useContext(AdminRoleContext);
  if (!ctx) throw new Error('useAdminRole must be used within AdminRoleProvider');
  return ctx;
}
