import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Warehouse, 
  Store, 
  Clock, 
  Plus, 
  Edit3, 
  Eye, 
  Download, 
  CheckCircle2, 
  X, 
  Phone, 
  Users, 
  Building2,
  ArrowRight
} from 'lucide-react';
import { useAdminRole } from '../context/AdminRoleContext';
import { saveFreshiozStore } from '../shared/freshiozStore';
import { useToast } from '../context/ToastContext';
import { exportToExcel } from '../utils/excelExporter';

export default function WarehouseShopsPage() {
  const { store } = useAdminRole();
  const { showToast } = useToast();
  const warehouses = store.warehouses || [];
  const shops = store.shops || [];

  // Modals state
  const [isWarehouseModalOpen, setIsWarehouseModalOpen] = useState(false);
  const [editingWarehouse, setEditingWarehouse] = useState(null);

  // Warehouse Form State (Cold Storage Temp REMOVED as requested)
  const [warehouseForm, setWarehouseForm] = useState({
    code: '',
    name: '',
    location: '',
    openTime: '05:00',
    cutoffTime: '21:00',
    capacityTons: 40,
    managerName: '',
    managerPhone: '',
    status: 'ACTIVE'
  });

  // ================= EXCEL EXPORT =================
  const handleExportExcel = () => {
    const headers = [
      'Warehouse Code',
      'Warehouse Name',
      'Warehouse Location',
      'Daily Cutoff Time',
      'Morning Dispatch',
      'Capacity (Tons)',
      'Warehouse Manager',
      'Manager Phone',
      'Linked Stores Count',
      'Assigned Store People',
      'Warehouse Status'
    ];

    const rows = warehouses.map(wh => {
      const whShops = shops.filter(s => s.warehouseId === wh.id);
      const whStaffCount = whShops.reduce((acc, s) => acc + (s.staff?.length || 2), 0);

      return [
        wh.code || wh.id,
        wh.name,
        wh.location,
        wh.cutoffTime || '21:00',
        wh.openTime || '05:00',
        wh.capacityTons || 35,
        wh.managerName || 'Operations Lead',
        wh.managerPhone || '+91 98450 11223',
        whShops.length,
        whStaffCount,
        wh.status || 'ACTIVE'
      ];
    });

    exportToExcel('Freshioz_Warehouses_Directory', headers, rows);
  };

  // ================= WAREHOUSE MODAL HANDLERS =================
  const handleOpenAddWarehouse = () => {
    setEditingWarehouse(null);
    setWarehouseForm({
      code: `WH-BLR-0${warehouses.length + 1}`,
      name: '',
      location: '',
      openTime: '05:00',
      cutoffTime: '21:00',
      capacityTons: 40,
      managerName: '',
      managerPhone: '',
      status: 'ACTIVE'
    });
    setIsWarehouseModalOpen(true);
  };

  const handleOpenEditWarehouse = (wh) => {
    setEditingWarehouse(wh);
    setWarehouseForm({
      code: wh.code || wh.id,
      name: wh.name,
      location: wh.location,
      openTime: wh.openTime || '05:00',
      cutoffTime: wh.cutoffTime || '21:00',
      capacityTons: wh.capacityTons || 40,
      managerName: wh.managerName || '',
      managerPhone: wh.managerPhone || '',
      status: wh.status || 'ACTIVE'
    });
    setIsWarehouseModalOpen(true);
  };

  const handleSaveWarehouse = (e) => {
    e.preventDefault();
    if (!warehouseForm.name.trim() || !warehouseForm.location.trim()) {
      alert('Please provide warehouse name and location address.');
      return;
    }

    if (editingWarehouse) {
      saveFreshiozStore(prev => ({
        ...prev,
        warehouses: prev.warehouses.map(w => w.id === editingWarehouse.id ? {
          ...w,
          ...warehouseForm
        } : w)
      }));
      showToast(`✓ Warehouse "${warehouseForm.name}" updated successfully.`);
    } else {
      const newWhId = `wh-${Date.now().toString().slice(-4)}`;
      const newWh = {
        id: newWhId,
        ...warehouseForm,
        slots: [
          { id: 'slot-morning', label: 'Morning Fresh Slot', timeWindow: '06:30 AM - 08:30 AM', desc: 'Direct to Society Drop Desk' },
          { id: 'slot-evening', label: 'Evening Fresh Slot', timeWindow: '05:00 PM - 07:30 PM', desc: 'Evening Return Drop' }
        ]
      };
      saveFreshiozStore(prev => ({
        ...prev,
        warehouses: [...(prev.warehouses || []), newWh]
      }));
      showToast(`✓ New Warehouse "${warehouseForm.name}" registered.`);
    }

    setIsWarehouseModalOpen(false);
  };

  return (
    <div className="admin-page-container" style={{ overflowX: 'hidden' }}>
      {/* High-Density Compact Page Header (Under 55px) */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '8px',
        paddingBottom: '10px',
        borderBottom: '1.5px solid #E2E8F0',
        marginBottom: '12px'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
            <h1 style={{ fontSize: '18px', color: '#0F172A', fontWeight: 800, margin: 0 }}>
              Warehouses Directory
            </h1>
            <span style={{ background: '#E0F2FE', color: '#0369A1', fontSize: '11px', fontWeight: 800, padding: '2px 8px', borderRadius: '4px' }}>
              {warehouses.length} Active Hubs
            </span>
          </div>

          {/* Compact Inline Stats Strip (Replaced 4 bulky cards!) */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '11.5px', color: '#64748B', marginTop: '3px', flexWrap: 'wrap' }}>
            <span>• <strong>{shops.length}</strong> Connected Stores</span>
            <span>• <strong>{shops.reduce((acc, s) => acc + (s.staff?.length || 2), 0)}</strong> Store Personnel</span>
            <span>• Daily Handling: <strong style={{ color: '#059669' }}>{warehouses.reduce((acc, w) => acc + (w.capacityTons || 35), 0)} Tons</strong></span>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <button
            type="button"
            onClick={handleExportExcel}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '5px',
              padding: '6px 12px',
              borderRadius: '6px',
              background: '#FFFFFF',
              border: '1.5px solid #CBD5E1',
              color: '#334155',
              fontWeight: 700,
              fontSize: '12px',
              cursor: 'pointer'
            }}
          >
            <Download size={13} />
            <span>Export Excel</span>
          </button>

          <button
            type="button"
            onClick={handleOpenAddWarehouse}
            className="admin-btn-accent"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', padding: '6px 14px', fontSize: '12px' }}
          >
            <Plus size={14} />
            <span>Add Warehouse</span>
          </button>
        </div>
      </div>

      {/* ================= PRIMARY WAREHOUSES TABLE ================= */}
      <div className="admin-table-card">
        <div className="admin-table-header">
          <div>
            <h3 style={{ fontSize: '15px', fontWeight: 800, color: '#0F172A', display: 'flex', alignItems: 'center', gap: '8px', margin: 0 }}>
              <Warehouse size={18} color="#234B3C" />
              <span>Primary Warehouses Directory ({warehouses.length})</span>
            </h3>
            <p style={{ fontSize: '12px', color: '#64748B', marginTop: '2px' }}>
              Click <strong>View Stores &rarr;</strong> on any warehouse below to navigate to its dedicated stores and store staff management desk.
            </p>
          </div>

          <div style={{ fontSize: '12px', color: '#0369A1', fontWeight: 700, background: '#E0F2FE', padding: '4px 10px', borderRadius: '6px' }}>
            {warehouses.length} Active Hubs
          </div>
        </div>

        <div style={{ overflowX: 'auto', width: '100%' }}>
          <table className="admin-data-table" style={{ width: '100%', minWidth: '760px' }}>
            <thead>
              <tr>
                <th>Warehouse Code & Name</th>
                <th>Physical Location</th>
                <th>Cut-off Time</th>
                <th>Morning Open</th>
                <th>Capacity</th>
                <th>Connected Stores</th>
                <th>Lead In-Charge</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {warehouses.map(wh => {
                const whShops = shops.filter(s => s.warehouseId === wh.id);
                const whShopCount = whShops.length;
                const whStaffCount = whShops.reduce((acc, s) => acc + (s.staff?.length || 2), 0);

                return (
                  <tr key={wh.id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <div style={{
                          width: '36px',
                          height: '36px',
                          borderRadius: '8px',
                          background: '#234B3C',
                          color: '#FFFFFF',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontWeight: 800,
                          fontSize: '12px',
                          flexShrink: 0
                        }}>
                          {wh.code?.slice(-2) || 'WH'}
                        </div>
                        <div>
                          <strong style={{ fontSize: '13.5px', color: '#0F172A' }}>{wh.name}</strong>
                          <div style={{ fontSize: '11px', color: '#64748B' }}>
                            Code: <span style={{ fontWeight: 700 }}>{wh.code || wh.id}</span>
                          </div>
                        </div>
                      </div>
                    </td>

                    <td>
                      <div style={{ fontSize: '12px', color: '#334155', maxWidth: '240px' }}>
                        {wh.location}
                      </div>
                    </td>

                    <td>
                      <div style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', background: '#FEF3C7', color: '#B45309', padding: '2px 7px', borderRadius: '5px', fontSize: '11.5px', fontWeight: 700 }}>
                        <Clock size={11} />
                        <span>{wh.cutoffTime || '21:00'}</span>
                      </div>
                    </td>

                    <td>
                      <div style={{ fontSize: '12px', color: '#475569', fontWeight: 600 }}>
                        {wh.openTime || '05:00'} AM
                      </div>
                    </td>

                    <td>
                      <div style={{ fontSize: '12px', color: '#0F172A', fontWeight: 700 }}>
                        {wh.capacityTons || 35} Tons
                      </div>
                    </td>

                    <td>
                      <Link
                        to={`/warehouse/${wh.id}/stores`}
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '6px',
                          background: whShopCount > 0 ? '#E0F2FE' : '#F1F5F9',
                          color: whShopCount > 0 ? '#0369A1' : '#64748B',
                          padding: '4px 9px',
                          borderRadius: '6px',
                          fontSize: '12px',
                          fontWeight: 800,
                          textDecoration: 'none'
                        }}
                        title="Click to view linked stores and store people"
                      >
                        <Store size={13} />
                        <span>{whShopCount} Stores</span>
                        <span style={{ fontSize: '10.5px', color: '#64748B', fontWeight: 600 }}>({whStaffCount} Staff)</span>
                      </Link>
                    </td>

                    <td>
                      <div style={{ fontSize: '12.5px', color: '#0F172A', fontWeight: 700 }}>
                        {wh.managerName || 'Operations Lead'}
                      </div>
                      <div style={{ fontSize: '11px', color: '#64748B' }}>
                        {wh.managerPhone || '+91 98450 11223'}
                      </div>
                    </td>

                    <td>
                      <span className={`status-pill ${wh.status === 'ACTIVE' ? 'approved' : 'rejected'}`}>
                        {wh.status || 'ACTIVE'}
                      </span>
                    </td>

                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                        {/* Dedicated Page Navigation Link (As requested by user: relevant data shown in new page) */}
                        <Link
                          to={`/warehouse/${wh.id}/stores`}
                          style={{
                            background: '#234B3C',
                            color: '#FFFFFF',
                            padding: '6px 12px',
                            borderRadius: '6px',
                            fontSize: '12px',
                            fontWeight: 800,
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '5px',
                            textDecoration: 'none',
                            transition: 'opacity 0.2s'
                          }}
                          title={`Open stores and store people for ${wh.name}`}
                        >
                          <Eye size={13} />
                          <span>View Stores</span>
                          <ArrowRight size={13} />
                        </Link>

                        <button
                          type="button"
                          onClick={() => handleOpenEditWarehouse(wh)}
                          style={{
                            background: '#F8FAFC',
                            border: '1px solid #CBD5E1',
                            padding: '6px 8px',
                            borderRadius: '6px',
                            cursor: 'pointer',
                            color: '#475569'
                          }}
                          title="Edit Warehouse Specifications"
                        >
                          <Edit3 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ================= MODAL: ADD / EDIT WAREHOUSE (COLD STORAGE REMOVED) ================= */}
      {isWarehouseModalOpen && (
        <div className="admin-modal-overlay">
          <div className="admin-modal-card">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '18px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{ width: '38px', height: '38px', borderRadius: '8px', background: '#234B3C', color: '#FFF', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Warehouse size={20} />
                </div>
                <div>
                  <h3 style={{ fontSize: '18px', fontWeight: 800, color: '#0F172A', margin: 0 }}>
                    {editingWarehouse ? 'Edit Warehouse' : 'Register New Warehouse'}
                  </h3>
                  <div style={{ fontSize: '12px', color: '#64748B' }}>
                    Configure central storage, cutoff times, and mandi receiving hub
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsWarehouseModalOpen(false)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748B' }}
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveWarehouse}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '14px', marginBottom: '14px' }}>
                <div>
                  <label className="form-label-title">Hub Code *</label>
                  <input
                    type="text"
                    className="form-input-control"
                    placeholder="e.g. WH-BLR-03"
                    value={warehouseForm.code}
                    onChange={(e) => setWarehouseForm({ ...warehouseForm, code: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <label className="form-label-title">Warehouse Name *</label>
                  <input
                    type="text"
                    className="form-input-control"
                    placeholder="e.g. East Agro Logistics Center"
                    value={warehouseForm.name}
                    onChange={(e) => setWarehouseForm({ ...warehouseForm, name: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div style={{ marginBottom: '14px' }}>
                <label className="form-label-title">Physical Location / Address *</label>
                <input
                  type="text"
                  className="form-input-control"
                  placeholder="e.g. Whitefield Agro-Park, Near APMC Yard, Bengaluru"
                  value={warehouseForm.location}
                  onChange={(e) => setWarehouseForm({ ...warehouseForm, location: e.target.value })}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '14px' }}>
                <div>
                  <label className="form-label-title">Morning Open Time</label>
                  <input
                    type="time"
                    className="form-input-control"
                    value={warehouseForm.openTime}
                    onChange={(e) => setWarehouseForm({ ...warehouseForm, openTime: e.target.value })}
                  />
                </div>
                <div>
                  <label className="form-label-title">Daily Order Cut-off Time *</label>
                  <input
                    type="time"
                    className="form-input-control"
                    value={warehouseForm.cutoffTime}
                    onChange={(e) => setWarehouseForm({ ...warehouseForm, cutoffTime: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div style={{ marginBottom: '14px' }}>
                <label className="form-label-title">Handling Capacity (Metric Tons)</label>
                <input
                  type="number"
                  className="form-input-control"
                  placeholder="40"
                  value={warehouseForm.capacityTons}
                  onChange={(e) => setWarehouseForm({ ...warehouseForm, capacityTons: Number(e.target.value) })}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '20px' }}>
                <div>
                  <label className="form-label-title">Hub Manager Name</label>
                  <input
                    type="text"
                    className="form-input-control"
                    placeholder="e.g. Anand Gowda"
                    value={warehouseForm.managerName}
                    onChange={(e) => setWarehouseForm({ ...warehouseForm, managerName: e.target.value })}
                  />
                </div>
                <div>
                  <label className="form-label-title">Manager Phone</label>
                  <input
                    type="tel"
                    className="form-input-control"
                    placeholder="e.g. +91 98450 11223"
                    value={warehouseForm.managerPhone}
                    onChange={(e) => setWarehouseForm({ ...warehouseForm, managerPhone: e.target.value })}
                  />
                </div>
              </div>

              <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
                <button
                  type="button"
                  onClick={() => setIsWarehouseModalOpen(false)}
                  style={{
                    padding: '10px 18px',
                    borderRadius: '8px',
                    border: '1.5px solid #CBD5E1',
                    background: '#F8FAFC',
                    color: '#64748B',
                    fontWeight: 700,
                    fontSize: '13px',
                    cursor: 'pointer'
                  }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  style={{
                    padding: '10px 22px',
                    borderRadius: '8px',
                    border: 'none',
                    background: '#234B3C',
                    color: '#FFF',
                    fontWeight: 800,
                    fontSize: '13px',
                    cursor: 'pointer'
                  }}
                >
                  {editingWarehouse ? 'Update Warehouse' : 'Save Warehouse'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
