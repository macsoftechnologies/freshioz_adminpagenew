import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Store, 
  Clock, 
  MapPin, 
  Plus, 
  Edit3, 
  Trash2, 
  Eye, 
  Download, 
  CheckCircle2, 
  X, 
  Save, 
  Phone, 
  Users, 
  Building2, 
  ArrowLeft,
  ChevronRight,
  ArrowRight
} from 'lucide-react';
import { useAdminRole } from '../context/AdminRoleContext';
import { useToast } from '../context/ToastContext';
import { saveFreshiozStore } from '../shared/freshiozStore';
import { exportToExcel } from '../utils/excelExporter';

export default function WarehouseStoresPage() {
  const { warehouseId } = useParams();
  const { store } = useAdminRole();
  const { showToast } = useToast();

  const warehouses = store.warehouses || [];
  const shops = store.shops || [];
  const societies = store.societies || [];

  // Find active warehouse
  const warehouse = warehouses.find(w => w.id === warehouseId) || warehouses[0];
  // Filter stores linked to this warehouse
  const warehouseStores = shops.filter(s => s.warehouseId === warehouse?.id);

  // Modal State for Add / Edit Store
  const [isAddStoreModalOpen, setIsAddStoreModalOpen] = useState(false);
  const [editingStore, setEditingStore] = useState(null);

  // Store Form State
  const [storeForm, setStoreForm] = useState({
    name: '',
    address: '',
    phone: '',
    manager: '',
    status: 'ACTIVE',
    capacityOrders: 500,
    lat: 12.9716,
    lng: 77.5946
  });

  // Inline Cutoff Time State for this warehouse
  const [inlineCutoff, setInlineCutoff] = useState(warehouse?.cutoffTime || '21:00');

  if (!warehouse) {
    return (
      <div className="admin-page-container" style={{ padding: '30px', textAlign: 'center' }}>
        <h2>Warehouse Not Found</h2>
        <p style={{ color: '#64748B', marginTop: '6px' }}>The requested warehouse could not be found.</p>
        <Link to="/warehouse-settings" className="admin-btn-primary" style={{ marginTop: '12px', display: 'inline-flex' }}>
          &larr; Back to Warehouses Directory
        </Link>
      </div>
    );
  }

  // Update inline cutoff
  const handleSaveCutoff = (e) => {
    e.preventDefault();
    saveFreshiozStore(prev => ({
      ...prev,
      warehouses: prev.warehouses.map(w => w.id === warehouse.id ? { ...w, cutoffTime: inlineCutoff } : w)
    }));
    showToast(`✓ Cutoff for ${warehouse.name} updated to ${inlineCutoff}!`);
  };

  // Add / Edit Store Handlers
  const handleOpenAddStore = () => {
    setEditingStore(null);
    setStoreForm({
      name: '',
      address: '',
      phone: '',
      manager: '',
      status: 'ACTIVE',
      capacityOrders: 500,
      lat: 12.9716,
      lng: 77.5946
    });
    setIsAddStoreModalOpen(true);
  };

  const handleOpenEditStore = (storeObj) => {
    setEditingStore(storeObj);
    setStoreForm({
      name: storeObj.name,
      address: storeObj.address,
      phone: storeObj.phone || '',
      manager: storeObj.manager || '',
      status: storeObj.status || 'ACTIVE',
      capacityOrders: storeObj.capacityOrders || 500,
      lat: storeObj.lat || 12.9716,
      lng: storeObj.lng || 77.5946
    });
    setIsAddStoreModalOpen(true);
  };

  const handleSaveStore = (e) => {
    e.preventDefault();
    if (!storeForm.name.trim() || !storeForm.address.trim()) {
      alert('Please enter store name and physical address.');
      return;
    }

    const resolvedLat = Number(storeForm.lat) || 12.9716;
    const resolvedLng = Number(storeForm.lng) || 77.5946;

    if (editingStore) {
      saveFreshiozStore(prev => ({
        ...prev,
        shops: prev.shops.map(s => s.id === editingStore.id ? {
          ...s,
          ...storeForm,
          lat: resolvedLat,
          lng: resolvedLng
        } : s)
      }));
      showToast(`✓ Store "${storeForm.name}" updated successfully.`);
    } else {
      const newStoreId = `shop-${Date.now().toString().slice(-4)}`;
      const newStore = {
        id: newStoreId,
        warehouseId: warehouse.id,
        ...storeForm,
        lat: resolvedLat,
        lng: resolvedLng
      };

      // Also register store manager in employees if specified
      const newManagerEmp = storeForm.manager?.trim() ? {
        id: `emp-${Date.now().toString().slice(-4)}`,
        name: storeForm.manager.trim(),
        phone: storeForm.phone?.trim() || '9845011999',
        email: `${storeForm.manager.toLowerCase().replace(/\s+/g, '.')}@freshioz.com`,
        roles: ['STORE_MANAGER'],
        assignedWarehouseId: newStoreId,
        assignedLocationType: 'STORE',
        assignedLocationName: storeForm.name,
        status: 'ACTIVE',
        inviteStatus: 'ACTIVE',
        password: 'admin123',
        dateJoined: new Date().toISOString().slice(0, 10),
        notes: `Store in-charge for ${storeForm.name}`
      } : null;

      saveFreshiozStore(prev => ({
        ...prev,
        shops: [...(prev.shops || []), newStore],
        employees: newManagerEmp ? [newManagerEmp, ...(prev.employees || [])] : prev.employees
      }));
      showToast(`✓ New Store "${storeForm.name}" registered under ${warehouse.name}!`);
    }

    setIsAddStoreModalOpen(false);
  };

  const handleDeleteStore = (storeId) => {
    if (confirm('Are you sure you want to remove this store from the warehouse network?')) {
      saveFreshiozStore(prev => ({
        ...prev,
        shops: prev.shops.filter(s => s.id !== storeId)
      }));
      showToast('Store removed.');
    }
  };

  // Export Stores Excel
  const handleExportStoresExcel = () => {
    const headers = [
      'Store ID',
      'Store Name',
      'Parent Warehouse',
      'Address',
      'Store Manager',
      'Phone',
      'Daily Order Capacity',
      'Staff Count',
      'Societies Count',
      'Status'
    ];

    const rows = warehouseStores.map(s => [
      s.id,
      s.name,
      warehouse.name,
      s.address,
      s.manager,
      s.phone,
      s.capacityOrders || 500,
      (s.staff || []).length,
      societies.filter(soc => soc.nearestShopId === s.id).length,
      s.status || 'ACTIVE'
    ]);

    exportToExcel(`Freshioz_Stores_${warehouse.code || warehouse.id}`, headers, rows);
  };

  return (
    <div className="admin-page-container">
      {/* High-Density Compact Breadcrumb Navigation */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: '#64748B', marginBottom: '8px' }}>
        <Link to="/warehouse-settings" style={{ color: '#234B3C', fontWeight: 700, textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '4px' }}>
          <ArrowLeft size={13} />
          <span>Warehouses</span>
        </Link>
        <ChevronRight size={12} color="#94A3B8" />
        <span style={{ color: '#0F172A', fontWeight: 700 }}>{warehouse.name}</span>
        <ChevronRight size={12} color="#94A3B8" />
        <span>Linked Stores</span>
      </div>

      {/* Slim Header: Title, Inline Meta Chips & Actions in a single compact strip (Under 60px) */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '10px',
        paddingBottom: '10px',
        borderBottom: '1.5px solid #E2E8F0',
        marginBottom: '14px'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
            <h1 style={{ fontSize: '18px', color: '#0F172A', fontWeight: 800, margin: 0 }}>
              Stores Linked to {warehouse.name}
            </h1>
            <span style={{ background: '#234B3C', color: '#FFF', fontSize: '10.5px', fontWeight: 800, padding: '2px 7px', borderRadius: '4px' }}>
              {warehouse.code || warehouse.id}
            </span>
            <span style={{ background: '#E0F2FE', color: '#0369A1', fontSize: '11px', fontWeight: 800, padding: '2px 8px', borderRadius: '4px' }}>
              {warehouseStores.length} Stores
            </span>
          </div>

          {/* Inline Metadata Strip (Eliminated 250px huge card!) */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', fontSize: '11.5px', color: '#64748B', marginTop: '3px', flexWrap: 'wrap' }}>
            <span>📍 {warehouse.location}</span>
            <span>• Lead: <strong>{warehouse.managerName || 'Operations Lead'}</strong> ({warehouse.managerPhone})</span>
            <span>• Capacity: <strong style={{ color: '#059669' }}>{warehouse.capacityTons || 35} Tons</strong></span>
            
            {/* Inline Cutoff Setter */}
            <form onSubmit={handleSaveCutoff} style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', marginLeft: '6px' }}>
              <span style={{ fontWeight: 700, color: '#B45309' }}>Cut-off:</span>
              <input
                type="time"
                value={inlineCutoff}
                onChange={(e) => setInlineCutoff(e.target.value)}
                style={{
                  padding: '2px 6px',
                  borderRadius: '4px',
                  border: '1px solid #CBD5E1',
                  fontSize: '11.5px',
                  fontWeight: 700,
                  color: '#0F172A',
                  background: '#FFF'
                }}
              />
              <button
                type="submit"
                style={{
                  padding: '2px 7px',
                  borderRadius: '4px',
                  background: '#234B3C',
                  color: '#FFF',
                  border: 'none',
                  fontSize: '11px',
                  fontWeight: 800,
                  cursor: 'pointer'
                }}
              >
                Save
              </button>
            </form>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <button
            type="button"
            onClick={handleExportStoresExcel}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '5px',
              padding: '7px 12px',
              borderRadius: '6px',
              background: '#FFFFFF',
              border: '1.5px solid #CBD5E1',
              color: '#334155',
              fontWeight: 700,
              fontSize: '12px',
              cursor: 'pointer'
            }}
          >
            <Download size={13} />
            <span>Export Excel</span>
          </button>

          {/* Fixed button label: Single clean icon without duplicate plus */}
          <button
            type="button"
            onClick={handleOpenAddStore}
            className="admin-btn-accent"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', padding: '7px 14px', fontSize: '12px' }}
          >
            <Plus size={14} />
            <span>Add Store</span>
          </button>
        </div>
      </div>

      {/* ================= DEDICATED FULL-WIDTH STORES TABLE (Immediately Visible at Top!) ================= */}
      <div className="admin-table-card">
        <div className="admin-table-header" style={{ padding: '12px 16px' }}>
          <div>
            <h3 style={{ fontSize: '14px', color: '#0F172A', fontWeight: 800, margin: 0, display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Store size={16} color="#234B3C" />
              <span>Connected Store Hubs ({warehouseStores.length})</span>
            </h3>
            <div style={{ fontSize: '11.5px', color: '#64748B' }}>
              Click <strong>View Details &rarr;</strong> to open the full store management desk (staff, societies & delivery route).
            </div>
          </div>

          <button
            type="button"
            onClick={handleOpenAddStore}
            style={{
              background: '#F0FDF4',
              border: '1px solid #BBF7D0',
              color: '#166534',
              padding: '5px 10px',
              borderRadius: '5px',
              fontSize: '11.5px',
              fontWeight: 800,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '4px'
            }}
          >
            <Plus size={13} />
            <span>Add Store</span>
          </button>
        </div>

        <div style={{ overflowX: 'auto', width: '100%' }}>
          <table className="admin-data-table" style={{ width: '100%', minWidth: '760px' }}>
            <thead>
              <tr>
                <th>Store ID & Name</th>
                <th>Physical Hub Address</th>
                <th>Store Manager</th>
                <th>Store People</th>
                <th>Covered Societies</th>
                <th>Capacity</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {warehouseStores.length === 0 ? (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '36px', color: '#64748B' }}>
                    No stores currently linked to this warehouse. Click <strong>Add Store</strong> to register one.
                  </td>
                </tr>
              ) : (
                warehouseStores.map(storeObj => {
                  const staffCount = (storeObj.staff || []).length;
                  const coveredSocCount = societies.filter(s => s.nearestShopId === storeObj.id).length;

                  return (
                    <tr key={storeObj.id}>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <div style={{
                            width: '30px',
                            height: '30px',
                            borderRadius: '6px',
                            background: '#E2E8F0',
                            color: '#334155',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontWeight: 800,
                            fontSize: '11px'
                          }}>
                            <Store size={14} />
                          </div>
                          <div>
                            <strong style={{ fontSize: '13px', color: '#0F172A' }}>{storeObj.name}</strong>
                            <div style={{ fontSize: '11px', color: '#64748B' }}>Code: {storeObj.id}</div>
                          </div>
                        </div>
                      </td>

                      <td>
                        <div style={{ fontSize: '12px', color: '#334155', maxWidth: '240px' }}>
                          {storeObj.address}
                        </div>
                      </td>

                      <td>
                        <div style={{ fontSize: '12.5px', color: '#0F172A', fontWeight: 700 }}>
                          {storeObj.manager}
                        </div>
                        <div style={{ fontSize: '11px', color: '#64748B' }}>
                          {storeObj.phone}
                        </div>
                      </td>

                      <td>
                        <Link
                          to={`/warehouse/${warehouse.id}/store/${storeObj.id}`}
                          style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '4px',
                            background: '#EFF6FF',
                            border: '1px solid #BFDBFE',
                            padding: '3px 8px',
                            borderRadius: '5px',
                            color: '#1D4ED8',
                            fontSize: '11px',
                            fontWeight: 800,
                            textDecoration: 'none'
                          }}
                          title="Open dedicated page for store staff"
                        >
                          <Users size={12} />
                          <span>{staffCount} People</span>
                        </Link>
                      </td>

                      <td>
                        <span style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '4px',
                          background: coveredSocCount > 0 ? '#ECFDF5' : '#F1F5F9',
                          color: coveredSocCount > 0 ? '#059669' : '#64748B',
                          padding: '3px 7px',
                          borderRadius: '5px',
                          fontSize: '11px',
                          fontWeight: 800
                        }}>
                          <Building2 size={11} />
                          <span>{coveredSocCount} Societies</span>
                        </span>
                      </td>

                      <td>
                        <div style={{ fontSize: '12px', color: '#166534', fontWeight: 800 }}>
                          {storeObj.capacityOrders || 500} Orders/Day
                        </div>
                      </td>

                      <td>
                        <span className={`status-pill ${storeObj.status === 'ACTIVE' ? 'approved' : 'rejected'}`}>
                          {storeObj.status || 'ACTIVE'}
                        </span>
                      </td>

                      <td style={{ textAlign: 'right' }}>
                        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                          {/* Dedicated Page Link: Opens /warehouse/:whId/store/:storeId on fresh page */}
                          <Link
                            to={`/warehouse/${warehouse.id}/store/${storeObj.id}`}
                            style={{
                              background: '#234B3C',
                              color: '#FFFFFF',
                              padding: '5px 10px',
                              borderRadius: '5px',
                              fontSize: '11.5px',
                              fontWeight: 800,
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '4px',
                              textDecoration: 'none'
                            }}
                            title="Open dedicated page for store details, staff & mapped societies"
                          >
                            <Eye size={12} />
                            <span>View Details</span>
                            <ArrowRight size={12} />
                          </Link>

                          <button
                            type="button"
                            onClick={() => handleOpenEditStore(storeObj)}
                            style={{
                              background: '#F8FAFC',
                              border: '1px solid #CBD5E1',
                              padding: '5px 7px',
                              borderRadius: '5px',
                              cursor: 'pointer',
                              color: '#334155'
                            }}
                            title="Edit Store Specs"
                          >
                            <Edit3 size={12} />
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDeleteStore(storeObj.id)}
                            style={{
                              background: '#FFF1F2',
                              border: '1px solid #FECDD3',
                              padding: '5px 6px',
                              borderRadius: '5px',
                              cursor: 'pointer',
                              color: '#E11D48'
                            }}
                            title="Delete Store"
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ================= MODAL: ADD / EDIT STORE ================= */}
      {isAddStoreModalOpen && (
        <div className="admin-modal-overlay">
          <div className="admin-modal-card">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{ width: '36px', height: '36px', borderRadius: '8px', background: '#059669', color: '#FFF', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Store size={18} />
                </div>
                <div>
                  <h3 style={{ fontSize: '17px', fontWeight: 800, color: '#0F172A', margin: 0 }}>
                    {editingStore ? 'Edit Store Hub' : 'Register New Store'}
                  </h3>
                  <div style={{ fontSize: '11.5px', color: '#64748B' }}>
                    Under {warehouse.name} ({warehouse.code})
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsAddStoreModalOpen(false)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748B' }}
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveStore}>
              <div style={{ marginBottom: '12px' }}>
                <label className="form-label-title">Store Name *</label>
                <input
                  type="text"
                  className="form-input-control"
                  placeholder="e.g. Sarjapur Agro Hub (Shop 6)"
                  value={storeForm.name}
                  onChange={(e) => setStoreForm({ ...storeForm, name: e.target.value })}
                  required
                />
              </div>

              <div style={{ marginBottom: '12px' }}>
                <label className="form-label-title">Physical Address / Locality *</label>
                <input
                  type="text"
                  className="form-input-control"
                  placeholder="e.g. Sarjapur Main Road, Near Carmelaram Station, Bengaluru"
                  value={storeForm.address}
                  onChange={(e) => setStoreForm({ ...storeForm, address: e.target.value })}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '12px' }}>
                <div>
                  <label className="form-label-title">Store Manager / In-Charge</label>
                  <input
                    type="text"
                    className="form-input-control"
                    placeholder="e.g. Ramesh V"
                    value={storeForm.manager}
                    onChange={(e) => setStoreForm({ ...storeForm, manager: e.target.value })}
                  />
                </div>
                <div>
                  <label className="form-label-title">Contact Phone</label>
                  <input
                    type="tel"
                    className="form-input-control"
                    placeholder="e.g. +91 98450 12345"
                    value={storeForm.phone}
                    onChange={(e) => setStoreForm({ ...storeForm, phone: e.target.value })}
                  />
                </div>
              </div>

              {/* GPS Coordinates & Locality Presets */}
              <div style={{ marginBottom: '14px', background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: '8px', padding: '10px 12px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <label className="form-label-title" style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '5px' }}>
                    <MapPin size={13} color="#EA580C" />
                    <span>GPS Coordinates (Latitude & Longitude) *</span>
                  </label>
                  <span style={{ fontSize: '11px', color: '#64748B' }}>For auto-mapping nearby societies</span>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '8px' }}>
                  <div>
                    <label style={{ fontSize: '10.5px', color: '#64748B' }}>Latitude (Decimal)</label>
                    <input
                      type="number"
                      step="any"
                      className="form-input-control"
                      value={storeForm.lat}
                      onChange={(e) => setStoreForm({ ...storeForm, lat: e.target.value })}
                      placeholder="e.g. 12.9784"
                      required
                    />
                  </div>
                  <div>
                    <label style={{ fontSize: '10.5px', color: '#64748B' }}>Longitude (Decimal)</label>
                    <input
                      type="number"
                      step="any"
                      className="form-input-control"
                      value={storeForm.lng}
                      onChange={(e) => setStoreForm({ ...storeForm, lng: e.target.value })}
                      placeholder="e.g. 77.6408"
                      required
                    />
                  </div>
                </div>

                {/* Locality Quick Presets */}
                <div>
                  <div style={{ fontSize: '11px', fontWeight: 700, color: '#475569', marginBottom: '4px' }}>Quick Locality Presets:</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                    {[
                      { name: 'Indiranagar', lat: 12.9784, lng: 77.6408 },
                      { name: 'Whitefield', lat: 12.9856, lng: 77.7321 },
                      { name: 'Koramangala', lat: 12.9352, lng: 77.6245 },
                      { name: 'HSR Layout', lat: 12.9110, lng: 77.6388 },
                      { name: 'Electronic City', lat: 12.8452, lng: 77.6602 },
                      { name: 'Sarjapur', lat: 12.9229, lng: 77.6835 },
                      { name: 'Hebbal', lat: 13.0450, lng: 77.5920 },
                      { name: 'Yelahanka', lat: 13.1007, lng: 77.5963 }
                    ].map(preset => (
                      <button
                        key={preset.name}
                        type="button"
                        onClick={() => setStoreForm({ ...storeForm, lat: preset.lat, lng: preset.lng })}
                        style={{
                          background: Math.abs(storeForm.lat - preset.lat) < 0.005 && Math.abs(storeForm.lng - preset.lng) < 0.005 ? '#E0F2FE' : '#FFFFFF',
                          border: '1px solid #CBD5E1',
                          borderRadius: '4px',
                          padding: '3px 7px',
                          fontSize: '10.5px',
                          color: '#334155',
                          cursor: 'pointer',
                          fontWeight: 600
                        }}
                      >
                        {preset.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '18px' }}>
                <div>
                  <label className="form-label-title">Daily Order Capacity</label>
                  <input
                    type="number"
                    className="form-input-control"
                    value={storeForm.capacityOrders}
                    onChange={(e) => setStoreForm({ ...storeForm, capacityOrders: Number(e.target.value) })}
                  />
                </div>
                <div>
                  <label className="form-label-title">Status</label>
                  <select
                    className="form-input-control"
                    value={storeForm.status}
                    onChange={(e) => setStoreForm({ ...storeForm, status: e.target.value })}
                  >
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="INACTIVE">INACTIVE</option>
                  </select>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end' }}>
                <button
                  type="button"
                  onClick={() => setIsAddStoreModalOpen(false)}
                  style={{
                    padding: '8px 16px',
                    borderRadius: '6px',
                    border: '1.5px solid #CBD5E1',
                    background: '#F8FAFC',
                    color: '#64748B',
                    fontWeight: 700,
                    fontSize: '12px',
                    cursor: 'pointer'
                  }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  style={{
                    padding: '8px 20px',
                    borderRadius: '6px',
                    border: 'none',
                    background: '#059669',
                    color: '#FFF',
                    fontWeight: 800,
                    fontSize: '12px',
                    cursor: 'pointer'
                  }}
                >
                  {editingStore ? 'Update Store' : 'Save Store'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
