import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ClipboardList, Plus, Truck, CheckCircle2, Clock, Warehouse, Filter, Layers } from 'lucide-react';
import { useAdminRole } from '../context/AdminRoleContext';

export default function ProcurementDemandPage() {
  const { store } = useAdminRole();
  const warehouses = store.warehouses || [];

  const [selectedWarehouseId, setSelectedWarehouseId] = useState('ALL');
  const [deliveryDateFilter, setDeliveryDateFilter] = useState('TOMORROW'); // 'TOMORROW' | 'ALL_OPEN'

  // Filter open orders (Excludes already PACKED, DELIVERED, and CANCELLED)
  const openOrders = (store.orders || []).filter(order => {
    const isOpenStatus = order.status === 'CONFIRMED' || order.status === 'PROCURING';
    if (!isOpenStatus) return false;

    // Filter by warehouse
    if (selectedWarehouseId !== 'ALL') {
      const whCode = warehouses.find(w => w.id === selectedWarehouseId)?.code;
      if (order.warehouseId && order.warehouseId !== selectedWarehouseId) return false;
      if (order.warehouseCode && whCode && order.warehouseCode !== whCode) return false;
    }

    return true;
  });

  // Aggregate item demands strictly from filtered open orders
  const demandMap = {};
  openOrders.forEach(order => {
    (order.items || []).forEach(item => {
      const itemName = item.name || item.productName || 'Fresh Item';
      if (!demandMap[itemName]) {
        const prod = (store.products || []).find(p => p.name === itemName) || {};
        demandMap[itemName] = {
          name: itemName,
          category: prod.category || 'VEGETABLES',
          origin: prod.origin || 'Kolar Mandi',
          unit: item.unit || prod.retailUnit || 'kg',
          orderQty: 0,
          benchmarkRate: prod.wholesalePrice ? Math.round(prod.wholesalePrice / 20) : Math.round((prod.retailPrice || 40) * 0.65),
          retailPrice: prod.retailPrice || 40
        };
      }
      demandMap[itemName].orderQty += (Number(item.qty || item.quantity) || 1);
    });
  });

  // If no open orders, provide baseline products list with 0 open demand
  const demandList = Object.keys(demandMap).length > 0 
    ? Object.values(demandMap)
    : (store.products || []).map(p => ({
        name: p.name,
        category: p.category,
        origin: p.origin || 'Kolar APMC Mandi',
        unit: p.retailUnit || 'kg',
        orderQty: 0,
        benchmarkRate: Math.round((p.retailPrice || 40) * 0.65),
        retailPrice: p.retailPrice || 40
      }));

  const totalDemandUnits = demandList.reduce((acc, d) => acc + d.orderQty, 0);
  const totalEstimatedCost = demandList.reduce((acc, d) => acc + (d.orderQty * d.benchmarkRate), 0);

  return (
    <div className="admin-page-container">
      {/* Compact Page Title & Live Notice */}
      <div className="page-title-header" style={{ marginBottom: '12px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
          <div>
            <h1 style={{ fontSize: '18px', fontWeight: 800, color: '#0F172A', margin: 0 }}>
              Dawn Mandi Aggregated Procurement Demand
            </h1>
            <p style={{ fontSize: '12px', color: '#64748B', margin: '2px 0 0' }}>
              Real-time APMC auction checklist strictly aggregated from open confirmed orders
            </p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
            <span style={{ fontSize: '11.5px', background: '#EBF2EE', color: '#234B3C', padding: '3px 10px', borderRadius: '6px', fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
              <Clock size={13} />
              <span>Dawn Auctions: 04:00 AM – 05:30 AM</span>
            </span>
            <span style={{ fontSize: '11.5px', background: '#FEF3C7', color: '#B45309', padding: '3px 10px', borderRadius: '6px', fontWeight: 700 }}>
              {openOrders.length} Open Customer Orders
            </span>
          </div>
        </div>

        <Link
          to="/procurement-entry"
          className="admin-btn-accent"
          style={{ fontSize: '12px', padding: '6px 14px', borderRadius: '6px', height: 'auto', display: 'inline-flex', alignItems: 'center', gap: '6px' }}
        >
          <Plus size={14} />
          <span>Log Mandi Purchase</span>
        </Link>
      </div>

      {/* Warehouse & Date Scope Strip */}
      <div style={{
        background: '#FFFFFF',
        border: '1.5px solid #E2E8F0',
        borderRadius: '10px',
        padding: '10px 14px',
        marginBottom: '12px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '10px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Warehouse size={16} color="#0284C7" />
            <label style={{ fontSize: '12px', fontWeight: 700, color: '#334155' }}>Logistics Hub:</label>
            <select
              value={selectedWarehouseId}
              onChange={(e) => setSelectedWarehouseId(e.target.value)}
              style={{
                padding: '4px 8px',
                borderRadius: '6px',
                border: '1px solid #CBD5E1',
                fontSize: '12px',
                fontWeight: 700,
                color: '#0F172A',
                background: '#F8FAFC'
              }}
            >
              <option value="ALL">All Hubs (Citywide Aggregated)</option>
              {warehouses.map(w => (
                <option key={w.id} value={w.id}>
                  {w.code} — {w.name}
                </option>
              ))}
            </select>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Filter size={14} color="#64748B" />
            <span style={{ fontSize: '12px', color: '#64748B' }}>
              Target Window: <strong>Tomorrow Morning Dispatch</strong>
            </span>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '12px', fontSize: '12px' }}>
          <span>Net Produce: <strong style={{ color: '#234B3C' }}>{totalDemandUnits} units</strong></span>
          <span>Est. Spend: <strong style={{ color: '#0F172A' }}>₹{totalEstimatedCost.toLocaleString()}</strong></span>
        </div>
      </div>

      {/* Demand Table */}
      <div className="admin-table-card">
        <div className="admin-table-header">
          <h3 style={{ fontSize: '15px', color: '#0F172A', margin: 0 }}>Produce Procurement Checklist</h3>
          <span style={{ fontSize: '12px', color: '#64748B' }}>
            {selectedWarehouseId === 'ALL' ? 'Aggregated across all warehouses' : `Scoped strictly to ${selectedWarehouseId}`}
          </span>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table className="admin-data-table">
            <thead>
              <tr>
                <th>Crop / Produce Item</th>
                <th>Category</th>
                <th>Open Orders Demand</th>
                <th>Safety Buffer (+10%)</th>
                <th>Benchmark Mandi Rate</th>
                <th>Estimated Spend</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {demandList.map((d, idx) => {
                const bufferQty = Math.ceil(d.orderQty * 1.1);
                return (
                  <tr key={idx}>
                    <td>
                      <strong style={{ fontSize: '13px', color: '#0F172A' }}>{d.name}</strong>
                      <div style={{ fontSize: '11px', color: '#64748B' }}>Origin: {d.origin}</div>
                    </td>
                    <td>
                      <span style={{ fontSize: '11px', background: '#F1F5F9', padding: '2px 8px', borderRadius: '4px', fontWeight: 700, color: '#334155' }}>
                        {d.category}
                      </span>
                    </td>
                    <td>
                      <strong style={{ color: d.orderQty > 0 ? '#234B3C' : '#94A3B8', fontSize: '14px' }}>
                        {d.orderQty} {d.unit}
                      </strong>
                    </td>
                    <td>
                      <span style={{ fontSize: '12.5px', color: '#0284C7', fontWeight: 700 }}>
                        {bufferQty} {d.unit}
                      </span>
                    </td>
                    <td>₹{d.benchmarkRate} / {d.unit.includes('kg') ? 'kg' : 'unit'}</td>
                    <td>
                      <strong style={{ color: '#0F172A' }}>
                        ₹{(bufferQty * d.benchmarkRate).toLocaleString()}
                      </strong>
                    </td>
                    <td>
                      <Link
                        to="/procurement-entry"
                        style={{
                          background: '#F0F4F2',
                          color: '#234B3C',
                          padding: '5px 12px',
                          borderRadius: '6px',
                          fontSize: '12px',
                          fontWeight: 700,
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '4px',
                          textDecoration: 'none'
                        }}
                      >
                        <span>Log Mandi Bill</span>
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
