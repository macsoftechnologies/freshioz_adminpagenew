import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  ShieldCheck, 
  Lock, 
  Mail, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  UserCheck, 
  Sparkles,
  Building2,
  Truck,
  Warehouse,
  Store,
  CheckCircle2
} from 'lucide-react';
import FreshiozLogo from '../components/common/FreshiozLogo';
import { useAdminRole, ROLES } from '../context/AdminRoleContext';
import { useToast } from '../context/ToastContext';

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const { login, ROLES: rolesDict } = useAdminRole();
  const { showToast } = useToast();

  const [emailOrPhone, setEmailOrPhone] = useState('vikram.rao@freshioz.com');
  const [password, setPassword] = useState('Freshioz@Ops2026');
  const [showPassword, setShowPassword] = useState(false);
  const [selectedRole, setSelectedRole] = useState('SUPER_ADMIN');
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleFormLogin = (e) => {
    e.preventDefault();
    setErrorMsg('');

    if (!emailOrPhone.trim()) {
      setErrorMsg('Please enter your work email or phone number.');
      return;
    }
    if (!password.trim()) {
      setErrorMsg('Please enter your account password.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      const user = login(emailOrPhone.trim(), password, selectedRole);
      setIsLoading(false);
      showToast(`Welcome back, ${user.name} (${ROLES[selectedRole]?.label})!`, 'success');

      // Navigate to selected role default route
      const dest = ROLES[selectedRole]?.defaultRoute || '/dashboard';
      navigate(dest, { replace: true });
    }, 450);
  };

  const handleQuickDemoLogin = (roleKey) => {
    setIsLoading(true);
    setTimeout(() => {
      const demoEmails = {
        SUPER_ADMIN: 'vikram.rao@freshioz.com',
        WAREHOUSE_MANAGER: 'rajesh.ops@freshioz.com',
        SALES_OFFICER: 'sneha.sales@freshioz.com',
        PROCUREMENT_OFFICER: 'mohan.mandi@freshioz.com'
      };

      const email = demoEmails[roleKey] || 'ops@freshioz.com';
      const user = login(email, 'demo123', roleKey);
      setIsLoading(false);
      showToast(`Logged in as ${user.name} • ${ROLES[roleKey]?.label}`, 'success');

      const dest = ROLES[roleKey]?.defaultRoute || '/dashboard';
      navigate(dest, { replace: true });
    }, 300);
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #0D231A 0%, #173328 60%, #10261E 100%)',
      padding: '20px',
      position: 'relative',
      fontFamily: 'system-ui, -apple-system, sans-serif'
    }}>
      {/* Background Decorative Glow */}
      <div style={{
        position: 'absolute',
        top: '20%',
        left: '20%',
        width: '350px',
        height: '350px',
        background: 'rgba(5, 150, 105, 0.15)',
        borderRadius: '50%',
        filter: 'blur(90px)',
        pointerEvents: 'none'
      }} />

      <div style={{
        position: 'absolute',
        bottom: '15%',
        right: '20%',
        width: '300px',
        height: '300px',
        background: 'rgba(242, 142, 20, 0.1)',
        borderRadius: '50%',
        filter: 'blur(80px)',
        pointerEvents: 'none'
      }} />

      {/* Main Login Card */}
      <div style={{
        maxWidth: '460px',
        width: '100%',
        background: '#FFFFFF',
        borderRadius: '20px',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.35)',
        padding: '36px 32px',
        position: 'relative',
        zIndex: 10
      }}>
        {/* Brand Header */}
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '10px' }}>
            <FreshiozLogo height={42} showTagline={false} />
          </div>
          <h1 style={{ fontSize: '20px', fontWeight: 800, color: '#0F172A', margin: 0 }}>
            Operations & Admin Portal
          </h1>
          <p style={{ fontSize: '13px', color: '#64748B', marginTop: '4px' }}>
            Unified supply chain logistics, pricing & society verification
          </p>
        </div>

        {/* Error Alert if any */}
        {errorMsg && (
          <div style={{
            background: '#FEE2E2',
            border: '1px solid #FCA5A5',
            color: '#B91C1C',
            padding: '10px 14px',
            borderRadius: '8px',
            fontSize: '12.5px',
            fontWeight: 600,
            marginBottom: '16px'
          }}>
            {errorMsg}
          </div>
        )}

        {/* Standard Credentials Form */}
        <form onSubmit={handleFormLogin}>
          {/* Email / Mobile */}
          <div style={{ marginBottom: '16px' }}>
            <label style={{ display: 'block', fontSize: '12.5px', fontWeight: 700, color: '#334155', marginBottom: '6px' }}>
              Work Email / Phone Number
            </label>
            <div style={{ position: 'relative' }}>
              <div style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#94A3B8' }}>
                <Mail size={16} />
              </div>
              <input
                type="text"
                value={emailOrPhone}
                onChange={(e) => setEmailOrPhone(e.target.value)}
                placeholder="e.g. name@freshioz.com or 9845011000"
                style={{
                  width: '100%',
                  height: '42px',
                  paddingLeft: '38px',
                  paddingRight: '12px',
                  borderRadius: '10px',
                  border: '1.5px solid #CBD5E1',
                  fontSize: '13.5px',
                  outline: 'none',
                  boxSizing: 'border-box'
                }}
                required
              />
            </div>
          </div>

          {/* Password */}
          <div style={{ marginBottom: '16px' }}>
            <label style={{ display: 'block', fontSize: '12.5px', fontWeight: 700, color: '#334155', marginBottom: '6px' }}>
              Password
            </label>
            <div style={{ position: 'relative' }}>
              <div style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#94A3B8' }}>
                <Lock size={16} />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                style={{
                  width: '100%',
                  height: '42px',
                  paddingLeft: '38px',
                  paddingRight: '38px',
                  borderRadius: '10px',
                  border: '1.5px solid #CBD5E1',
                  fontSize: '13.5px',
                  outline: 'none',
                  boxSizing: 'border-box'
                }}
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                style={{
                  position: 'absolute',
                  right: '10px',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  background: 'none',
                  border: 'none',
                  color: '#94A3B8',
                  cursor: 'pointer',
                  padding: '4px'
                }}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {/* Operational Desk / Role Selector */}
          <div style={{ marginBottom: '16px' }}>
            <label style={{ display: 'block', fontSize: '12.5px', fontWeight: 700, color: '#334155', marginBottom: '6px' }}>
              Assign to Operations Desk
            </label>
            <div style={{ position: 'relative' }}>
              <div style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#234B3C' }}>
                <UserCheck size={16} />
              </div>
              <select
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value)}
                style={{
                  width: '100%',
                  height: '42px',
                  paddingLeft: '38px',
                  paddingRight: '12px',
                  borderRadius: '10px',
                  border: '1.5px solid #CBD5E1',
                  fontSize: '13px',
                  fontWeight: 700,
                  color: '#234B3C',
                  background: '#F8FAFC',
                  outline: 'none',
                  cursor: 'pointer',
                  boxSizing: 'border-box'
                }}
              >
                {Object.values(ROLES).map(r => (
                  <option key={r.id} value={r.id}>
                    {r.label} — {r.desc}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Remember Me & Forgot Password Row */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12.5px', color: '#475569', cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                style={{ accentColor: '#234B3C', cursor: 'pointer' }}
              />
              <span>Remember this session</span>
            </label>

            <Link
              to="/forgot-password"
              style={{ fontSize: '12.5px', fontWeight: 700, color: '#F28E14', textDecoration: 'none' }}
            >
              Forgot Password?
            </Link>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            style={{
              width: '100%',
              height: '44px',
              borderRadius: '10px',
              background: '#234B3C',
              color: '#FFFFFF',
              fontSize: '14px',
              fontWeight: 800,
              border: 'none',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
              transition: 'opacity 0.2s',
              opacity: isLoading ? 0.75 : 1
            }}
          >
            {isLoading ? (
              <span>Authenticating Session...</span>
            ) : (
              <>
                <span>Sign In to Operations Desk</span>
                <ArrowRight size={16} />
              </>
            )}
          </button>
        </form>

        {/* Divider */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', margin: '22px 0 16px' }}>
          <div style={{ flex: 1, height: '1px', background: '#E2E8F0' }} />
          <span style={{ fontSize: '11px', color: '#94A3B8', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
            Or Instant 1-Click Role Access
          </span>
          <div style={{ flex: 1, height: '1px', background: '#E2E8F0' }} />
        </div>

        {/* 1-Click Demo Buttons for Fast Developer / QA Testing */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px' }}>
          <button
            type="button"
            onClick={() => handleQuickDemoLogin('SUPER_ADMIN')}
            style={{
              padding: '8px 6px',
              borderRadius: '8px',
              background: '#F1F5F9',
              border: '1px solid #CBD5E1',
              color: '#0F172A',
              fontSize: '11px',
              fontWeight: 700,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '4px'
            }}
          >
            <ShieldCheck size={13} color="#234B3C" />
            <span>Super Admin</span>
          </button>

          <button
            type="button"
            onClick={() => handleQuickDemoLogin('WAREHOUSE_MANAGER')}
            style={{
              padding: '8px 6px',
              borderRadius: '8px',
              background: '#F1F5F9',
              border: '1px solid #CBD5E1',
              color: '#0F172A',
              fontSize: '11px',
              fontWeight: 700,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '4px'
            }}
          >
            <Warehouse size={13} color="#0284C7" />
            <span>WH Manager</span>
          </button>

          <button
            type="button"
            onClick={() => handleQuickDemoLogin('SALES_OFFICER')}
            style={{
              padding: '8px 6px',
              borderRadius: '8px',
              background: '#F1F5F9',
              border: '1px solid #CBD5E1',
              color: '#0F172A',
              fontSize: '11px',
              fontWeight: 700,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '4px'
            }}
          >
            <Building2 size={13} color="#F28E14" />
            <span>Field Sales</span>
          </button>

          <button
            type="button"
            onClick={() => handleQuickDemoLogin('PROCUREMENT_OFFICER')}
            style={{
              padding: '8px 6px',
              borderRadius: '8px',
              background: '#F1F5F9',
              border: '1px solid #CBD5E1',
              color: '#0F172A',
              fontSize: '11px',
              fontWeight: 700,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '4px'
            }}
          >
            <Truck size={13} color="#059669" />
            <span>Procurement</span>
          </button>

          <button
            type="button"
            onClick={() => handleQuickDemoLogin('STORE_MANAGER')}
            style={{
              padding: '8px 6px',
              borderRadius: '8px',
              background: '#F1F5F9',
              border: '1px solid #CBD5E1',
              color: '#0F172A',
              fontSize: '11px',
              fontWeight: 700,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '4px'
            }}
          >
            <Store size={13} color="#7C3AED" />
            <span>Store Hub</span>
          </button>

          <button
            type="button"
            onClick={() => handleQuickDemoLogin('DELIVERY_EXECUTIVE')}
            style={{
              padding: '8px 6px',
              borderRadius: '8px',
              background: '#F1F5F9',
              border: '1px solid #CBD5E1',
              color: '#0F172A',
              fontSize: '11px',
              fontWeight: 700,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '4px'
            }}
          >
            <Truck size={13} color="#DC2626" />
            <span>Delivery Rider</span>
          </button>
        </div>
      </div>
    </div>
  );
}
