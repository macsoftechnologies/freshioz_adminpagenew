import React, { useState } from 'react';
import { Tags, Save, Check, RefreshCw, AlertCircle, Download } from 'lucide-react';
import { useAdminRole } from '../context/AdminRoleContext';
import { useToast } from '../context/ToastContext';
import { saveFreshiozStore } from '../shared/freshiozStore';
import { exportToExcel } from '../utils/excelExporter';

export default function DailyPricingPage() {
  const { store } = useAdminRole();
  const { showToast } = useToast();

  const [products, setProducts] = useState(store.products || []);
  const [successToast, setSuccessToast] = useState('');

  const handlePriceChange = (id, field, value) => {
    setProducts(prev => prev.map(p => {
      if (p.id === id) {
        return { ...p, [field]: Number(value) };
      }
      return p;
    }));
  };

  const handleSaveAll = (e) => {
    e.preventDefault();
    saveFreshiozStore(prev => ({
      ...prev,
      products
    }));
    showToast('Daily Produce Rates, Wholesale Crate Prices & GST % Updated across all customer apps!', 'success');
    setSuccessToast('✓ Daily Produce Rates, Wholesale Crate Prices & GST % Updated! Live on customer storefront.');
    setTimeout(() => setSuccessToast(''), 5000);
  };

  // Export to Excel
  const handleExportExcel = () => {
    const headers = [
      'Produce ID',
      'Produce Name',
      'Category',
      'Retail Unit',
      'Today Retail Rate (₹)',
      'Wholesale Packaging',
      'Wholesale Crate Rate (₹)',
      'GST %',
      'Tax Status'
    ];

    const rows = products.map(p => [
      p.id,
      p.name,
      p.category,
      p.retailUnit,
      p.retailPrice,
      p.wholesaleUnit,
      p.wholesalePrice,
      `${p.gstPercent ?? 0}%`,
      (p.gstPercent ?? 0) === 0 ? 'Exempt' : 'Taxable'
    ]);

    exportToExcel('Freshioz_Daily_Pricing_GST_Master', headers, rows);
  };

  return (
    <div className="admin-page-container">
      {/* High-Density Compact Page Header (Under 50px) */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '8px',
        paddingBottom: '10px',
        borderBottom: '1.5px solid #E2E8F0',
        marginBottom: '12px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <h1 style={{ fontSize: '18px', color: '#0F172A', fontWeight: 800, margin: 0 }}>
            Daily Dynamic Pricing & GST Master
          </h1>
          <span style={{ fontSize: '11px', background: '#ECFDF5', color: '#059669', fontWeight: 800, padding: '2px 8px', borderRadius: '4px' }}>
            {products.length} Items Live
          </span>
        </div>

        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <button
            type="button"
            onClick={handleExportExcel}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '5px',
              padding: '6px 12px',
              borderRadius: '6px',
              background: '#FFFFFF',
              border: '1.5px solid #CBD5E1',
              color: '#334155',
              fontWeight: 700,
              fontSize: '12px',
              cursor: 'pointer'
            }}
          >
            <Download size={13} />
            <span>Export Excel</span>
          </button>

          <button
            type="button"
            onClick={handleSaveAll}
            className="admin-btn-primary"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', padding: '6px 16px', fontSize: '12px' }}
          >
            <Save size={14} />
            <span>Save All Updated Rates</span>
          </button>
        </div>
      </div>

      {successToast && (
        <div style={{
          background: '#ECFDF5',
          border: '1.5px solid #059669',
          color: '#065F46',
          padding: '8px 14px',
          borderRadius: '8px',
          fontWeight: 700,
          fontSize: '12px',
          marginBottom: '12px',
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <Check size={16} />
          <span>{successToast}</span>
        </div>
      )}

      {/* Pricing Table (Starts Immediately at Top!) */}
      <div className="admin-table-card">
        <div className="admin-table-header">
          <div>
            <h3 style={{ fontSize: '15px', color: '#0F172A', fontWeight: 800, margin: 0 }}>
              Daily Rate & Tax Master ({products.length} Items)
            </h3>
            <div style={{ fontSize: '12px', color: '#64748B', marginTop: '2px' }}>
              All price and GST % fields below are directly editable. Click "Save All Updated Rates" to apply immediately.
            </div>
          </div>
          <span style={{ fontSize: '12px', color: '#059669', fontWeight: 700, background: '#ECFDF5', padding: '4px 10px', borderRadius: '6px' }}>
            0% Default for Raw Produce
          </span>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table className="admin-data-table">
            <thead>
              <tr>
                <th>Item Name</th>
                <th>Category</th>
                <th>Retail Unit</th>
                <th>Today's Retail (₹)</th>
                <th>Wholesale Packaging</th>
                <th>Wholesale Rate (₹)</th>
                <th>GST % (Editable)</th>
              </tr>
            </thead>
            <tbody>
              {products.map(prod => {
                const gst = prod.gstPercent ?? 0;

                return (
                  <tr key={prod.id}>
                    <td>
                      <strong style={{ fontSize: '13.5px', color: '#0F172A' }}>{prod.name}</strong>
                    </td>
                    <td>
                      <span style={{ fontSize: '11px', background: '#F1F5F9', padding: '2px 8px', borderRadius: '4px', fontWeight: 700, color: '#334155' }}>
                        {prod.category}
                      </span>
                    </td>
                    <td style={{ fontSize: '13px', color: '#475569', fontWeight: 600 }}>{prod.retailUnit}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <span style={{ fontSize: '13px', fontWeight: 700, color: '#64748B' }}>₹</span>
                        <input
                          type="number"
                          value={prod.retailPrice}
                          onChange={(e) => handlePriceChange(prod.id, 'retailPrice', e.target.value)}
                          style={{
                            width: '84px',
                            height: '36px',
                            padding: '0 10px',
                            borderRadius: '6px',
                            border: '1.5px solid #CBD5E1',
                            fontWeight: 800,
                            color: '#234B3C',
                            fontSize: '13.5px',
                            background: '#FFF',
                            outline: 'none'
                          }}
                        />
                      </div>
                    </td>
                    <td style={{ fontSize: '12.5px', color: '#475569' }}>{prod.wholesaleUnit}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <span style={{ fontSize: '13px', fontWeight: 700, color: '#64748B' }}>₹</span>
                        <input
                          type="number"
                          value={prod.wholesalePrice}
                          onChange={(e) => handlePriceChange(prod.id, 'wholesalePrice', e.target.value)}
                          style={{
                            width: '94px',
                            height: '36px',
                            padding: '0 10px',
                            borderRadius: '6px',
                            border: '1.5px solid #CBD5E1',
                            fontWeight: 800,
                            color: '#D97706',
                            fontSize: '13.5px',
                            background: '#FFF',
                            outline: 'none'
                          }}
                        />
                      </div>
                    </td>

                    {/* EDITABLE GST % FIELD (Requested by user) */}
                    <td>
                      <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                        <input
                          type="number"
                          min="0"
                          max="28"
                          value={gst}
                          onChange={(e) => handlePriceChange(prod.id, 'gstPercent', e.target.value)}
                          style={{
                            width: '64px',
                            height: '36px',
                            padding: '0 8px',
                            borderRadius: '6px',
                            border: '1.5px solid #CBD5E1',
                            fontWeight: 800,
                            color: gst === 0 ? '#059669' : '#0F172A',
                            fontSize: '13.5px',
                            textAlign: 'center',
                            background: '#FFF',
                            outline: 'none'
                          }}
                        />
                        <span style={{ fontSize: '13px', fontWeight: 700, color: '#64748B' }}>%</span>
                        {gst === 0 ? (
                          <span style={{
                            fontSize: '11px',
                            background: '#ECFDF5',
                            color: '#059669',
                            padding: '2px 6px',
                            borderRadius: '4px',
                            fontWeight: 800
                          }}>
                            Exempt
                          </span>
                        ) : (
                          <span style={{
                            fontSize: '11px',
                            background: '#FEF3C7',
                            color: '#B45309',
                            padding: '2px 6px',
                            borderRadius: '4px',
                            fontWeight: 800
                          }}>
                            Taxable
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
