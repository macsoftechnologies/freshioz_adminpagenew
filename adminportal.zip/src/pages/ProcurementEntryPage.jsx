import React, { useState } from 'react';
import { 
  Truck, 
  MapPin, 
  FileText, 
  DollarSign, 
  Camera, 
  CheckCircle2, 
  Send,
  Building2,
  Store,
  Layers
} from 'lucide-react';
import { useAdminRole } from '../context/AdminRoleContext';
import { useToast } from '../context/ToastContext';
import { saveFreshiozStore } from '../shared/freshiozStore';

export default function ProcurementEntryPage() {
  const { store, currentUser } = useAdminRole();
  const { showToast } = useToast();

  const [formData, setFormData] = useState({
    vendorName: 'M.K. APMC Mandi Traders',
    mandiLocation: 'APMC Yard Kolar, Gate No. 4',
    lat: 13.1362,
    lng: 78.1347,
    productName: 'Farm Fresh Hybrid Tomatoes',
    unit: '20 kg Crates',
    quantity: '25',
    ratePerUnit: '380',
    totalAmount: '9500',
    billNumber: 'APMC/KLR/2026/9102',
    paymentMode: 'IMPS_TRANSFER',
    destinationType: 'CENTRAL_WAREHOUSE', // 'CENTRAL_WAREHOUSE' | 'DIRECT_SHOP' | 'DIRECT_WHOLESALE'
    destinationName: 'Central Agri-Hub North',
    receiptPhotoAttached: true
  });

  const [submitted, setSubmitted] = useState(false);

  const handleQtyRateChange = (qtyVal, rateVal) => {
    const q = Number(qtyVal) || 0;
    const r = Number(rateVal) || 0;
    setFormData(prev => ({
      ...prev,
      quantity: qtyVal,
      ratePerUnit: rateVal,
      totalAmount: String(q * r)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.vendorName || !formData.billNumber || !formData.totalAmount) {
      showToast('Please fill in all vendor and bill details.', 'error');
      return;
    }

    const newProcLog = {
      id: `PROC-${Date.now().toString().slice(-4)}`,
      mandiName: formData.mandiLocation,
      vendorName: formData.vendorName,
      lat: formData.lat,
      lng: formData.lng,
      items: [
        {
          name: formData.productName,
          qty: `${formData.quantity} (${formData.unit})`,
          rate: Number(formData.ratePerUnit),
          total: Number(formData.totalAmount)
        }
      ],
      destinationType: formData.destinationType,
      destinationName: formData.destinationName,
      totalAmountPaid: Number(formData.totalAmount),
      paymentMode: formData.paymentMode,
      billNumber: formData.billNumber,
      loggedByOfficerId: currentUser?.id || 'emp-104',
      loggedByOfficerName: currentUser?.name || 'Mandi Buyer',
      receiptPhotoAttached: true,
      timestamp: new Date().toISOString()
    };

    saveFreshiozStore(prev => ({
      ...prev,
      procurementLogs: [newProcLog, ...(prev.procurementLogs || [])]
    }));

    showToast('Mandi procurement record & bill logged successfully!', 'success');
    setSubmitted(true);
  };

  return (
    <div className="admin-page-container" style={{ maxWidth: '820px' }}>
      <div className="page-title-header" style={{ marginBottom: '14px' }}>
        <div>
          <h1 style={{ fontSize: '18px', fontWeight: 800, color: '#0F172A', margin: 0 }}>
            Log Mandi Vendor Purchase & Bill
          </h1>
          <p style={{ fontSize: '12px', color: '#64748B', margin: '2px 0 0' }}>
            Record farmer/mandi vendor purchases, attach bills, and select distribution routing
          </p>
        </div>
      </div>

      {submitted ? (
        <div style={{
          background: '#FFFFFF',
          borderRadius: '16px',
          border: '1.5px solid #059669',
          padding: '36px 24px',
          textAlign: 'center',
          boxShadow: '0 4px 16px rgba(5, 150, 105, 0.1)'
        }}>
          <div style={{
            width: '64px',
            height: '64px',
            borderRadius: '50%',
            background: '#ECFDF5',
            color: '#059669',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 16px'
          }}>
            <CheckCircle2 size={36} />
          </div>

          <h2 style={{ fontSize: '22px', color: '#065F46', marginBottom: '8px' }}>
            Mandi Purchase Logged & Dispatched!
          </h2>

          <p style={{ fontSize: '14px', color: '#475569', maxWidth: '540px', margin: '0 auto 20px', lineHeight: '1.6' }}>
            Bill <strong>#{formData.billNumber}</strong> for <strong>₹{Number(formData.totalAmount).toLocaleString()}</strong> successfully recorded.
            Routed to <strong>{formData.destinationName}</strong> for next-morning grading and packing.
          </p>

          <button
            type="button"
            onClick={() => setSubmitted(false)}
            className="admin-btn-primary"
            style={{ margin: '0 auto' }}
          >
            + Log Another Mandi Purchase
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="admin-form-card">
          {/* Vendor & Mandi Details */}
          <div style={{ borderBottom: '1px solid #E2E8F0', paddingBottom: '18px', marginBottom: '18px' }}>
            <h3 style={{ fontSize: '16px', color: '#234B3C', display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '14px' }}>
              <Store size={18} />
              <span>1. Mandi Trader & Market Location</span>
            </h3>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '14px' }}>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Vendor / Mandi Trader Name *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Ramesh Agro Traders"
                  value={formData.vendorName}
                  onChange={(e) => setFormData({ ...formData, vendorName: e.target.value })}
                  style={{ width: '100%', height: '42px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px' }}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  APMC Market Yard & Location *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Kolar APMC Yard, Shed 12"
                  value={formData.mandiLocation}
                  onChange={(e) => setFormData({ ...formData, mandiLocation: e.target.value })}
                  style={{ width: '100%', height: '42px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px' }}
                  required
                />
              </div>
            </div>
          </div>

          {/* Produce Items & Pricing */}
          <div style={{ borderBottom: '1px solid #E2E8F0', paddingBottom: '18px', marginBottom: '18px' }}>
            <h3 style={{ fontSize: '16px', color: '#234B3C', display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '14px' }}>
              <FileText size={18} />
              <span>2. Procured Produce & Invoiced Rates</span>
            </h3>

            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '14px', marginBottom: '14px' }}>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Crop / Produce Name *
                </label>
                <select
                  value={formData.productName}
                  onChange={(e) => setFormData({ ...formData, productName: e.target.value })}
                  style={{ width: '100%', height: '42px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px', fontWeight: 700 }}
                >
                  {store.products.map(p => (
                    <option key={p.id} value={p.name}>{p.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Unit Standard
                </label>
                <select
                  value={formData.unit}
                  onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                  style={{ width: '100%', height: '42px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px' }}
                >
                  <option value="20 kg Crates">20 kg Crates</option>
                  <option value="25 kg Sacks">25 kg Sacks</option>
                  <option value="Kilograms (kg)">Kilograms (kg)</option>
                  <option value="Bunches">Bunches</option>
                  <option value="10 kg Cartons">10 kg Cartons</option>
                </select>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '14px' }}>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Quantity Procured *
                </label>
                <input
                  type="number"
                  value={formData.quantity}
                  onChange={(e) => handleQtyRateChange(e.target.value, formData.ratePerUnit)}
                  style={{ width: '100%', height: '40px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px', fontWeight: 800 }}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Mandi Rate per Unit (₹) *
                </label>
                <input
                  type="number"
                  value={formData.ratePerUnit}
                  onChange={(e) => handleQtyRateChange(formData.quantity, e.target.value)}
                  style={{ width: '100%', height: '40px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px', fontWeight: 800 }}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Total Invoiced Amount (₹)
                </label>
                <input
                  type="text"
                  value={`₹${Number(formData.totalAmount).toLocaleString()}`}
                  readOnly
                  style={{ width: '100%', height: '40px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', background: '#F8FAFC', fontSize: '15px', fontWeight: 800, color: '#234B3C' }}
                />
              </div>
            </div>
          </div>

          {/* Destination Routing Selector (As Specifically Required by User) */}
          <div style={{ borderBottom: '1px solid #E2E8F0', paddingBottom: '18px', marginBottom: '18px' }}>
            <h3 style={{ fontSize: '16px', color: '#234B3C', display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '14px' }}>
              <Truck size={18} />
              <span>3. Logistics Destination & Dispatch Routing</span>
            </h3>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '10px', marginBottom: '14px' }}>
              <label style={{
                padding: '12px',
                borderRadius: '8px',
                border: formData.destinationType === 'CENTRAL_WAREHOUSE' ? '2px solid #234B3C' : '1px solid #CBD5E1',
                background: formData.destinationType === 'CENTRAL_WAREHOUSE' ? '#EBF2EE' : '#FFF',
                cursor: 'pointer'
              }}>
                <input
                  type="radio"
                  name="dest"
                  checked={formData.destinationType === 'CENTRAL_WAREHOUSE'}
                  onChange={() => setFormData({ ...formData, destinationType: 'CENTRAL_WAREHOUSE', destinationName: 'Central Agri-Hub North' })}
                  style={{ accentColor: '#234B3C', marginRight: '8px' }}
                />
                <strong style={{ fontSize: '13px' }}>Central Warehouse</strong>
                <div style={{ fontSize: '11.5px', color: '#64748B', marginTop: '2px' }}>
                  For central quality grading & crating
                </div>
              </label>

              <label style={{
                padding: '12px',
                borderRadius: '8px',
                border: formData.destinationType === 'DIRECT_SHOP' ? '2px solid #234B3C' : '1px solid #CBD5E1',
                background: formData.destinationType === 'DIRECT_SHOP' ? '#EBF2EE' : '#FFF',
                cursor: 'pointer'
              }}>
                <input
                  type="radio"
                  name="dest"
                  checked={formData.destinationType === 'DIRECT_SHOP'}
                  onChange={() => setFormData({ ...formData, destinationType: 'DIRECT_SHOP', destinationName: 'Indiranagar Fresh Hub (Shop 1)' })}
                  style={{ accentColor: '#234B3C', marginRight: '8px' }}
                />
                <strong style={{ fontSize: '13px' }}>Direct to Hub Shop</strong>
                <div style={{ fontSize: '11.5px', color: '#64748B', marginTop: '2px' }}>
                  Direct drop to Shop 1, 2, or 3
                </div>
              </label>

              <label style={{
                padding: '12px',
                borderRadius: '8px',
                border: formData.destinationType === 'DIRECT_WHOLESALE' ? '2px solid #234B3C' : '1px solid #CBD5E1',
                background: formData.destinationType === 'DIRECT_WHOLESALE' ? '#EBF2EE' : '#FFF',
                cursor: 'pointer'
              }}>
                <input
                  type="radio"
                  name="dest"
                  checked={formData.destinationType === 'DIRECT_WHOLESALE'}
                  onChange={() => setFormData({ ...formData, destinationType: 'DIRECT_WHOLESALE', destinationName: 'Wholesale Client Direct Delivery' })}
                  style={{ accentColor: '#234B3C', marginRight: '8px' }}
                />
                <strong style={{ fontSize: '13px' }}>Direct Wholesale Client</strong>
                <div style={{ fontSize: '11.5px', color: '#64748B', marginTop: '2px' }}>
                  Straight to hostel mess / catering
                </div>
              </label>
            </div>
          </div>

          {/* Mandi Bill & Receipt Upload */}
          <div style={{ marginBottom: '24px' }}>
            <h3 style={{ fontSize: '16px', color: '#234B3C', display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '14px' }}>
              <Camera size={18} />
              <span>4. Mandi Bill Number & Receipt Photo</span>
            </h3>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '14px' }}>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Mandi Invoice / Bill Number *
                </label>
                <input
                  type="text"
                  placeholder="e.g. APMC/2026/8912"
                  value={formData.billNumber}
                  onChange={(e) => setFormData({ ...formData, billNumber: e.target.value })}
                  style={{ width: '100%', height: '42px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px', fontFamily: 'monospace' }}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Payment Mode
                </label>
                <select
                  value={formData.paymentMode}
                  onChange={(e) => setFormData({ ...formData, paymentMode: e.target.value })}
                  style={{ width: '100%', height: '42px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px' }}
                >
                  <option value="IMPS_TRANSFER">IMPS / Bank Transfer</option>
                  <option value="UPI">Instant Mandi UPI</option>
                  <option value="CASH">Cash Settlement</option>
                  <option value="MANDI_CREDIT">Mandi 7-Day Credit Ledger</option>
                </select>
              </div>
            </div>

            <div style={{
              background: '#F8FAFC',
              border: '1.5px dashed #CBD5E1',
              borderRadius: '10px',
              padding: '16px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Camera size={24} color="#64748B" />
                <div>
                  <div style={{ fontSize: '13px', fontWeight: 700, color: '#0F172A' }}>Mandi Receipt Photo / Invoice Screenshot</div>
                  <div style={{ fontSize: '11.5px', color: '#64748B' }}>Captured via phone camera at APMC weighing counter</div>
                </div>
              </div>
              <span style={{ fontSize: '12px', background: '#ECFDF5', color: '#059669', fontWeight: 800, padding: '4px 10px', borderRadius: '9999px' }}>
                ✓ PHOTO ATTACHED
              </span>
            </div>
          </div>

          <button
            type="submit"
            className="admin-btn-accent"
            style={{ width: '100%', padding: '14px', fontSize: '15px', justifyContent: 'center' }}
          >
            <Send size={18} />
            <span>Submit Mandi Procurement Entry & Update Ledger</span>
          </button>
        </form>
      )}
    </div>
  );
}
