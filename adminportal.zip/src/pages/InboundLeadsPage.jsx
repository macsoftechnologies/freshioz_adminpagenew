import React from 'react';
import { Users, MapPin, Phone, Mail, ArrowRight, Building2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAdminRole } from '../context/AdminRoleContext';

export default function InboundLeadsPage() {
  const { store } = useAdminRole();

  const requests = store.societyRequests || [];

  return (
    <div className="admin-page-container">
      {/* Compact Page Title & Stats */}
      <div className="page-title-header" style={{ marginBottom: '12px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
          <div>
            <h1 style={{ fontSize: '18px', fontWeight: 800, color: '#0F172A', margin: 0 }}>
              Inbound Customer Society Requests
            </h1>
            <p style={{ fontSize: '12px', color: '#64748B', margin: '2px 0 0' }}>
              Societies requested by shoppers not yet in the registration dropdown
            </p>
          </div>

          <span style={{ fontSize: '11.5px', background: '#FEF3C7', color: '#B45309', padding: '3px 10px', borderRadius: '6px', fontWeight: 700 }}>
            {requests.length} New Field Leads
          </span>
        </div>

        <Link
          to="/sales-onboarding"
          className="admin-btn-primary"
          style={{ fontSize: '12px', padding: '6px 14px', borderRadius: '6px', height: 'auto', display: 'inline-flex', alignItems: 'center', gap: '6px' }}
        >
          <span>+ Onboard New Building</span>
        </Link>
      </div>

      {/* High-Density Table */}
      <div className="admin-table-card">
        <div style={{ overflowX: 'auto' }}>
          <table className="admin-data-table">
            <thead>
              <tr>
                <th>Requested Society</th>
                <th>Requester Customer</th>
                <th>Est. Flats / GPS</th>
                <th>Lead Status</th>
                <th style={{ textAlign: 'right' }}>Sales Action</th>
              </tr>
            </thead>
            <tbody>
              {requests.length === 0 ? (
                <tr>
                  <td colSpan="5" style={{ textAlign: 'center', padding: '36px 16px', color: '#64748B' }}>
                    No inbound customer requests right now.
                  </td>
                </tr>
              ) : (
                requests.map(req => (
                  <tr key={req.id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <div style={{
                          width: '28px',
                          height: '28px',
                          borderRadius: '6px',
                          background: '#EBF2EE',
                          color: '#234B3C',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0
                        }}>
                          <Building2 size={15} />
                        </div>
                        <div>
                          <strong style={{ fontSize: '13px', color: '#0F172A' }}>{req.societyName}</strong>
                          <div style={{ fontSize: '11px', color: '#64748B', display: 'flex', alignItems: 'center', gap: '3px' }}>
                            <MapPin size={11} color="#F28E14" />
                            <span>{req.address}</span>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div style={{ fontSize: '12.5px', fontWeight: 600, color: '#0F172A' }}>{req.requesterName}</div>
                      <div style={{ fontSize: '11px', color: '#64748B' }}>
                        +91 {req.requesterPhone} {req.requesterEmail ? `• ${req.requesterEmail}` : ''}
                      </div>
                    </td>
                    <td>
                      <strong style={{ fontSize: '12.5px', color: '#0F172A' }}>
                        ~{req.estimatedFlats || 150} Flats
                      </strong>
                      <div style={{ fontSize: '10.5px', color: '#64748B' }}>
                        Lat {req.lat}, Lng {req.lng}
                      </div>
                    </td>
                    <td>
                      {req.status === 'CONVERTED' ? (
                        <span style={{ fontSize: '11px', background: '#DCFCE7', color: '#166534', fontWeight: 800, padding: '2px 8px', borderRadius: '4px' }}>
                          ✓ CONVERTED
                        </span>
                      ) : (
                        <span style={{ fontSize: '11px', background: '#FEF3C7', color: '#B45309', fontWeight: 800, padding: '2px 8px', borderRadius: '4px' }}>
                          NEW FIELD LEAD
                        </span>
                      )}
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      {req.status === 'CONVERTED' ? (
                        <Link
                          to="/sales-societies"
                          style={{
                            background: '#ECFDF5',
                            color: '#065F46',
                            border: '1px solid #A7F3D0',
                            fontSize: '11.5px',
                            fontWeight: 700,
                            padding: '4px 10px',
                            borderRadius: '6px',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '4px',
                            textDecoration: 'none'
                          }}
                        >
                          <span>View in Societies</span>
                          <ArrowRight size={12} />
                        </Link>
                      ) : (
                        <Link
                          to={`/sales-onboarding?leadId=${req.id}`}
                          style={{
                            background: '#234B3C',
                            color: '#FFF',
                            fontSize: '11.5px',
                            fontWeight: 700,
                            padding: '5px 12px',
                            borderRadius: '6px',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '4px',
                            textDecoration: 'none'
                          }}
                        >
                          <span>Onboard Field</span>
                          <ArrowRight size={13} />
                        </Link>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
