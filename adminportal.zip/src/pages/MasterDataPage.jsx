import React, { useState } from 'react';
import { 
  Database, 
  FolderPlus, 
  Plus, 
  Scale, 
  Apple, 
  Edit3, 
  Trash2, 
  Download, 
  Search, 
  CheckCircle2, 
  X,
  Package,
  Layers,
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAdminRole } from '../context/AdminRoleContext';
import { useToast } from '../context/ToastContext';
import { saveFreshiozStore } from '../shared/freshiozStore';
import { exportToExcel } from '../utils/excelExporter';

export default function MasterDataPage() {
  const { store } = useAdminRole();
  const { showToast } = useToast();
  const categories = store.categories || [];
  const products = store.products || [];
  const units = store.units || [];

  const [activeTab, setActiveTab] = useState('PRODUCTS'); // 'PRODUCTS' | 'CATEGORIES' | 'UNITS'
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [isUnitModalOpen, setIsUnitModalOpen] = useState(false);

  // Simplified Form states
  const [categoryForm, setCategoryForm] = useState({ id: '', name: '', slug: '', icon: '🥦', description: '', status: 'ACTIVE' });
  const [unitForm, setUnitForm] = useState({ id: '', name: '', label: '', description: '', status: 'ACTIVE' });
  
  // Product Master Form: Strictly taxonomy specs, NO prices (prices managed exclusively at /daily-pricing)
  const [productForm, setProductForm] = useState({
    id: '',
    name: '',
    category: 'VEGETABLES',
    defaultUnit: '1 kg',
    origin: 'Kolar Agro Mandi, Karnataka',
    shelfLife: '4-5 Days',
    desc: '',
    image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600&auto=format&fit=crop&q=80',
    tags: 'Farm Fresh, Mandi Direct',
    status: 'ACTIVE'
  });

  const [editingId, setEditingId] = useState(null);

  // Export handlers
  const handleExportProductsExcel = () => {
    const headers = ['Produce ID', 'Item Name', 'Category', 'Default Unit', 'Origin Mandi', 'Shelf Life', 'Description', 'Status'];
    const rows = products.map(p => [
      p.id,
      p.name,
      p.category,
      p.defaultUnit || p.retailUnit || 'kg',
      p.origin || 'APMC Mandi',
      p.shelfLife || '3-5 Days',
      p.desc || '',
      p.status || 'ACTIVE'
    ]);
    exportToExcel('Freshioz_Produce_Master_Catalog', headers, rows);
  };

  const handleExportCategoriesExcel = () => {
    const headers = ['Category ID', 'Category Name', 'Slug', 'Icon', 'Description', 'Item Count', 'Status'];
    const rows = categories.map(c => [c.id, c.name, c.slug, c.icon, c.description, c.itemCount || 0, c.status]);
    exportToExcel('Freshioz_Categories_Master', headers, rows);
  };

  const handleExportUnitsExcel = () => {
    const headers = ['Unit Code', 'Display Label', 'Description', 'Status'];
    const rows = units.map(u => [u.name, u.label || u.name, u.description || '', u.status || 'ACTIVE']);
    exportToExcel('Freshioz_Packaging_Units_Master', headers, rows);
  };

  // Add / Edit Category
  const handleSaveCategory = (e) => {
    e.preventDefault();
    if (!categoryForm.name.trim()) return;

    const catId = editingId || categoryForm.name.toUpperCase().replace(/\s+/g, '_');
    const newCat = {
      ...categoryForm,
      id: catId,
      slug: categoryForm.slug || categoryForm.name.toLowerCase().replace(/\s+/g, '-'),
      itemCount: products.filter(p => p.category === catId).length
    };

    saveFreshiozStore(prev => ({
      ...prev,
      categories: editingId 
        ? prev.categories.map(c => c.id === editingId ? newCat : c)
        : [...(prev.categories || []), newCat]
    }));

    setIsCategoryModalOpen(false);
    setEditingId(null);
    showToast(`✓ Category "${categoryForm.name}" saved!`);
  };

  // Add / Edit Unit (Simplified to: kg, tones, crate, etc.)
  const handleSaveUnit = (e) => {
    e.preventDefault();
    if (!unitForm.name.trim()) return;

    const unitCode = unitForm.name.trim().toLowerCase();
    const unitId = editingId || `u-${unitCode}`;
    const newUnit = { 
      ...unitForm, 
      id: unitId,
      name: unitCode,
      label: unitForm.label.trim() || unitCode
    };

    saveFreshiozStore(prev => ({
      ...prev,
      units: editingId
        ? prev.units.map(u => u.id === editingId ? newUnit : u)
        : [...(prev.units || []), newUnit]
    }));

    setIsUnitModalOpen(false);
    setEditingId(null);
    showToast(`✓ Packaging Unit "${unitCode}" saved!`);
  };

  const handleDeleteUnit = (id) => {
    if (confirm('Delete this packaging unit?')) {
      saveFreshiozStore(prev => ({
        ...prev,
        units: prev.units.filter(u => u.id !== id)
      }));
      showToast('Unit deleted.');
    }
  };

  // Add / Edit Produce Item (Item Specs ONLY, NO PRICING)
  const handleSaveProduct = (e) => {
    e.preventDefault();
    if (!productForm.name.trim()) return;

    const prodId = editingId || `prod-${Date.now().toString().slice(-4)}`;
    const tagsArray = typeof productForm.tags === 'string' 
      ? productForm.tags.split(',').map(t => t.trim()).filter(Boolean)
      : productForm.tags;

    // Preserve existing daily prices from store if editing, but don't configure prices here
    const existingProd = products.find(p => p.id === prodId) || {};

    const newProd = {
      ...existingProd,
      ...productForm,
      id: prodId,
      retailUnit: productForm.defaultUnit || '1 kg',
      tags: tagsArray
    };

    saveFreshiozStore(prev => ({
      ...prev,
      products: editingId
        ? prev.products.map(p => p.id === editingId ? newProd : p)
        : [...(prev.products || []), newProd]
    }));

    setIsProductModalOpen(false);
    setEditingId(null);
    showToast(`✓ Produce item "${productForm.name}" cataloged! Daily rates managed at /daily-pricing.`);
  };

  const handleDeleteProduct = (id) => {
    if (confirm('Delete this produce item from the master catalog?')) {
      saveFreshiozStore(prev => ({
        ...prev,
        products: prev.products.filter(p => p.id !== id)
      }));
      showToast('Item removed from catalog.');
    }
  };

  // Filtered datasets
  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.origin?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredCategories = categories.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredUnits = units.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (u.label && u.label.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="admin-page-container">
      {/* High-Density Compact Header Strip (Under 55px) */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '8px',
        paddingBottom: '10px',
        borderBottom: '1.5px solid #E2E8F0',
        marginBottom: '12px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <h1 style={{ fontSize: '18px', color: '#0F172A', fontWeight: 800, margin: 0 }}>
            Master Data Catalog
          </h1>
          <span style={{ fontSize: '11px', color: '#64748B' }}>
            Taxonomies for Produce, Categories & Packing Units
          </span>
        </div>

        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <Link
            to="/daily-pricing"
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px',
              padding: '6px 12px',
              borderRadius: '6px',
              background: '#FEF3C7',
              border: '1px solid #FDE68A',
              color: '#92400E',
              fontSize: '11.5px',
              fontWeight: 800,
              textDecoration: 'none'
            }}
            title="Produce pricing is updated daily at /daily-pricing"
          >
            <span>Daily Pricing Desk &rarr;</span>
          </Link>

          <button
            type="button"
            onClick={
              activeTab === 'PRODUCTS' 
                ? handleExportProductsExcel 
                : activeTab === 'CATEGORIES' 
                ? handleExportCategoriesExcel 
                : handleExportUnitsExcel
            }
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px',
              padding: '6px 10px',
              borderRadius: '6px',
              background: '#FFFFFF',
              border: '1px solid #CBD5E1',
              color: '#334155',
              fontWeight: 700,
              fontSize: '12px',
              cursor: 'pointer'
            }}
          >
            <Download size={13} />
            <span>Export</span>
          </button>

          {activeTab === 'PRODUCTS' && (
            <button
              type="button"
              onClick={() => {
                setEditingId(null);
                setProductForm({
                  id: '',
                  name: '',
                  category: 'VEGETABLES',
                  defaultUnit: '1 kg',
                  origin: 'Kolar Agro Mandi, Karnataka',
                  shelfLife: '4-5 Days',
                  desc: '',
                  image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600&auto=format&fit=crop&q=80',
                  tags: 'Farm Fresh, Mandi Direct',
                  status: 'ACTIVE'
                });
                setIsProductModalOpen(true);
              }}
              className="admin-btn-accent"
              style={{ padding: '6px 12px', fontSize: '12px', display: 'inline-flex', alignItems: 'center', gap: '4px' }}
            >
              <Plus size={14} />
              <span>Add Produce</span>
            </button>
          )}

          {activeTab === 'CATEGORIES' && (
            <button
              type="button"
              onClick={() => {
                setEditingId(null);
                setCategoryForm({ id: '', name: '', slug: '', icon: '🥦', description: '', status: 'ACTIVE' });
                setIsCategoryModalOpen(true);
              }}
              className="admin-btn-accent"
              style={{ padding: '6px 12px', fontSize: '12px', display: 'inline-flex', alignItems: 'center', gap: '4px' }}
            >
              <Plus size={14} />
              <span>Add Category</span>
            </button>
          )}

          {activeTab === 'UNITS' && (
            <button
              type="button"
              onClick={() => {
                setEditingId(null);
                setUnitForm({ id: '', name: '', label: '', description: '', status: 'ACTIVE' });
                setIsUnitModalOpen(true);
              }}
              className="admin-btn-accent"
              style={{ padding: '6px 12px', fontSize: '12px', display: 'inline-flex', alignItems: 'center', gap: '4px' }}
            >
              <Plus size={14} />
              <span>Add Unit</span>
            </button>
          )}
        </div>
      </div>

      {/* Compact High-Density Tabs & Search Bar (Unified in single row!) */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '10px',
        marginBottom: '12px'
      }}>
        {/* Sleek Pill Tab Switcher */}
        <div style={{ display: 'inline-flex', background: '#F1F5F9', padding: '3px', borderRadius: '8px', gap: '3px' }}>
          <button
            type="button"
            onClick={() => { setActiveTab('PRODUCTS'); setSearchQuery(''); }}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              padding: '6px 14px',
              borderRadius: '6px',
              border: 'none',
              fontSize: '12.5px',
              fontWeight: 800,
              cursor: 'pointer',
              background: activeTab === 'PRODUCTS' ? '#234B3C' : 'transparent',
              color: activeTab === 'PRODUCTS' ? '#FFFFFF' : '#475569'
            }}
          >
            <Apple size={14} />
            <span>Produce Catalog</span>
            <span style={{ fontSize: '10.5px', background: activeTab === 'PRODUCTS' ? 'rgba(255,255,255,0.2)' : '#E2E8F0', padding: '1px 6px', borderRadius: '10px' }}>
              {products.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveTab('CATEGORIES'); setSearchQuery(''); }}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              padding: '6px 14px',
              borderRadius: '6px',
              border: 'none',
              fontSize: '12.5px',
              fontWeight: 800,
              cursor: 'pointer',
              background: activeTab === 'CATEGORIES' ? '#234B3C' : 'transparent',
              color: activeTab === 'CATEGORIES' ? '#FFFFFF' : '#475569'
            }}
          >
            <Layers size={14} />
            <span>Categories</span>
            <span style={{ fontSize: '10.5px', background: activeTab === 'CATEGORIES' ? 'rgba(255,255,255,0.2)' : '#E2E8F0', padding: '1px 6px', borderRadius: '10px' }}>
              {categories.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveTab('UNITS'); setSearchQuery(''); }}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              padding: '6px 14px',
              borderRadius: '6px',
              border: 'none',
              fontSize: '12.5px',
              fontWeight: 800,
              cursor: 'pointer',
              background: activeTab === 'UNITS' ? '#234B3C' : 'transparent',
              color: activeTab === 'UNITS' ? '#FFFFFF' : '#475569'
            }}
          >
            <Scale size={14} />
            <span>Packing Units</span>
            <span style={{ fontSize: '10.5px', background: activeTab === 'UNITS' ? 'rgba(255,255,255,0.2)' : '#E2E8F0', padding: '1px 6px', borderRadius: '10px' }}>
              {units.length}
            </span>
          </button>
        </div>

        {/* Compact Search */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          background: '#FFFFFF',
          border: '1px solid #CBD5E1',
          borderRadius: '6px',
          padding: '5px 10px',
          minWidth: '240px'
        }}>
          <Search size={14} color="#64748B" />
          <input
            type="text"
            placeholder={
              activeTab === 'PRODUCTS' 
                ? 'Search fruit/vegetable, origin...'
                : activeTab === 'CATEGORIES'
                ? 'Search categories...'
                : 'Search units (kg, crate...)...'
            }
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{ border: 'none', outline: 'none', fontSize: '12px', width: '100%' }}
          />
        </div>
      </div>

      {/* TAB 1: PRODUCE CATALOG (Taxonomy Specs ONLY, zero duplicate prices) */}
      {activeTab === 'PRODUCTS' && (
        <div className="admin-table-card">
          <div style={{ overflowX: 'auto', width: '100%' }}>
            <table className="admin-data-table" style={{ width: '100%', minWidth: '760px' }}>
              <thead>
                <tr>
                  <th>Produce Item & Code</th>
                  <th>Category</th>
                  <th>Default Unit</th>
                  <th>Mandi Origin</th>
                  <th>Shelf Life</th>
                  <th>Daily Pricing</th>
                  <th>Status</th>
                  <th style={{ textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredProducts.length === 0 ? (
                  <tr>
                    <td colSpan="8" style={{ textAlign: 'center', padding: '30px', color: '#64748B' }}>
                      No produce items found matching "{searchQuery}"
                    </td>
                  </tr>
                ) : (
                  filteredProducts.map(prod => (
                    <tr key={prod.id}>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <img
                            src={prod.image}
                            alt={prod.name}
                            style={{ width: '36px', height: '36px', borderRadius: '6px', objectFit: 'cover', flexShrink: 0 }}
                          />
                          <div>
                            <strong style={{ fontSize: '13px', color: '#0F172A' }}>{prod.name}</strong>
                            <div style={{ fontSize: '11px', color: '#64748B' }}>
                              Code: <code>{prod.id}</code>
                            </div>
                          </div>
                        </div>
                      </td>

                      <td>
                        <span style={{
                          background: '#F1F5F9',
                          color: '#334155',
                          fontSize: '11px',
                          fontWeight: 700,
                          padding: '2px 7px',
                          borderRadius: '4px'
                        }}>
                          {prod.category}
                        </span>
                      </td>

                      <td>
                        <strong style={{ fontSize: '12px', color: '#234B3C' }}>
                          {prod.defaultUnit || prod.retailUnit || 'kg'}
                        </strong>
                      </td>

                      <td>
                        <div style={{ fontSize: '11.5px', color: '#475569', maxWidth: '200px' }}>
                          {prod.origin || 'APMC Mandi'}
                        </div>
                      </td>

                      <td>
                        <div style={{ fontSize: '11.5px', color: '#64748B' }}>
                          {prod.shelfLife || '3-5 Days'}
                        </div>
                      </td>

                      <td>
                        <Link
                          to="/daily-pricing"
                          style={{
                            fontSize: '11px',
                            fontWeight: 700,
                            color: '#B45309',
                            background: '#FEF3C7',
                            padding: '3px 8px',
                            borderRadius: '4px',
                            textDecoration: 'none',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '3px'
                          }}
                          title="Click to view and edit live morning price in Daily Pricing"
                        >
                          <span>₹{prod.retailPrice || 0}/unit</span>
                          <ArrowRight size={10} />
                        </Link>
                      </td>

                      <td>
                        <span className={`status-pill ${prod.status === 'INACTIVE' ? 'rejected' : 'approved'}`} style={{ fontSize: '10.5px' }}>
                          {prod.status || 'ACTIVE'}
                        </span>
                      </td>

                      <td style={{ textAlign: 'right' }}>
                        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                          <button
                            type="button"
                            onClick={() => {
                              setEditingId(prod.id);
                              setProductForm({
                                id: prod.id,
                                name: prod.name,
                                category: prod.category,
                                defaultUnit: prod.defaultUnit || prod.retailUnit || '1 kg',
                                origin: prod.origin || '',
                                shelfLife: prod.shelfLife || '',
                                desc: prod.desc || '',
                                image: prod.image || '',
                                tags: Array.isArray(prod.tags) ? prod.tags.join(', ') : prod.tags || '',
                                status: prod.status || 'ACTIVE'
                              });
                              setIsProductModalOpen(true);
                            }}
                            style={{
                              background: '#F8FAFC',
                              border: '1px solid #CBD5E1',
                              padding: '5px 7px',
                              borderRadius: '5px',
                              cursor: 'pointer',
                              color: '#334155'
                            }}
                            title="Edit Produce Item Specs"
                          >
                            <Edit3 size={12} />
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDeleteProduct(prod.id)}
                            style={{
                              background: '#FFF1F2',
                              border: '1px solid #FECDD3',
                              padding: '5px 6px',
                              borderRadius: '5px',
                              cursor: 'pointer',
                              color: '#E11D48'
                            }}
                            title="Delete Item"
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: CATEGORIES MASTER TABLE */}
      {activeTab === 'CATEGORIES' && (
        <div className="admin-table-card">
          <div style={{ overflowX: 'auto', width: '100%' }}>
            <table className="admin-data-table" style={{ width: '100%' }}>
              <thead>
                <tr>
                  <th>Category Name & Icon</th>
                  <th>Category Code</th>
                  <th>URL Slug</th>
                  <th>Total Produce Items</th>
                  <th>Status</th>
                  <th style={{ textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredCategories.map(cat => (
                  <tr key={cat.id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span style={{ fontSize: '18px' }}>{cat.icon || '🌱'}</span>
                        <div>
                          <strong style={{ fontSize: '13px', color: '#0F172A' }}>{cat.name}</strong>
                          <div style={{ fontSize: '11px', color: '#64748B' }}>{cat.description}</div>
                        </div>
                      </div>
                    </td>

                    <td>
                      <code style={{ background: '#F1F5F9', padding: '2px 6px', borderRadius: '4px', fontSize: '11.5px', color: '#0F172A' }}>
                        {cat.id}
                      </code>
                    </td>

                    <td style={{ fontSize: '12px', color: '#64748B' }}>
                      {cat.slug}
                    </td>

                    <td>
                      <span style={{ fontWeight: 800, color: '#234B3C', fontSize: '12px' }}>
                        {products.filter(p => p.category === cat.id).length} Items
                      </span>
                    </td>

                    <td>
                      <span className="status-pill approved" style={{ fontSize: '10.5px' }}>ACTIVE</span>
                    </td>

                    <td style={{ textAlign: 'right' }}>
                      <button
                        type="button"
                        onClick={() => {
                          setEditingId(cat.id);
                          setCategoryForm({ ...cat });
                          setIsCategoryModalOpen(true);
                        }}
                        style={{
                          background: '#F8FAFC',
                          border: '1px solid #CBD5E1',
                          padding: '5px 8px',
                          borderRadius: '5px',
                          cursor: 'pointer',
                          color: '#334155',
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '4px',
                          fontSize: '11.5px'
                        }}
                      >
                        <Edit3 size={11} />
                        <span>Edit</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: PACKAGING UNITS MASTER (SIMPLIFIED: kg, tones, crate) */}
      {activeTab === 'UNITS' && (
        <div className="admin-table-card">
          <div style={{ overflowX: 'auto', width: '100%' }}>
            <table className="admin-data-table" style={{ width: '100%' }}>
              <thead>
                <tr>
                  <th>Packaging Unit Code</th>
                  <th>Display Label</th>
                  <th>Operational Description</th>
                  <th>Status</th>
                  <th style={{ textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredUnits.map(unit => (
                  <tr key={unit.id}>
                    <td>
                      <code style={{ fontSize: '13px', fontWeight: 800, color: '#0F172A', background: '#F1F5F9', padding: '3px 8px', borderRadius: '5px' }}>
                        {unit.name}
                      </code>
                    </td>

                    <td>
                      <strong style={{ fontSize: '13px', color: '#234B3C' }}>
                        {unit.label || unit.name}
                      </strong>
                    </td>

                    <td style={{ fontSize: '12px', color: '#64748B' }}>
                      {unit.description || 'Standard packaging unit'}
                    </td>

                    <td>
                      <span className="status-pill approved" style={{ fontSize: '10.5px' }}>ACTIVE</span>
                    </td>

                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                        <button
                          type="button"
                          onClick={() => {
                            setEditingId(unit.id);
                            setUnitForm({
                              id: unit.id,
                              name: unit.name,
                              label: unit.label || unit.name,
                              description: unit.description || '',
                              status: unit.status || 'ACTIVE'
                            });
                            setIsUnitModalOpen(true);
                          }}
                          style={{
                            background: '#F8FAFC',
                            border: '1px solid #CBD5E1',
                            padding: '4px 7px',
                            borderRadius: '5px',
                            cursor: 'pointer',
                            color: '#334155'
                          }}
                        >
                          <Edit3 size={11} />
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteUnit(unit.id)}
                          style={{
                            background: '#FFF1F2',
                            border: '1px solid #FECDD3',
                            padding: '4px 6px',
                            borderRadius: '5px',
                            cursor: 'pointer',
                            color: '#E11D48'
                          }}
                        >
                          <Trash2 size={11} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL: ADD / EDIT PRODUCE ITEM (Taxonomy Specs ONLY, NO Pricing Fields) */}
      {isProductModalOpen && (
        <div className="admin-modal-overlay">
          <div className="admin-modal-card" style={{ maxWidth: '580px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Apple size={20} color="#234B3C" />
                <h3 style={{ fontSize: '17px', fontWeight: 800, color: '#0F172A', margin: 0 }}>
                  {editingId ? 'Edit Produce Item Specs' : 'Register New Produce Item'}
                </h3>
              </div>
              <button type="button" onClick={() => setIsProductModalOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748B' }}>
                <X size={18} />
              </button>
            </div>

            <div style={{ background: '#FEF3C7', border: '1px solid #FDE68A', padding: '8px 12px', borderRadius: '6px', fontSize: '11.5px', color: '#92400E', marginBottom: '14px' }}>
              ℹ️ <strong>Daily Pricing Separation:</strong> Market buying rates, consumer retail selling prices, wholesale crate rates, and GST % are managed daily at <strong>/daily-pricing</strong> based on morning APMC arrivals.
            </div>

            <form onSubmit={handleSaveProduct}>
              <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: '12px', marginBottom: '12px' }}>
                <div>
                  <label className="form-label-title" style={{ fontSize: '11px' }}>Produce Name *</label>
                  <input
                    type="text"
                    className="form-input-control"
                    placeholder="e.g. Crisp Green Capsicum (Shimla Mirch)"
                    value={productForm.name}
                    onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label className="form-label-title" style={{ fontSize: '11px' }}>Category *</label>
                  <select
                    className="form-input-control"
                    value={productForm.category}
                    onChange={(e) => setProductForm({ ...productForm, category: e.target.value })}
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.id}>{c.icon} {c.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '12px' }}>
                <div>
                  <label className="form-label-title" style={{ fontSize: '11px' }}>Default Packing Unit *</label>
                  <select
                    className="form-input-control"
                    value={productForm.defaultUnit}
                    onChange={(e) => setProductForm({ ...productForm, defaultUnit: e.target.value })}
                  >
                    {units.map(u => (
                      <option key={u.id} value={u.name}>
                        {u.name} ({u.label || u.name})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="form-label-title" style={{ fontSize: '11px' }}>Shelf Life</label>
                  <input
                    type="text"
                    className="form-input-control"
                    placeholder="e.g. 4-5 Days"
                    value={productForm.shelfLife}
                    onChange={(e) => setProductForm({ ...productForm, shelfLife: e.target.value })}
                  />
                </div>
              </div>

              <div style={{ marginBottom: '12px' }}>
                <label className="form-label-title" style={{ fontSize: '11px' }}>Mandi Origin / Source</label>
                <input
                  type="text"
                  className="form-input-control"
                  placeholder="e.g. Kolar Agro Mandi, Karnataka"
                  value={productForm.origin}
                  onChange={(e) => setProductForm({ ...productForm, origin: e.target.value })}
                />
              </div>

              <div style={{ marginBottom: '12px' }}>
                <label className="form-label-title" style={{ fontSize: '11px' }}>Image URL</label>
                <input
                  type="url"
                  className="form-input-control"
                  placeholder="https://images.unsplash.com/..."
                  value={productForm.image}
                  onChange={(e) => setProductForm({ ...productForm, image: e.target.value })}
                />
              </div>

              <div style={{ marginBottom: '16px' }}>
                <label className="form-label-title" style={{ fontSize: '11px' }}>Freshness Description & Tags</label>
                <input
                  type="text"
                  className="form-input-control"
                  placeholder="e.g. Farm picked, hydroponic, crisp"
                  value={productForm.desc}
                  onChange={(e) => setProductForm({ ...productForm, desc: e.target.value })}
                />
              </div>

              <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end' }}>
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  style={{ padding: '7px 14px', borderRadius: '6px', border: '1px solid #CBD5E1', background: '#FFF', fontSize: '12px' }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  style={{ padding: '7px 18px', borderRadius: '6px', border: 'none', background: '#234B3C', color: '#FFF', fontWeight: 800, fontSize: '12px' }}
                >
                  Save Item Specs
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD / EDIT CATEGORY */}
      {isCategoryModalOpen && (
        <div className="admin-modal-overlay">
          <div className="admin-modal-card" style={{ maxWidth: '440px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
              <h3 style={{ fontSize: '16px', fontWeight: 800, margin: 0 }}>Category Master Setup</h3>
              <button type="button" onClick={() => setIsCategoryModalOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748B' }}>
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveCategory}>
              <div style={{ marginBottom: '12px' }}>
                <label className="form-label-title" style={{ fontSize: '11px' }}>Category Name *</label>
                <input
                  type="text"
                  className="form-input-control"
                  placeholder="e.g. Exotic & Salads"
                  value={categoryForm.name}
                  onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '0.8fr 1.2fr', gap: '10px', marginBottom: '12px' }}>
                <div>
                  <label className="form-label-title" style={{ fontSize: '11px' }}>Emoji Icon</label>
                  <input
                    type="text"
                    className="form-input-control"
                    placeholder="🥦"
                    value={categoryForm.icon}
                    onChange={(e) => setCategoryForm({ ...categoryForm, icon: e.target.value })}
                  />
                </div>
                <div>
                  <label className="form-label-title" style={{ fontSize: '11px' }}>URL Slug</label>
                  <input
                    type="text"
                    className="form-input-control"
                    placeholder="exotic-salads"
                    value={categoryForm.slug}
                    onChange={(e) => setCategoryForm({ ...categoryForm, slug: e.target.value })}
                  />
                </div>
              </div>

              <div style={{ marginBottom: '16px' }}>
                <label className="form-label-title" style={{ fontSize: '11px' }}>Description</label>
                <input
                  type="text"
                  className="form-input-control"
                  placeholder="Short description"
                  value={categoryForm.description}
                  onChange={(e) => setCategoryForm({ ...categoryForm, description: e.target.value })}
                />
              </div>

              <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end' }}>
                <button type="button" onClick={() => setIsCategoryModalOpen(false)} style={{ padding: '7px 14px', borderRadius: '6px', border: '1px solid #CBD5E1', fontSize: '12px' }}>
                  Cancel
                </button>
                <button type="submit" style={{ padding: '7px 18px', borderRadius: '6px', border: 'none', background: '#234B3C', color: '#FFF', fontWeight: 800, fontSize: '12px' }}>
                  Save Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD / EDIT PACKAGING UNIT (SIMPLIFIED: kg, tones, crate) */}
      {isUnitModalOpen && (
        <div className="admin-modal-overlay">
          <div className="admin-modal-card" style={{ maxWidth: '420px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Scale size={18} color="#234B3C" />
                <h3 style={{ fontSize: '16px', fontWeight: 800, margin: 0 }}>Packaging Unit Setup</h3>
              </div>
              <button type="button" onClick={() => setIsUnitModalOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748B' }}>
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveUnit}>
              <div style={{ marginBottom: '12px' }}>
                <label className="form-label-title" style={{ fontSize: '11px' }}>Unit Code / Short Form *</label>
                <input
                  type="text"
                  className="form-input-control"
                  placeholder="e.g. kg, tones, crate, pack"
                  value={unitForm.name}
                  onChange={(e) => setUnitForm({ ...unitForm, name: e.target.value })}
                  required
                />
                <span style={{ fontSize: '10.5px', color: '#64748B' }}>Enter standard unit abbreviation: kg, tones, crate, etc.</span>
              </div>

              <div style={{ marginBottom: '12px' }}>
                <label className="form-label-title" style={{ fontSize: '11px' }}>Display Label</label>
                <input
                  type="text"
                  className="form-input-control"
                  placeholder="e.g. Kilogram (kg), Metric Ton, Standard Crate"
                  value={unitForm.label}
                  onChange={(e) => setUnitForm({ ...unitForm, label: e.target.value })}
                />
              </div>

              <div style={{ marginBottom: '16px' }}>
                <label className="form-label-title" style={{ fontSize: '11px' }}>Operational Description</label>
                <input
                  type="text"
                  className="form-input-control"
                  placeholder="e.g. Standard 20kg APMC harvesting crate"
                  value={unitForm.description}
                  onChange={(e) => setUnitForm({ ...unitForm, description: e.target.value })}
                />
              </div>

              <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end' }}>
                <button type="button" onClick={() => setIsUnitModalOpen(false)} style={{ padding: '7px 14px', borderRadius: '6px', border: '1px solid #CBD5E1', fontSize: '12px' }}>
                  Cancel
                </button>
                <button type="submit" style={{ padding: '7px 18px', borderRadius: '6px', border: 'none', background: '#234B3C', color: '#FFF', fontWeight: 800, fontSize: '12px' }}>
                  Save Unit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
