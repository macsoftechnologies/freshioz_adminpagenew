import React, { useState } from 'react';
import { 
  Users, 
  UserPlus, 
  ShieldCheck, 
  Briefcase, 
  Building2, 
  Phone, 
  Mail, 
  Search, 
  Filter, 
  Download, 
  CheckCircle2, 
  XCircle, 
  Edit3, 
  Trash2, 
  X,
  Warehouse,
  Store,
  Truck,
  KeyRound,
  Link2,
  Copy
} from 'lucide-react';
import { useAdminRole, ROLES } from '../context/AdminRoleContext';
import { useToast } from '../context/ToastContext';
import { saveFreshiozStore } from '../shared/freshiozStore';
import { exportToExcel } from '../utils/excelExporter';

export default function EmployeeManagementPage() {
  const { store } = useAdminRole();
  const { showToast } = useToast();
  const employees = store.employees || [];
  const warehouses = store.warehouses || [];
  const shops = store.shops || [];

  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('ALL');
  const [facilityFilter, setFacilityFilter] = useState('ALL'); // 'ALL' | 'WAREHOUSE' | 'STORE'
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState(null);

  // Form Fields
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    roles: ['STORE_MANAGER'], // Multi-role support
    assignedWarehouseId: 'shop-1',
    assignedLocationType: 'STORE',
    assignedLocationName: 'Indiranagar Fresh Hub (Shop 1)',
    status: 'ACTIVE',
    authMethod: 'PASSWORD', // 'PASSWORD' | 'INVITE'
    password: 'admin123',
    inviteStatus: 'ACTIVE', // 'ACTIVE' | 'INVITED'
    inviteToken: '',
    notes: ''
  });

  const [formError, setFormError] = useState('');

  // Available operational roles (Including Store Managers and Delivery Executives)
  const AVAILABLE_ROLES = [
    { id: 'SUPER_ADMIN', label: 'Super Admin', desc: 'Full Master Platform Control & Executive Financial Reports', badgeColor: '#234B3C', isMain: true },
    { id: 'STORE_MANAGER', label: 'Store & Hub Manager', desc: 'In-charge of local micro-fulfillment store, local orders & customer desks', badgeColor: '#0284C7' },
    { id: 'DELIVERY_EXECUTIVE', label: 'Delivery Executive (Store)', desc: 'Morning society drop desk last-mile dispatch rider', badgeColor: '#EA580C' },
    { id: 'WAREHOUSE_MANAGER', label: 'Warehouse & Crating Manager', desc: 'Dawn sorting, crating lines, and central hub dispatch', badgeColor: '#059669' },
    { id: 'PROCUREMENT_OFFICER', label: 'Mandi Procurement Buyer', desc: 'Dawn APMC sourcing, vendor bills & APMC ledger', badgeColor: '#D97706' },
    { id: 'SALES_OFFICER', label: 'Field Sales Officer', desc: 'Society & hostel onboarding and GPS tagging', badgeColor: '#2563EB' }
  ];

  const handleCopyInviteLink = (emp) => {
    const token = emp.inviteToken || `inv-${emp.id}`;
    const url = `https://admin.freshioz.com/activate?token=${token}`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(url).catch(() => {});
    }
    showToast(`✓ Copied link for ${emp.name}: ${url}`, 'info');
  };

  const handleOpenAddModal = () => {
    setEditingEmployee(null);
    setFormData({
      name: '',
      phone: '',
      email: '',
      roles: ['STORE_MANAGER'],
      assignedWarehouseId: shops[0]?.id || warehouses[0]?.id || 'shop-1',
      assignedLocationType: 'STORE',
      assignedLocationName: shops[0]?.name || 'Indiranagar Fresh Hub (Shop 1)',
      status: 'ACTIVE',
      authMethod: 'PASSWORD',
      password: 'admin123',
      inviteStatus: 'ACTIVE',
      inviteToken: '',
      notes: ''
    });
    setFormError('');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (emp) => {
    setEditingEmployee(emp);
    setFormData({
      name: emp.name,
      phone: emp.phone,
      email: emp.email || '',
      roles: emp.roles || ['STORE_MANAGER'],
      assignedWarehouseId: emp.assignedWarehouseId || 'shop-1',
      assignedLocationType: emp.assignedLocationType || (emp.assignedWarehouseId?.startsWith('shop') ? 'STORE' : 'WAREHOUSE'),
      assignedLocationName: emp.assignedLocationName || '',
      status: emp.status || 'ACTIVE',
      authMethod: emp.authMethod || (emp.inviteStatus === 'INVITED' ? 'INVITE' : 'PASSWORD'),
      password: emp.password || 'admin123',
      inviteStatus: emp.inviteStatus || 'ACTIVE',
      inviteToken: emp.inviteToken || '',
      notes: emp.notes || ''
    });
    setFormError('');
    setIsModalOpen(true);
  };

  const toggleRoleSelection = (roleId) => {
    setFormData(prev => {
      const current = prev.roles || [];
      if (current.includes(roleId)) {
        if (current.length === 1) return prev; // Keep at least one role
        return { ...prev, roles: current.filter(r => r !== roleId) };
      } else {
        return { ...prev, roles: [...current, roleId] };
      }
    });
  };

  const handleSubmitForm = (e) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim()) {
      setFormError('Please enter employee name and contact phone number.');
      return;
    }

    if (!/^[6-9]\d{9}$/.test(formData.phone.trim())) {
      setFormError('Please enter a valid 10-digit Indian phone number.');
      return;
    }

    if (formData.roles.length === 0) {
      setFormError('Please select at least one operational role.');
      return;
    }

    // Determine location name & type
    let locName = 'All Hubs & Warehouses (Citywide)';
    let locType = 'ALL';

    if (formData.assignedWarehouseId !== 'ALL') {
      const wh = warehouses.find(w => w.id === formData.assignedWarehouseId);
      if (wh) {
        locName = wh.name;
        locType = 'WAREHOUSE';
      } else {
        const sh = shops.find(s => s.id === formData.assignedWarehouseId);
        if (sh) {
          locName = sh.name;
          locType = 'STORE';
        }
      }
    }

    const resolvedInviteStatus = formData.authMethod === 'INVITE' ? 'INVITED' : 'ACTIVE';
    const resolvedInviteToken = formData.authMethod === 'INVITE'
      ? (formData.inviteToken || `inv_${Math.random().toString(36).substring(2, 9)}_${Date.now().toString(36)}`)
      : null;
    const resolvedPassword = formData.authMethod === 'PASSWORD' ? (formData.password || 'admin123') : null;

    if (editingEmployee) {
      // Update existing
      saveFreshiozStore(prev => ({
        ...prev,
        employees: prev.employees.map(emp => emp.id === editingEmployee.id ? {
          ...emp,
          ...formData,
          inviteStatus: resolvedInviteStatus,
          inviteToken: resolvedInviteToken,
          password: resolvedPassword,
          assignedLocationType: locType,
          assignedLocationName: locName
        } : emp)
      }));
    } else {
      // Add new
      const newEmp = {
        id: `emp-${Date.now().toString().slice(-4)}`,
        ...formData,
        inviteStatus: resolvedInviteStatus,
        inviteToken: resolvedInviteToken,
        password: resolvedPassword,
        assignedLocationType: locType,
        assignedLocationName: locName,
        dateJoined: new Date().toISOString().slice(0, 10)
      };

      saveFreshiozStore(prev => ({
        ...prev,
        employees: [newEmp, ...(prev.employees || [])]
      }));
    }

    showToast(editingEmployee ? `Updated employee "${formData.name}"` : `Added new employee "${formData.name}"`, 'success');
    setIsModalOpen(false);
  };

  const handleToggleStatus = (empId) => {
    saveFreshiozStore(prev => ({
      ...prev,
      employees: prev.employees.map(e => e.id === empId ? {
        ...e,
        status: e.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE'
      } : e)
    }));
    showToast('Employee account status updated', 'info');
  };

  const handleDeleteEmployee = (empId) => {
    if (confirm('Are you sure you want to remove this employee from the directory?')) {
      saveFreshiozStore(prev => ({
        ...prev,
        employees: prev.employees.filter(e => e.id !== empId)
      }));
      showToast('Employee removed from directory', 'info');
    }
  };

  // Export to Excel
  const handleExportExcel = () => {
    const headers = [
      'Employee ID',
      'Name',
      'Phone',
      'Email',
      'Primary Role',
      'All Assigned Roles',
      'Facility Type (Store/Warehouse)',
      'Assigned Location Name',
      'Account Status',
      'Date Joined',
      'Notes'
    ];

    const rows = employees.map(e => [
      e.id,
      e.name,
      e.phone,
      e.email || 'N/A',
      e.roles?.includes('SUPER_ADMIN') ? 'SUPER ADMIN (Main Executive)' : (e.roles?.[0] || 'N/A'),
      e.roles?.join(', ') || 'N/A',
      e.assignedLocationType || (e.assignedWarehouseId?.startsWith('shop') ? 'STORE' : 'WAREHOUSE'),
      e.assignedLocationName,
      e.status,
      e.dateJoined,
      e.notes || ''
    ]);

    exportToExcel('Freshioz_Staff_Directory_Warehouse_And_Store', headers, rows);
  };

  // Filtered List
  const filteredEmployees = employees.filter(emp => {
    const matchesQuery = 
      emp.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      emp.phone?.includes(searchQuery) ||
      emp.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      emp.assignedLocationName?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesRole = roleFilter === 'ALL' || (emp.roles && emp.roles.includes(roleFilter));
    const matchesStatus = statusFilter === 'ALL' || emp.status === statusFilter;

    const empType = emp.assignedLocationType || (emp.assignedWarehouseId?.startsWith('shop') ? 'STORE' : emp.assignedWarehouseId === 'ALL' ? 'ALL' : 'WAREHOUSE');
    const matchesFacility = 
      facilityFilter === 'ALL' ||
      (facilityFilter === 'STORE' && empType === 'STORE') ||
      (facilityFilter === 'WAREHOUSE' && (empType === 'WAREHOUSE' || empType === 'ALL'));

    return matchesQuery && matchesRole && matchesStatus && matchesFacility;
  });

  return (
    <div className="admin-page-container">
      {/* High-Density Compact Page Header (Under 55px) */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '8px',
        paddingBottom: '10px',
        borderBottom: '1.5px solid #E2E8F0',
        marginBottom: '12px'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
            <h1 style={{ fontSize: '18px', color: '#0F172A', fontWeight: 800, margin: 0 }}>
              Employee Management & Roles
            </h1>
            <span style={{ background: '#E0F2FE', color: '#0369A1', fontSize: '11px', fontWeight: 800, padding: '2px 8px', borderRadius: '4px' }}>
              {employees.length} Personnel
            </span>
          </div>

          {/* Compact Inline Role Breakdown Strip (Replaced 5 bulky cards!) */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '11.5px', color: '#64748B', marginTop: '3px', flexWrap: 'wrap' }}>
            <span>• Active: <strong style={{ color: '#059669' }}>{employees.filter(e => e.status === 'ACTIVE').length}</strong></span>
            <span>• 👑 Super Admin: <strong>{employees.filter(e => e.roles?.includes('SUPER_ADMIN')).length}</strong></span>
            <span>• Store Staff: <strong>{employees.filter(e => e.roles?.some(r => ['STORE_MANAGER', 'DELIVERY_EXECUTIVE'].includes(r))).length}</strong></span>
            <span>• WH Leads: <strong>{employees.filter(e => e.roles?.includes('WAREHOUSE_MANAGER')).length}</strong></span>
            <span>• APMC Mandi/Sales: <strong>{employees.filter(e => e.roles?.some(r => ['PROCUREMENT_OFFICER', 'SALES_OFFICER'].includes(r))).length}</strong></span>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <button
            type="button"
            onClick={handleExportExcel}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '5px',
              padding: '6px 12px',
              borderRadius: '6px',
              background: '#FFFFFF',
              border: '1.5px solid #CBD5E1',
              color: '#334155',
              fontWeight: 700,
              fontSize: '12px',
              cursor: 'pointer'
            }}
          >
            <Download size={13} />
            <span>Export Excel</span>
          </button>

          <button
            type="button"
            onClick={handleOpenAddModal}
            className="admin-btn-accent"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', padding: '6px 14px', fontSize: '12px' }}
          >
            <UserPlus size={14} />
            <span>Add Employee</span>
          </button>
        </div>
      </div>

      {/* High-Density Search & Filter Bar */}
      <div style={{
        background: '#FFFFFF',
        borderRadius: '12px',
        border: '1px solid #E2E8F0',
        padding: '12px 16px',
        marginBottom: '18px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '12px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flex: 1, minWidth: '240px' }}>
          <Search size={16} color="#64748B" />
          <input
            type="text"
            placeholder="Search by name, phone, store, warehouse, or role..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{ width: '100%', border: 'none', outline: 'none', fontSize: '13px', color: '#0F172A' }}
          />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
          {/* Facility Type Filter */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: '#64748B' }}>
            <span>Facility:</span>
            <select
              value={facilityFilter}
              onChange={(e) => setFacilityFilter(e.target.value)}
              style={{ border: '1px solid #CBD5E1', borderRadius: '6px', padding: '5px 8px', fontSize: '12px', background: '#FFF' }}
            >
              <option value="ALL">All Facilities</option>
              <option value="STORE">🏪 Stores & Riders ({employees.filter(e => (e.assignedLocationType === 'STORE' || e.assignedWarehouseId?.startsWith('shop'))).length})</option>
              <option value="WAREHOUSE">🏢 Central Warehouses ({employees.filter(e => (!e.assignedLocationType || e.assignedLocationType === 'WAREHOUSE' || e.assignedWarehouseId?.startsWith('wh') || e.assignedWarehouseId === 'ALL')).length})</option>
            </select>
          </div>

          {/* Role Filter */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: '#64748B' }}>
            <Filter size={13} />
            <span>Role:</span>
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              style={{ border: '1px solid #CBD5E1', borderRadius: '6px', padding: '5px 8px', fontSize: '12px', background: '#FFF' }}
            >
              <option value="ALL">All Roles</option>
              <option value="SUPER_ADMIN">👑 Super Admin (Main)</option>
              <option value="STORE_MANAGER">🏪 Store Managers</option>
              <option value="DELIVERY_EXECUTIVE">🚚 Delivery Executives</option>
              <option value="WAREHOUSE_MANAGER">🏢 Warehouse Managers</option>
              <option value="PROCUREMENT_OFFICER">🌾 Mandi Procurement</option>
              <option value="SALES_OFFICER">📋 Field Sales</option>
            </select>
          </div>

          {/* Status Filter */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: '#64748B' }}>
            <span>Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              style={{ border: '1px solid #CBD5E1', borderRadius: '6px', padding: '5px 8px', fontSize: '12px', background: '#FFF' }}
            >
              <option value="ALL">All Status</option>
              <option value="ACTIVE">Active</option>
              <option value="INACTIVE">Inactive</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Enterprise Staff Data Table */}
      <div className="admin-table-card">
        <div style={{ overflowX: 'auto' }}>
          <table className="admin-data-table">
            <thead>
              <tr>
                <th>Staff Name & Contact</th>
                <th>Assigned Roles (Multi-Role)</th>
                <th>Assigned Store / Warehouse Facility</th>
                <th>Status & Auth</th>
                <th>Joined Date</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredEmployees.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: 'center', padding: '36px', color: '#64748B' }}>
                    No employees matching the selected criteria.
                  </td>
                </tr>
              ) : (
                filteredEmployees.map(emp => {
                  const isStorePerson = emp.assignedLocationType === 'STORE' || emp.assignedWarehouseId?.startsWith('shop');
                  const isCitywide = emp.assignedWarehouseId === 'ALL';

                  return (
                    <tr key={emp.id}>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <div style={{
                            width: '36px',
                            height: '36px',
                            borderRadius: '50%',
                            background: emp.roles?.includes('SUPER_ADMIN') ? '#234B3C' : isStorePerson ? '#0284C7' : '#475569',
                            color: '#FFFFFF',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontWeight: 800,
                            fontSize: '13px',
                            flexShrink: 0
                          }}>
                            {emp.name?.[0]?.toUpperCase()}
                          </div>
                          <div>
                            <strong style={{ fontSize: '13.5px', color: '#0F172A' }}>{emp.name}</strong>
                            <div style={{ fontSize: '11.5px', color: '#64748B', display: 'flex', alignItems: 'center', gap: '8px', marginTop: '1px' }}>
                              <span>+91 {emp.phone}</span>
                              {emp.email && <span>• {emp.email}</span>}
                            </div>
                          </div>
                        </div>
                      </td>

                      <td>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px' }}>
                          {[...(emp.roles || [])].sort((a, b) => (a === 'SUPER_ADMIN' ? -1 : b === 'SUPER_ADMIN' ? 1 : 0)).map(roleId => {
                            const roleDef = AVAILABLE_ROLES.find(r => r.id === roleId) || { label: roleId, badgeColor: '#64748B' };
                            const isSuper = roleId === 'SUPER_ADMIN';

                            return (
                              <span
                                key={roleId}
                                style={{
                                  display: 'inline-flex',
                                  alignItems: 'center',
                                  gap: '4px',
                                  background: isSuper ? '#234B3C' : '#F8FAFC',
                                  color: isSuper ? '#FFFFFF' : roleDef.badgeColor,
                                  border: isSuper ? '1px solid #19352A' : `1px solid ${roleDef.badgeColor}35`,
                                  fontSize: '11px',
                                  fontWeight: 800,
                                  padding: '2px 8px',
                                  borderRadius: '6px'
                                }}
                              >
                                {isSuper ? (
                                  <>
                                    <span>👑</span>
                                    <span>Super Admin (Main)</span>
                                  </>
                                ) : (
                                  <>
                                    {roleId === 'STORE_MANAGER' && <span>🏪</span>}
                                    {roleId === 'DELIVERY_EXECUTIVE' && <span>🚚</span>}
                                    {roleId === 'WAREHOUSE_MANAGER' && <span>🏢</span>}
                                    {roleId === 'PROCUREMENT_OFFICER' && <span>🌾</span>}
                                    {roleId === 'SALES_OFFICER' && <span>📋</span>}
                                    <span>{roleDef.label}</span>
                                  </>
                                )}
                              </span>
                            );
                          })}
                        </div>
                      </td>

                      <td>
                        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', fontSize: '12.5px', color: '#1E293B', fontWeight: 700 }}>
                          {isStorePerson ? (
                            <span style={{ color: '#0284C7', background: '#E0F2FE', padding: '2px 6px', borderRadius: '4px', fontSize: '11px', fontWeight: 800 }}>
                              🏪 STORE
                            </span>
                          ) : isCitywide ? (
                            <span style={{ color: '#234B3C', background: '#DCFCE7', padding: '2px 6px', borderRadius: '4px', fontSize: '11px', fontWeight: 800 }}>
                              🌐 CITYWIDE
                            </span>
                          ) : (
                            <span style={{ color: '#059669', background: '#ECFDF5', padding: '2px 6px', borderRadius: '4px', fontSize: '11px', fontWeight: 800 }}>
                              🏢 WAREHOUSE
                            </span>
                          )}
                          <span>{emp.assignedLocationName}</span>
                        </div>
                        {emp.notes && (
                          <div style={{ fontSize: '11px', color: '#64748B', marginTop: '2px' }}>
                            {emp.notes}
                          </div>
                        )}
                      </td>

                      <td>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                          <button
                            type="button"
                            onClick={() => handleToggleStatus(emp.id)}
                            style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, textAlign: 'left' }}
                            title="Click to toggle status"
                          >
                            <span className={`status-pill ${emp.status === 'ACTIVE' ? 'approved' : 'rejected'}`}>
                              {emp.status}
                            </span>
                          </button>
                          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', marginTop: '2px' }}>
                            {emp.inviteStatus === 'INVITED' ? (
                              <span style={{
                                background: '#FEF3C7',
                                color: '#B45309',
                                fontSize: '10px',
                                fontWeight: 700,
                                padding: '1px 6px',
                                borderRadius: '4px',
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '3px'
                              }}>
                                <Mail size={9} />
                                <span>Invited</span>
                              </span>
                            ) : (
                              <span style={{
                                background: '#ECFDF5',
                                color: '#047857',
                                fontSize: '10px',
                                fontWeight: 700,
                                padding: '1px 6px',
                                borderRadius: '4px',
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '3px'
                              }}>
                                <KeyRound size={9} />
                                <span>Pass Set</span>
                              </span>
                            )}
                            <button
                              type="button"
                              onClick={() => handleCopyInviteLink(emp)}
                              style={{
                                background: '#F1F5F9',
                                border: '1px solid #CBD5E1',
                                borderRadius: '4px',
                                padding: '1px 5px',
                                fontSize: '10px',
                                color: '#334155',
                                fontWeight: 700,
                                cursor: 'pointer',
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '2px'
                              }}
                              title="Copy activation or login link"
                            >
                              <Copy size={9} />
                              <span>Link</span>
                            </button>
                          </div>
                        </div>
                      </td>

                      <td style={{ fontSize: '12px', color: '#64748B' }}>
                        {emp.dateJoined || '2026-02-01'}
                      </td>

                      <td style={{ textAlign: 'right' }}>
                        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                          <button
                            type="button"
                            onClick={() => handleOpenEditModal(emp)}
                            style={{
                              background: '#F8FAFC',
                              border: '1px solid #CBD5E1',
                              padding: '5px 9px',
                              borderRadius: '6px',
                              cursor: 'pointer',
                              color: '#334155',
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '4px',
                              fontSize: '12px',
                              fontWeight: 700
                            }}
                            title="Edit staff member"
                          >
                            <Edit3 size={12} />
                            <span>Edit</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDeleteEmployee(emp.id)}
                            style={{
                              background: '#FFF1F2',
                              border: '1px solid #FECDD3',
                              padding: '5px 8px',
                              borderRadius: '6px',
                              cursor: 'pointer',
                              color: '#E11D48'
                            }}
                            title="Remove staff member"
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Employee Modal */}
      {isModalOpen && (
        <div className="admin-modal-overlay">
          <div className="admin-modal-card">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '18px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{ width: '38px', height: '38px', borderRadius: '8px', background: '#234B3C', color: '#FFF', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Users size={20} />
                </div>
                <div>
                  <h3 style={{ fontSize: '18px', fontWeight: 800, color: '#0F172A', margin: 0 }}>
                    {editingEmployee ? 'Edit Staff Member' : 'Register Operational Staff'}
                  </h3>
                  <div style={{ fontSize: '12px', color: '#64748B' }}>
                    Assign multiple roles and link to either a Central Warehouse or a Hub Store
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748B' }}
              >
                <X size={20} />
              </button>
            </div>

            {formError && (
              <div style={{ background: '#FEE2E2', border: '1px solid #FCA5A5', color: '#B91C1C', padding: '10px 14px', borderRadius: '8px', fontSize: '12.5px', marginBottom: '16px' }}>
                {formError}
              </div>
            )}

            <form onSubmit={handleSubmitForm}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '14px' }}>
                <div>
                  <label className="form-label-title">Full Name *</label>
                  <input
                    type="text"
                    className="form-input-control"
                    placeholder="e.g. Ramesh Kumar"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label className="form-label-title">Phone Number (10 Digits) *</label>
                  <input
                    type="tel"
                    className="form-input-control"
                    placeholder="e.g. 9845012345"
                    value={formData.phone}
                    maxLength={10}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value.replace(/\D/g, '').slice(0, 10) })}
                    required
                  />
                </div>
              </div>

              <div style={{ marginBottom: '14px' }}>
                <label className="form-label-title">Email Address</label>
                <input
                  type="email"
                  className="form-input-control"
                  placeholder="e.g. ramesh@freshioz.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
              </div>

              {/* Multi-Role Assignment Checkboxes */}
              <div style={{ marginBottom: '16px' }}>
                <label className="form-label-title" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span>Assign Operational Roles * (Multi-Role Allowed)</span>
                  <span style={{ fontSize: '11px', color: '#0369A1', fontWeight: 700 }}>Select all that apply</span>
                </label>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '6px' }}>
                  {AVAILABLE_ROLES.map(role => {
                    const isSelected = formData.roles?.includes(role.id);
                    return (
                      <div
                        key={role.id}
                        onClick={() => toggleRoleSelection(role.id)}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          padding: '10px 14px',
                          borderRadius: '10px',
                          border: isSelected ? '1.5px solid #234B3C' : '1px solid #E2E8F0',
                          background: isSelected ? '#F0F7F4' : '#FFFFFF',
                          cursor: 'pointer',
                          transition: 'all 0.15s ease'
                        }}
                      >
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => {}}
                          style={{ cursor: 'pointer', accentColor: '#234B3C', width: '16px', height: '16px' }}
                        />
                        <div style={{ flex: 1 }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <span style={{ fontSize: '13px', fontWeight: 800, color: '#0F172A' }}>{role.label}</span>
                            {role.isMain && (
                              <span style={{ background: '#234B3C', color: '#FFF', fontSize: '10px', fontWeight: 800, padding: '1px 6px', borderRadius: '4px' }}>
                                MAIN ROLE
                              </span>
                            )}
                          </div>
                          <div style={{ fontSize: '11.5px', color: '#64748B', marginTop: '1px' }}>
                            {role.desc}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Assigned Facility (Warehouse or Store) */}
              <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 0.8fr', gap: '14px', marginBottom: '14px' }}>
                <div>
                  <label className="form-label-title">Assigned Facility (Store or Warehouse)</label>
                  <select
                    className="form-input-control"
                    value={formData.assignedWarehouseId}
                    onChange={(e) => setFormData({ ...formData, assignedWarehouseId: e.target.value })}
                  >
                    <optgroup label="Citywide Access">
                      <option value="ALL">🌐 All Hubs & Warehouses (Citywide)</option>
                    </optgroup>
                    <optgroup label="Hub Stores (Store People / Last-Mile)">
                      {shops.map(sh => (
                        <option key={sh.id} value={sh.id}>
                          🏪 {sh.name}
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label="Central Warehouses">
                      {warehouses.map(wh => (
                        <option key={wh.id} value={wh.id}>
                          🏢 {wh.name} ({wh.code || wh.id})
                        </option>
                      ))}
                    </optgroup>
                  </select>
                </div>

                <div>
                  <label className="form-label-title">Status</label>
                  <select
                    className="form-input-control"
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  >
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="INACTIVE">INACTIVE</option>
                  </select>
                </div>
              </div>

              {/* Account Password & Activation Invite Flow */}
              <div style={{ marginBottom: '16px', background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: '10px', padding: '12px 14px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <label className="form-label-title" style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <KeyRound size={14} color="#234B3C" />
                    <span>Portal Login Authentication *</span>
                  </label>
                  <span style={{ fontSize: '11px', color: '#64748B' }}>Store Hub & Rider desks</span>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, authMethod: 'PASSWORD' })}
                    style={{
                      padding: '8px 10px',
                      borderRadius: '6px',
                      border: formData.authMethod === 'PASSWORD' ? '1.5px solid #234B3C' : '1px solid #CBD5E1',
                      background: formData.authMethod === 'PASSWORD' ? '#EBF2EE' : '#FFF',
                      color: formData.authMethod === 'PASSWORD' ? '#234B3C' : '#475569',
                      fontWeight: 700,
                      fontSize: '12px',
                      cursor: 'pointer',
                      textAlign: 'center'
                    }}
                  >
                    🔑 Set Direct Password
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, authMethod: 'INVITE' })}
                    style={{
                      padding: '8px 10px',
                      borderRadius: '6px',
                      border: formData.authMethod === 'INVITE' ? '1.5px solid #234B3C' : '1px solid #CBD5E1',
                      background: formData.authMethod === 'INVITE' ? '#EBF2EE' : '#FFF',
                      color: formData.authMethod === 'INVITE' ? '#234B3C' : '#475569',
                      fontWeight: 700,
                      fontSize: '12px',
                      cursor: 'pointer',
                      textAlign: 'center'
                    }}
                  >
                    📧 Send Invite Link
                  </button>
                </div>

                {formData.authMethod === 'PASSWORD' ? (
                  <div style={{ marginTop: '10px' }}>
                    <label style={{ fontSize: '11.5px', color: '#475569', fontWeight: 700 }}>
                      Portal Login Password
                    </label>
                    <input
                      type="text"
                      className="form-input-control"
                      placeholder="e.g. admin123"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      style={{ marginTop: '4px' }}
                    />
                    <div style={{ fontSize: '11px', color: '#64748B', marginTop: '3px' }}>
                      Staff can log in immediately using their phone/email and this password.
                    </div>
                  </div>
                ) : (
                  <div style={{ marginTop: '10px', background: '#F0F9FF', border: '1px solid #BAE6FD', borderRadius: '6px', padding: '8px 10px', fontSize: '11.5px', color: '#0369A1' }}>
                    An activation invite link will be issued. The staff member can verify their phone and choose a password on first login.
                  </div>
                )}
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label className="form-label-title">Operations Notes / Scope</label>
                <input
                  type="text"
                  className="form-input-control"
                  placeholder="e.g. In charge of Indiranagar morning dispatch and flat delivery"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                />
              </div>

              <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  style={{
                    padding: '10px 18px',
                    borderRadius: '8px',
                    border: '1.5px solid #CBD5E1',
                    background: '#F8FAFC',
                    color: '#64748B',
                    fontWeight: 700,
                    fontSize: '13px',
                    cursor: 'pointer'
                  }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  style={{
                    padding: '10px 22px',
                    borderRadius: '8px',
                    border: 'none',
                    background: '#234B3C',
                    color: '#FFF',
                    fontWeight: 800,
                    fontSize: '13px',
                    cursor: 'pointer'
                  }}
                >
                  {editingEmployee ? 'Update Staff Member' : 'Save Employee'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
