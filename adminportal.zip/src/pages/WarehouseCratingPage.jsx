import React from 'react';
import { ClipboardList, CheckCircle2, Truck, PackageCheck, Building2 } from 'lucide-react';
import { useAdminRole } from '../context/AdminRoleContext';
import { useToast } from '../context/ToastContext';
import { saveFreshiozStore } from '../shared/freshiozStore';

export default function WarehouseCratingPage() {
  const { store } = useAdminRole();
  const { showToast } = useToast();

  const orders = store.orders || [];

  const handleMarkCrated = (orderId) => {
    saveFreshiozStore(prev => ({
      ...prev,
      orders: prev.orders.map(o => o.id === orderId ? { ...o, status: 'PACKED' } : o)
    }));
    showToast(`Order #${orderId} marked crated & tagged for delivery!`, 'success');
  };

  const handleDispatch = (orderId) => {
    saveFreshiozStore(prev => ({
      ...prev,
      orders: prev.orders.map(o => o.id === orderId ? { ...o, status: 'OUT_FOR_DELIVERY' } : o)
    }));
    showToast(`Order #${orderId} dispatched on morning delivery route!`, 'info');
  };

  return (
    <div className="admin-page-container">
      {/* Compact Page Title & Stats */}
      <div className="page-title-header" style={{ marginBottom: '12px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
          <div>
            <h1 style={{ fontSize: '18px', fontWeight: 800, color: '#0F172A', margin: 0 }}>
              Warehouse Crating & Flat Packing Desk
            </h1>
            <p style={{ fontSize: '12px', color: '#64748B', margin: '2px 0 0' }}>
              Pack customer retail bags, apply society flat tags, and load into morning delivery crates
            </p>
          </div>

          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
            <span style={{ fontSize: '11.5px', background: '#E2E8F0', color: '#334155', padding: '3px 10px', borderRadius: '6px', fontWeight: 700 }}>
              Total Orders: {orders.length}
            </span>
            <span style={{ fontSize: '11.5px', background: '#FEF3C7', color: '#B45309', padding: '3px 10px', borderRadius: '6px', fontWeight: 700 }}>
              To Pack: {orders.filter(o => o.status === 'CONFIRMED' || o.status === 'PROCURING').length}
            </span>
            <span style={{ fontSize: '11.5px', background: '#EBF2EE', color: '#234B3C', padding: '3px 10px', borderRadius: '6px', fontWeight: 700 }}>
              Ready for Route: {orders.filter(o => o.status === 'PACKED').length}
            </span>
          </div>
        </div>
      </div>

      {/* Crating Table */}
      <div className="admin-table-card">
        <div style={{ overflowX: 'auto' }}>
          <table className="admin-data-table">
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Society & Flat</th>
                <th>Recipient / Contact</th>
                <th>Items to Pack</th>
                <th>Total (₹)</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Packing Action</th>
              </tr>
            </thead>
            <tbody>
              {orders.length === 0 ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '36px 16px', color: '#64748B' }}>
                    No orders scheduled for crating.
                  </td>
                </tr>
              ) : (
                orders.map(order => (
                  <tr key={order.id}>
                    <td>
                      <strong style={{ fontFamily: 'monospace', color: '#0F172A', fontSize: '12.5px' }}>
                        #{order.id}
                      </strong>
                    </td>
                    <td>
                      <div style={{ fontWeight: 700, color: '#0F172A', fontSize: '13px' }}>{order.societyName}</div>
                      <span style={{ fontSize: '11px', background: '#EBF2EE', color: '#234B3C', fontWeight: 800, padding: '1px 6px', borderRadius: '4px', display: 'inline-block', marginTop: '2px' }}>
                        Flat: {order.flatNo}
                      </span>
                    </td>
                    <td>
                      <div style={{ fontSize: '12.5px', fontWeight: 600, color: '#0F172A' }}>{order.userName}</div>
                      <div style={{ fontSize: '11px', color: '#64748B' }}>+91 {order.userPhone}</div>
                    </td>
                    <td>
                      <div style={{ fontSize: '12px', color: '#1E293B', maxWidth: '320px' }}>
                        {order.items.map((i, idx) => (
                          <span key={idx} style={{ display: 'inline-block', marginRight: '6px' }}>
                            • {i.name} <strong>({i.qty} {i.unit})</strong>
                          </span>
                        ))}
                      </div>
                    </td>
                    <td>
                      <strong style={{ fontSize: '13px', color: '#234B3C' }}>
                        ₹{order.totalAmount}
                      </strong>
                    </td>
                    <td>
                      <span className={`status-pill ${order.status.toLowerCase()}`}>
                        {order.status}
                      </span>
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      {order.status === 'CONFIRMED' || order.status === 'PROCURING' ? (
                        <button
                          type="button"
                          onClick={() => handleMarkCrated(order.id)}
                          style={{
                            background: '#234B3C',
                            color: '#FFF',
                            fontSize: '11.5px',
                            fontWeight: 700,
                            padding: '6px 12px',
                            borderRadius: '6px',
                            border: 'none',
                            cursor: 'pointer',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '4px'
                          }}
                        >
                          <PackageCheck size={14} />
                          <span>Mark Crated</span>
                        </button>
                      ) : order.status === 'PACKED' ? (
                        <button
                          type="button"
                          onClick={() => handleDispatch(order.id)}
                          style={{
                            background: '#F28E14',
                            color: '#FFF',
                            fontSize: '11.5px',
                            fontWeight: 700,
                            padding: '6px 12px',
                            borderRadius: '6px',
                            border: 'none',
                            cursor: 'pointer',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '4px'
                          }}
                        >
                          <Truck size={14} />
                          <span>Dispatch Route</span>
                        </button>
                      ) : (
                        <span style={{ fontSize: '11.5px', color: '#059669', fontWeight: 800, background: '#ECFDF5', padding: '4px 8px', borderRadius: '6px' }}>
                          ✓ {order.status}
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
