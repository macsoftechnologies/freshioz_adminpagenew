import React, { useState } from 'react';
import { 
  Truck, 
  Warehouse, 
  CheckCircle2, 
  Clock, 
  Package, 
  Search, 
  Filter, 
  Download, 
  Building2, 
  User, 
  Eye, 
  X, 
  AlertCircle,
  Layers,
  ChevronRight,
  ArrowRight
} from 'lucide-react';
import { useAdminRole } from '../context/AdminRoleContext';
import { useToast } from '../context/ToastContext';
import { saveFreshiozStore } from '../shared/freshiozStore';
import { exportToExcel } from '../utils/excelExporter';

export default function OrdersFulfillmentPage() {
  const { store } = useAdminRole();
  const { showToast } = useToast();
  const orders = store.orders || [];
  const societies = store.societies || [];
  const warehouses = store.warehouses || [];

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [societyFilter, setSocietyFilter] = useState('ALL');
  const [warehouseFilter, setWarehouseFilter] = useState('ALL');

  // Society Batch Update State
  const [batchSociety, setBatchSociety] = useState(societies[0]?.name || '');
  const [batchTargetStatus, setBatchTargetStatus] = useState('AT_WAREHOUSE');

  // Order Details Modal
  const [selectedOrder, setSelectedOrder] = useState(null);

  // Status definitions & badges (Unified canonical lifecycle)
  const STATUS_CONFIG = {
    CONFIRMED: { label: 'Confirmed', badgeClass: 'pending', desc: 'Order locked at 9 PM cutoff', color: '#6366F1' },
    PROCURING: { label: 'Procuring at Mandi', badgeClass: 'in-progress', desc: 'Sourcing at APMC Yard 4:30 AM', color: '#D97706' },
    AT_WAREHOUSE: { label: 'At Warehouse', badgeClass: 'approved', desc: 'Arrived at hub for sorting', color: '#0284C7' },
    PACKED: { label: 'Packed & Crated', badgeClass: 'approved', desc: 'Quality checked, flat-tagged & loaded in crate', color: '#10B981' },
    OUT_FOR_DELIVERY: { label: 'Out for Delivery', badgeClass: 'in-progress', desc: 'Dispatched to society drop desk', color: '#F28E14' },
    DELIVERED: { label: 'Delivered', badgeClass: 'approved', desc: 'Secured at society drop desk', color: '#059669' },
    CANCELLED: { label: 'Cancelled', badgeClass: 'rejected', desc: 'Order voided / refunded', color: '#DC2626' }
  };

  // Status counts
  const countConfirmed = orders.filter(o => (o.status || 'CONFIRMED') === 'CONFIRMED').length;
  const countProcuring = orders.filter(o => o.status === 'PROCURING').length;
  const countWarehouse = orders.filter(o => o.status === 'AT_WAREHOUSE').length;
  const countPacked = orders.filter(o => o.status === 'PACKED').length;
  const countOut = orders.filter(o => o.status === 'OUT_FOR_DELIVERY').length;
  const countDelivered = orders.filter(o => o.status === 'DELIVERED').length;

  // Single Order Status Change (Accrues society commission strictly when becoming DELIVERED)
  const handleUpdateOrderStatus = (orderId, newStatus) => {
    saveFreshiozStore(prev => {
      const targetOrder = (prev.orders || []).find(o => o.id === orderId);
      const isNewlyDelivered = newStatus === 'DELIVERED' && targetOrder?.status !== 'DELIVERED';
      const commEarned = (isNewlyDelivered && targetOrder?.societyCommissionEarned) ? targetOrder.societyCommissionEarned : 0;

      const updatedSocieties = isNewlyDelivered ? (prev.societies || []).map(s => {
        if (s.id === targetOrder?.societyId || s.name === targetOrder?.societyName) {
          return {
            ...s,
            balanceEarned: Number(((s.balanceEarned || 0) + commEarned).toFixed(2)),
            totalOrdersDelivered: (s.totalOrdersDelivered || 0) + 1
          };
        }
        return s;
      }) : prev.societies;

      return {
        ...prev,
        societies: updatedSocieties,
        orders: prev.orders.map(o => o.id === orderId ? {
          ...o,
          status: newStatus,
          lastStatusUpdate: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          deliveredAt: newStatus === 'DELIVERED' ? new Date().toISOString() : o.deliveredAt
        } : o)
      };
    });

    if (newStatus === 'DELIVERED') {
      showToast(`Order #${orderId} marked DELIVERED! Society commission credited to community wallet.`, 'success');
    } else {
      showToast(`Order #${orderId} status set to ${newStatus}`);
    }
  };

  // Society Batch Update Handler (Accrues commissions on batch DELIVERED)
  const handleBatchUpdateSociety = (e) => {
    e.preventDefault();
    if (!batchSociety) return;

    let updatedCount = 0;
    saveFreshiozStore(prev => {
      let batchCommissionAccrued = 0;
      let newlyDeliveredCount = 0;

      const updatedOrders = prev.orders.map(o => {
        if (o.societyName === batchSociety) {
          updatedCount++;
          if (batchTargetStatus === 'DELIVERED' && o.status !== 'DELIVERED') {
            batchCommissionAccrued += (o.societyCommissionEarned || 0);
            newlyDeliveredCount++;
          }
          return {
            ...o,
            status: batchTargetStatus,
            lastStatusUpdate: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            deliveredAt: batchTargetStatus === 'DELIVERED' ? new Date().toISOString() : o.deliveredAt
          };
        }
        return o;
      });

      const updatedSocieties = (batchTargetStatus === 'DELIVERED' && newlyDeliveredCount > 0) ? prev.societies.map(s => {
        if (s.name === batchSociety) {
          return {
            ...s,
            balanceEarned: Number(((s.balanceEarned || 0) + batchCommissionAccrued).toFixed(2)),
            totalOrdersDelivered: (s.totalOrdersDelivered || 0) + newlyDeliveredCount
          };
        }
        return s;
      }) : prev.societies;

      return {
        ...prev,
        societies: updatedSocieties,
        orders: updatedOrders
      };
    });

    showToast(`Batch Update: Set ${updatedCount} orders for "${batchSociety}" to ${batchTargetStatus}!`, 'success');
  };

  // Export Delivery Manifest Excel
  const handleExportManifestExcel = () => {
    const headers = [
      'Order ID',
      'Placed At',
      'Customer Name',
      'Contact Phone',
      'Society / Community',
      'Flat / Door No',
      'Items Breakdown',
      'Total Items',
      'Order Total (₹)',
      'Payment Mode',
      'Fulfillment Warehouse',
      'Current Status'
    ];

    const rows = filteredOrders.map(o => [
      o.id,
      o.createdAt || 'Today 8:45 PM',
      o.userName || o.customerName || 'Resident',
      o.userPhone || '+91 98450 11999',
      o.societyName || 'Greenfield Heights',
      o.flatNumber || 'T-402',
      (o.items || []).map(i => `${i.name || i.productName} (${i.quantity || 1}x)`).join('; '),
      (o.items || []).length,
      o.totalAmount || 0,
      o.paymentMethod || 'UPI / Prepaid',
      o.warehouseCode || 'WH-BLR-NORTH',
      o.status || 'CONFIRMED'
    ]);

    exportToExcel('Freshioz_Morning_Delivery_Manifest', headers, rows);
  };

  // Filtered Orders
  const filteredOrders = orders.filter(o => {
    const currentStatus = o.status || 'CONFIRMED';
    const matchesSearch = 
      o.id?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.userName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.societyName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.flatNumber?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'ALL' || currentStatus === statusFilter;
    const matchesSociety = societyFilter === 'ALL' || o.societyName === societyFilter;

    return matchesSearch && matchesStatus && matchesSociety;
  });

  return (
    <div className="admin-page-container">
      {/* High-Density Compact Page Header (Under 50px) */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '8px',
        paddingBottom: '10px',
        borderBottom: '1.5px solid #E2E8F0',
        marginBottom: '10px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <h1 style={{ fontSize: '18px', color: '#0F172A', fontWeight: 800, margin: 0 }}>
            Order Fulfillment Pipeline
          </h1>
          <span style={{ fontSize: '11px', background: '#E0F2FE', color: '#0369A1', fontWeight: 800, padding: '2px 8px', borderRadius: '4px' }}>
            {orders.length} Orders Active
          </span>
        </div>

        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <button
            type="button"
            onClick={handleExportManifestExcel}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '5px',
              padding: '6px 12px',
              borderRadius: '6px',
              background: '#FFFFFF',
              border: '1.5px solid #CBD5E1',
              color: '#334155',
              fontWeight: 700,
              fontSize: '12px',
              cursor: 'pointer'
            }}
          >
            <Download size={13} />
            <span>Export Delivery Manifest</span>
          </button>
        </div>
      </div>

      {/* Slim Horizontal Pipeline Stages Pill Bar (Replaced 180px bulky box!) */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: '6px',
        overflowX: 'auto',
        paddingBottom: '4px',
        marginBottom: '10px'
      }}>
        <button
          type="button"
          onClick={() => setStatusFilter('ALL')}
          style={{
            padding: '5px 12px',
            borderRadius: '6px',
            fontSize: '11.5px',
            fontWeight: 800,
            cursor: 'pointer',
            border: 'none',
            background: statusFilter === 'ALL' ? '#234B3C' : '#F1F5F9',
            color: statusFilter === 'ALL' ? '#FFF' : '#475569',
            whiteSpace: 'nowrap'
          }}
        >
          All Stages ({orders.length})
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('CONFIRMED')}
          style={{
            padding: '5px 12px',
            borderRadius: '6px',
            fontSize: '11.5px',
            fontWeight: 800,
            cursor: 'pointer',
            border: statusFilter === 'CONFIRMED' ? '1.5px solid #6366F1' : '1px solid #E2E8F0',
            background: statusFilter === 'CONFIRMED' ? '#EEF2FF' : '#FFF',
            color: statusFilter === 'CONFIRMED' ? '#4F46E5' : '#334155',
            whiteSpace: 'nowrap'
          }}
        >
          1. Confirmed ({countConfirmed})
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('PROCURING')}
          style={{
            padding: '5px 12px',
            borderRadius: '6px',
            fontSize: '11.5px',
            fontWeight: 800,
            cursor: 'pointer',
            border: statusFilter === 'PROCURING' ? '1.5px solid #D97706' : '1px solid #E2E8F0',
            background: statusFilter === 'PROCURING' ? '#FEF3C7' : '#FFF',
            color: statusFilter === 'PROCURING' ? '#B45309' : '#334155',
            whiteSpace: 'nowrap'
          }}
        >
          2. Mandi Procurement ({countProcuring})
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('AT_WAREHOUSE')}
          style={{
            padding: '5px 12px',
            borderRadius: '6px',
            fontSize: '11.5px',
            fontWeight: 800,
            cursor: 'pointer',
            border: statusFilter === 'AT_WAREHOUSE' ? '1.5px solid #0284C7' : '1px solid #E2E8F0',
            background: statusFilter === 'AT_WAREHOUSE' ? '#E0F2FE' : '#FFF',
            color: statusFilter === 'AT_WAREHOUSE' ? '#0369A1' : '#334155',
            whiteSpace: 'nowrap'
          }}
        >
          3. At Warehouse Sorting ({countWarehouse})
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('PACKED')}
          style={{
            padding: '5px 12px',
            borderRadius: '6px',
            fontSize: '11.5px',
            fontWeight: 800,
            cursor: 'pointer',
            border: statusFilter === 'PACKED' ? '1.5px solid #10B981' : '1px solid #E2E8F0',
            background: statusFilter === 'PACKED' ? '#ECFDF5' : '#FFF',
            color: statusFilter === 'PACKED' ? '#059669' : '#334155',
            whiteSpace: 'nowrap'
          }}
        >
          4. Packed & Crated ({countPacked})
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('OUT_FOR_DELIVERY')}
          style={{
            padding: '5px 12px',
            borderRadius: '6px',
            fontSize: '11.5px',
            fontWeight: 800,
            cursor: 'pointer',
            border: statusFilter === 'OUT_FOR_DELIVERY' ? '1.5px solid #F28E14' : '1px solid #E2E8F0',
            background: statusFilter === 'OUT_FOR_DELIVERY' ? '#FFF7ED' : '#FFF',
            color: statusFilter === 'OUT_FOR_DELIVERY' ? '#EA580C' : '#334155',
            whiteSpace: 'nowrap'
          }}
        >
          5. Out for Delivery ({countOut})
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('DELIVERED')}
          style={{
            padding: '5px 12px',
            borderRadius: '6px',
            fontSize: '11.5px',
            fontWeight: 800,
            cursor: 'pointer',
            border: statusFilter === 'DELIVERED' ? '1.5px solid #059669' : '1px solid #E2E8F0',
            background: statusFilter === 'DELIVERED' ? '#ECFDF5' : '#FFF',
            color: statusFilter === 'DELIVERED' ? '#047857' : '#334155',
            whiteSpace: 'nowrap'
          }}
        >
          6. Delivered ({countDelivered})
        </button>
      </div>

      {/* Slim Society Batch Quick Updater Bar */}
      <div style={{
        background: '#F0FDF4',
        border: '1px solid #BBF7D0',
        borderRadius: '8px',
        padding: '6px 12px',
        marginBottom: '10px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '8px'
      }}>
        <div style={{ fontSize: '11.5px', fontWeight: 700, color: '#166534', display: 'flex', alignItems: 'center', gap: '5px' }}>
          <Layers size={13} />
          <span>Quick Society Batch Advance:</span>
        </div>

        <form onSubmit={handleBatchUpdateSociety} style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
          <select
            value={batchSociety}
            onChange={(e) => setBatchSociety(e.target.value)}
            style={{ padding: '3px 8px', borderRadius: '4px', border: '1px solid #86EFAC', background: '#FFF', fontSize: '11.5px', fontWeight: 700, color: '#0F172A' }}
          >
            {societies.map(s => (
              <option key={s.id} value={s.name}>{s.name}</option>
            ))}
          </select>

          <span style={{ fontSize: '11px', fontWeight: 800, color: '#166534' }}>&rarr;</span>

          <select
            value={batchTargetStatus}
            onChange={(e) => setBatchTargetStatus(e.target.value)}
            style={{ padding: '3px 8px', borderRadius: '4px', border: '1px solid #86EFAC', background: '#FFF', fontSize: '11.5px', fontWeight: 700, color: '#0F172A' }}
          >
            <option value="PROCURING">PROCURING (Mandi Yard)</option>
            <option value="AT_WAREHOUSE">AT WAREHOUSE (Sorting & Crating)</option>
            <option value="OUT_FOR_DELIVERY">OUT FOR DELIVERY (In Transit)</option>
            <option value="DELIVERED">DELIVERED (Drop Desk Handover)</option>
          </select>

          <button
            type="submit"
            style={{ padding: '4px 10px', borderRadius: '4px', background: '#166534', color: '#FFF', border: 'none', fontSize: '11.5px', fontWeight: 800, cursor: 'pointer' }}
          >
            Apply to All Orders
          </button>
        </form>
      </div>

      {/* ================= SEARCH & FILTER CONTROLS ================= */}
      <div style={{
        background: '#FFFFFF',
        borderRadius: '12px',
        border: '1px solid #E2E8F0',
        padding: '12px 16px',
        marginBottom: '18px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '12px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1, minWidth: '240px' }}>
          <Search size={16} color="#64748B" />
          <input
            type="text"
            placeholder="Search by Order ID, customer, society, or flat number..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{ width: '100%', border: 'none', outline: 'none', fontSize: '13px' }}
          />
        </div>

        <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: '#64748B' }}>
            <Filter size={13} />
            <span>Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              style={{ padding: '4px 8px', borderRadius: '6px', border: '1px solid #CBD5E1', fontSize: '12px' }}
            >
              <option value="ALL">All Status ({orders.length})</option>
              <option value="CONFIRMED">Confirmed ({countConfirmed})</option>
              <option value="PROCURING">Procuring ({countProcuring})</option>
              <option value="AT_WAREHOUSE">At Warehouse ({countWarehouse})</option>
              <option value="OUT_FOR_DELIVERY">Out for Delivery ({countOut})</option>
              <option value="DELIVERED">Delivered ({countDelivered})</option>
            </select>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: '#64748B' }}>
            <span>Society:</span>
            <select
              value={societyFilter}
              onChange={(e) => setSocietyFilter(e.target.value)}
              style={{ padding: '4px 8px', borderRadius: '6px', border: '1px solid #CBD5E1', fontSize: '12px' }}
            >
              <option value="ALL">All Societies</option>
              {societies.map(s => (
                <option key={s.id} value={s.name}>{s.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* ================= PRIMARY ENTERPRISE ORDERS DATA TABLE ================= */}
      <div className="admin-table-card">
        <div style={{ overflowX: 'auto' }}>
          <table className="admin-data-table">
            <thead>
              <tr>
                <th>Order # & Timestamp</th>
                <th>Resident & Community</th>
                <th>Produce Basket Items</th>
                <th>Value & Mode</th>
                <th>Assigned Warehouse Hub</th>
                <th>Live Fulfillment Status</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '36px', color: '#64748B' }}>
                    No orders matching the selected filter criteria.
                  </td>
                </tr>
              ) : (
                filteredOrders.map(order => {
                  const currentStatus = order.status || 'CONFIRMED';
                  const statusConf = STATUS_CONFIG[currentStatus] || STATUS_CONFIG.CONFIRMED;

                  return (
                    <tr key={order.id}>
                      <td>
                        <strong style={{ fontSize: '13px', color: '#0F172A' }}>#{order.id}</strong>
                        <div style={{ fontSize: '11px', color: '#64748B', display: 'flex', alignItems: 'center', gap: '4px', marginTop: '2px' }}>
                          <Clock size={11} />
                          <span>{order.createdAt || 'Cutoff 9 PM'}</span>
                        </div>
                      </td>

                      <td>
                        <div style={{ fontSize: '13px', fontWeight: 800, color: '#0F172A' }}>
                          {order.userName || order.customerName || 'Resident User'}
                        </div>
                        <div style={{ fontSize: '11.5px', color: '#475569', display: 'flex', alignItems: 'center', gap: '4px', marginTop: '2px' }}>
                          <Building2 size={12} color="#64748B" />
                          <span>{order.societyName || 'Greenfield Heights'}</span>
                          {order.flatNumber && <span style={{ fontWeight: 700 }}>({order.flatNumber})</span>}
                        </div>
                      </td>

                      <td>
                        <div style={{ fontSize: '12.5px', color: '#1E293B', fontWeight: 600 }}>
                          {(order.items || []).slice(0, 2).map((item, idx) => (
                            <span key={idx}>
                              {item.name || item.productName || 'Fresh Item'} ({item.quantity || 1}x)
                              {idx < Math.min((order.items || []).length, 2) - 1 ? ', ' : ''}
                            </span>
                          ))}
                          {(order.items || []).length > 2 && (
                            <span style={{ color: '#0369A1', fontSize: '11.5px', fontWeight: 700 }}>
                              {' '}+{ (order.items || []).length - 2 } more
                            </span>
                          )}
                        </div>
                        <div style={{ fontSize: '11px', color: '#64748B', marginTop: '2px' }}>
                          {(order.items || []).length} items in crate
                        </div>
                      </td>

                      <td>
                        <div style={{ fontSize: '13.5px', fontWeight: 800, color: '#0F172A' }}>
                          ₹{(order.totalAmount || 0).toLocaleString()}
                        </div>
                        <span style={{ fontSize: '10.5px', background: '#F1F5F9', color: '#475569', padding: '1px 5px', borderRadius: '4px', fontWeight: 700 }}>
                          {order.paymentMethod || 'UPI / Prepaid'}
                        </span>
                      </td>

                      <td>
                        <div style={{ fontSize: '12px', fontWeight: 700, color: '#334155', display: 'flex', alignItems: 'center', gap: '4px' }}>
                          <Warehouse size={13} color="#059669" />
                          <span>{order.warehouseCode || 'WH-BLR-NORTH'}</span>
                        </div>
                        <div style={{ fontSize: '11px', color: '#64748B' }}>
                          Morning Drop Desk
                        </div>
                      </td>

                      <td>
                        {/* Live Status Interactive Selector */}
                        <select
                          value={currentStatus}
                          onChange={(e) => handleUpdateOrderStatus(order.id, e.target.value)}
                          style={{
                            padding: '4px 8px',
                            borderRadius: '6px',
                            border: `1.5px solid ${statusConf.color}`,
                            background: '#FFFFFF',
                            color: statusConf.color,
                            fontWeight: 800,
                            fontSize: '11.5px',
                            cursor: 'pointer'
                          }}
                        >
                          <option value="CONFIRMED">CONFIRMED (Cutoff)</option>
                          <option value="PROCURING">PROCURING (Mandi)</option>
                          <option value="AT_WAREHOUSE">AT WAREHOUSE (Sorting)</option>
                          <option value="PACKED">PACKED & CRATED (Tags)</option>
                          <option value="OUT_FOR_DELIVERY">OUT FOR DELIVERY</option>
                          <option value="DELIVERED">DELIVERED (Drop Desk)</option>
                          <option value="CANCELLED">CANCELLED</option>
                        </select>
                        {order.lastStatusUpdate && (
                          <div style={{ fontSize: '10px', color: '#64748B', marginTop: '2px' }}>
                            Updated: {order.lastStatusUpdate}
                          </div>
                        )}
                      </td>

                      <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                        {currentStatus === 'OUT_FOR_DELIVERY' && (
                          <button
                            type="button"
                            onClick={() => handleUpdateOrderStatus(order.id, 'DELIVERED')}
                            style={{
                              background: '#059669',
                              color: '#FFF',
                              border: 'none',
                              padding: '5px 9px',
                              borderRadius: '6px',
                              fontSize: '11.5px',
                              fontWeight: 800,
                              cursor: 'pointer',
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '4px',
                              marginRight: '6px'
                            }}
                            title="Mark Delivered to society drop desk"
                          >
                            <CheckCircle2 size={13} />
                            <span>Mark Delivered</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setSelectedOrder(order)}
                          style={{
                            background: '#F8FAFC',
                            border: '1px solid #CBD5E1',
                            padding: '5px 9px',
                            borderRadius: '6px',
                            fontSize: '12px',
                            fontWeight: 700,
                            color: '#334155',
                            cursor: 'pointer',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '4px'
                          }}
                          title="View Order Details"
                        >
                          <Eye size={12} />
                          <span>View</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ================= ORDER DETAILS MODAL ================= */}
      {selectedOrder && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(15, 23, 42, 0.65)',
          backdropFilter: 'blur(4px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          padding: '20px'
        }}>
          <div style={{
            background: '#FFFFFF',
            borderRadius: '16px',
            maxWidth: '520px',
            width: '100%',
            padding: '24px 28px',
            boxShadow: '0 20px 40px rgba(0, 0, 0, 0.2)'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <div>
                <h3 style={{ fontSize: '18px', fontWeight: 800, color: '#0F172A', margin: 0 }}>
                  Order #{selectedOrder.id}
                </h3>
                <div style={{ fontSize: '12px', color: '#64748B' }}>
                  {selectedOrder.societyName} • Flat {selectedOrder.flatNumber || 'T-402'}
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedOrder(null)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748B' }}
              >
                <X size={20} />
              </button>
            </div>

            <div style={{ background: '#F8FAFC', padding: '14px', borderRadius: '10px', marginBottom: '16px' }}>
              <div style={{ fontSize: '12px', color: '#64748B', fontWeight: 700, textTransform: 'uppercase', marginBottom: '8px' }}>
                Crate Items Manifest
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {(selectedOrder.items || []).map((item, idx) => (
                  <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px' }}>
                    <span style={{ color: '#0F172A', fontWeight: 600 }}>
                      {item.name || item.productName} ({item.unit || '1 kg'}) × {item.quantity || 1}
                    </span>
                    <strong style={{ color: '#234B3C' }}>
                      ₹{(item.price || item.retailPrice || 0) * (item.quantity || 1)}
                    </strong>
                  </div>
                ))}
              </div>
              <div style={{ borderTop: '1px solid #E2E8F0', marginTop: '10px', paddingTop: '8px', display: 'flex', justifyContent: 'space-between', fontSize: '14px', fontWeight: 800 }}>
                <span>Order Total:</span>
                <span style={{ color: '#234B3C' }}>₹{selectedOrder.totalAmount || 0}</span>
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '10px' }}>
              <div style={{ fontSize: '12px', color: '#64748B' }}>
                Current Status: <strong>{selectedOrder.status || 'CONFIRMED'}</strong>
              </div>
              <button
                type="button"
                onClick={() => setSelectedOrder(null)}
                style={{
                  padding: '8px 18px',
                  borderRadius: '6px',
                  background: '#234B3C',
                  color: '#FFF',
                  border: 'none',
                  fontSize: '12.5px',
                  fontWeight: 700,
                  cursor: 'pointer'
                }}
              >
                Close Manifest
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
