import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  Store, 
  Warehouse, 
  ArrowLeft, 
  Users, 
  UserPlus, 
  Building2, 
  Phone, 
  MapPin, 
  Clock, 
  CheckCircle2, 
  Edit3, 
  Trash2, 
  X, 
  Save, 
  Download,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { useAdminRole } from '../context/AdminRoleContext';
import { useToast } from '../context/ToastContext';
import { saveFreshiozStore } from '../shared/freshiozStore';
import { exportToExcel } from '../utils/excelExporter';

export default function StoreDetailsPage() {
  const { warehouseId, storeId } = useParams();
  const navigate = useNavigate();
  const { store } = useAdminRole();
  const { showToast: showGlobalToast } = useToast();

  const warehouses = store.warehouses || [];
  const shops = store.shops || [];
  const societies = store.societies || [];

  const warehouse = warehouses.find(w => w.id === warehouseId) || warehouses[0];
  const currentStore = shops.find(s => s.id === storeId) || shops.find(s => s.warehouseId === warehouse?.id) || shops[0];

  const mappedSocieties = societies.filter(soc => soc.nearestShopId === currentStore?.id);
  const employees = store.employees || [];
  const assignedEmployees = employees.filter(e => e.assignedWarehouseId === currentStore?.id);
  const staffList = assignedEmployees.length > 0
    ? assignedEmployees.map(emp => ({
        id: emp.id,
        name: emp.name,
        role: emp.roles?.includes('DELIVERY_EXECUTIVE') ? 'Delivery Executive' : 'Store Manager',
        phone: emp.phone,
        shift: emp.notes?.replace('Shift: ', '') || 'Dawn Dispatch 6:00 AM - 9:30 AM'
      }))
    : (currentStore?.staff || []);

  // Edit Store State
  const [isEditingStore, setIsEditingStore] = useState(false);
  const [storeEditForm, setStoreEditForm] = useState({
    name: currentStore?.name || '',
    address: currentStore?.address || '',
    manager: currentStore?.manager || '',
    phone: currentStore?.phone || '',
    capacityOrders: currentStore?.capacityOrders || 500,
    status: currentStore?.status || 'ACTIVE'
  });

  // Add Staff State
  const [isAddingStaff, setIsAddingStaff] = useState(false);
  const [newStaff, setNewStaff] = useState({
    name: '',
    role: 'Delivery Executive',
    phone: '',
    shift: 'Dawn Dispatch 6:00 AM - 9:30 AM'
  });

  const [notificationToast, setNotificationToast] = useState('');

  const showToast = (msg, type = 'success') => {
    setNotificationToast(msg);
    showGlobalToast(msg, type);
    setTimeout(() => setNotificationToast(''), 4500);
  };

  if (!currentStore) {
    return (
      <div className="admin-page-container" style={{ padding: '40px', textAlign: 'center' }}>
        <h2>Store Not Found</h2>
        <p style={{ color: '#64748B', marginTop: '8px' }}>The requested store hub could not be found.</p>
        <Link to={`/warehouse/${warehouseId || 'wh-1'}/stores`} className="admin-btn-primary" style={{ marginTop: '16px', display: 'inline-flex' }}>
          &larr; Back to Stores List
        </Link>
      </div>
    );
  }

  // Save Store Specs
  const handleSaveStoreSpecs = (e) => {
    e.preventDefault();
    saveFreshiozStore(prev => ({
      ...prev,
      shops: prev.shops.map(s => s.id === currentStore.id ? { ...s, ...storeEditForm } : s)
    }));
    setIsEditingStore(false);
    showToast(`✓ Store specifications for "${storeEditForm.name}" updated!`);
  };

  // Add Staff Member (Direct to Master Employees Directory)
  const handleAddStaff = (e) => {
    e.preventDefault();
    if (!newStaff.name.trim() || !newStaff.phone.trim()) {
      alert('Please enter staff name and contact number.');
      return;
    }

    const roleMapping = newStaff.role.toLowerCase().includes('delivery')
      ? 'DELIVERY_EXECUTIVE'
      : 'STORE_MANAGER';

    const newEmpId = `emp-${Date.now().toString().slice(-4)}`;
    const newEmp = {
      id: newEmpId,
      name: newStaff.name.trim(),
      phone: newStaff.phone.trim(),
      email: `${newStaff.name.toLowerCase().replace(/\s+/g, '.')}@freshioz.com`,
      roles: [roleMapping],
      assignedWarehouseId: currentStore.id,
      assignedLocationType: 'STORE',
      assignedLocationName: currentStore.name,
      status: 'ACTIVE',
      inviteStatus: 'ACTIVE',
      password: 'admin123',
      notes: `Shift: ${newStaff.shift}`,
      dateJoined: new Date().toISOString().slice(0, 10)
    };

    saveFreshiozStore(prev => ({
      ...prev,
      employees: [newEmp, ...(prev.employees || [])]
    }));

    setNewStaff({
      name: '',
      role: 'Delivery Executive',
      phone: '',
      shift: 'Dawn Dispatch 6:00 AM - 9:30 AM'
    });
    setIsAddingStaff(false);
    showToast(`✓ Added ${newStaff.name} to enterprise staff directory for ${currentStore.name}!`);
  };

  // Remove Staff Member
  const handleRemoveStaff = (staffId) => {
    saveFreshiozStore(prev => ({
      ...prev,
      employees: (prev.employees || []).filter(e => e.id !== staffId),
      shops: (prev.shops || []).map(s => s.id === currentStore.id ? {
        ...s,
        staff: (s.staff || []).filter(st => st.id !== staffId)
      } : s)
    }));
    showToast('Staff member removed from store roster.');
  };

  // Export Store Manifest
  const handleExportStoreManifest = () => {
    const headers = [
      'Store ID',
      'Store Name',
      'Warehouse Hub',
      'Address',
      'Manager',
      'Phone',
      'Staff Member',
      'Staff Role',
      'Shift',
      'Mapped Society',
      'Society Flats',
      'Cashback %'
    ];

    const rows = [];
    if (staffList.length === 0 && mappedSocieties.length === 0) {
      rows.push([
        currentStore.id,
        currentStore.name,
        warehouse?.name || 'N/A',
        currentStore.address,
        currentStore.manager,
        currentStore.phone,
        'None',
        'None',
        'None',
        'None',
        0,
        0
      ]);
    } else {
      const maxRows = Math.max(staffList.length, mappedSocieties.length);
      for (let i = 0; i < maxRows; i++) {
        const staff = staffList[i];
        const soc = mappedSocieties[i];
        rows.push([
          currentStore.id,
          currentStore.name,
          warehouse?.name || 'N/A',
          currentStore.address,
          currentStore.manager,
          currentStore.phone,
          staff?.name || '-',
          staff?.role || '-',
          staff?.shift || '-',
          soc?.name || '-',
          soc?.totalUnits || '-',
          soc?.commissionPercent ? `${soc.commissionPercent}%` : '-'
        ]);
      }
    }

    exportToExcel(`Freshioz_Store_${currentStore.id}_Manifest`, headers, rows);
  };

  return (
    <div className="admin-page-container">
      {/* Compact Breadcrumb Bar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: '#64748B', marginBottom: '12px' }}>
        <Link to="/warehouse-settings" style={{ color: '#234B3C', fontWeight: 700, textDecoration: 'none' }}>
          Warehouses
        </Link>
        <ChevronRight size={12} color="#94A3B8" />
        <Link to={`/warehouse/${warehouse?.id}/stores`} style={{ color: '#234B3C', fontWeight: 700, textDecoration: 'none' }}>
          {warehouse?.name || 'Warehouse'} Stores
        </Link>
        <ChevronRight size={12} color="#94A3B8" />
        <span style={{ color: '#0F172A', fontWeight: 800 }}>{currentStore.name}</span>
      </div>

      {/* Slim Header with Quick Actions */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '10px',
        paddingBottom: '12px',
        borderBottom: '1.5px solid #E2E8F0',
        marginBottom: '16px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <Link
            to={`/warehouse/${warehouse?.id}/stores`}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px',
              padding: '6px 10px',
              borderRadius: '6px',
              background: '#F1F5F9',
              border: '1px solid #CBD5E1',
              color: '#334155',
              fontSize: '12px',
              fontWeight: 800,
              textDecoration: 'none'
            }}
          >
            <ArrowLeft size={14} />
            <span>Back to Stores</span>
          </Link>

          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <h1 style={{ fontSize: '18px', fontWeight: 800, color: '#0F172A', margin: 0 }}>
                {currentStore.name}
              </h1>
              <span style={{ background: '#234B3C', color: '#FFF', fontSize: '10.5px', fontWeight: 800, padding: '2px 7px', borderRadius: '4px' }}>
                {currentStore.id}
              </span>
              <span className={`status-pill ${currentStore.status === 'ACTIVE' ? 'approved' : 'rejected'}`} style={{ fontSize: '10.5px', padding: '2px 8px' }}>
                {currentStore.status || 'ACTIVE'}
              </span>
            </div>
            <div style={{ fontSize: '11.5px', color: '#64748B', marginTop: '2px' }}>
              Parent: <strong>{warehouse?.name}</strong> • Lead: {currentStore.manager} ({currentStore.phone})
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <button
            type="button"
            onClick={handleExportStoreManifest}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '5px',
              padding: '7px 12px',
              borderRadius: '6px',
              background: '#FFFFFF',
              border: '1px solid #CBD5E1',
              color: '#334155',
              fontWeight: 700,
              fontSize: '12px',
              cursor: 'pointer'
            }}
          >
            <Download size={13} />
            <span>Export Manifest</span>
          </button>

          <button
            type="button"
            onClick={() => setIsEditingStore(!isEditingStore)}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '5px',
              padding: '7px 14px',
              borderRadius: '6px',
              background: '#234B3C',
              color: '#FFFFFF',
              fontWeight: 800,
              fontSize: '12px',
              border: 'none',
              cursor: 'pointer'
            }}
          >
            <Edit3 size={13} />
            <span>{isEditingStore ? 'Cancel Edit' : 'Edit Store Specs'}</span>
          </button>
        </div>
      </div>

      {/* Toast Alert */}
      {notificationToast && (
        <div style={{
          background: '#ECFDF5',
          border: '1.5px solid #6EE7B7',
          color: '#065F46',
          padding: '10px 14px',
          borderRadius: '8px',
          marginBottom: '14px',
          fontWeight: 700,
          fontSize: '12.5px',
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <CheckCircle2 size={16} color="#059669" />
          <span>{notificationToast}</span>
        </div>
      )}

      {/* Edit Store Inline Form (Collapsible) */}
      {isEditingStore && (
        <form onSubmit={handleSaveStoreSpecs} style={{
          background: '#F8FAFC',
          border: '1.5px solid #CBD5E1',
          borderRadius: '10px',
          padding: '16px',
          marginBottom: '18px'
        }}>
          <div style={{ fontSize: '13px', fontWeight: 800, color: '#0F172A', marginBottom: '12px' }}>
            Modify Store Specifications
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '12px', marginBottom: '12px' }}>
            <div>
              <label className="form-label-title" style={{ fontSize: '11px' }}>Store Name *</label>
              <input
                type="text"
                className="form-input-control"
                value={storeEditForm.name}
                onChange={(e) => setStoreEditForm({ ...storeEditForm, name: e.target.value })}
                required
              />
            </div>
            <div>
              <label className="form-label-title" style={{ fontSize: '11px' }}>Physical Address *</label>
              <input
                type="text"
                className="form-input-control"
                value={storeEditForm.address}
                onChange={(e) => setStoreEditForm({ ...storeEditForm, address: e.target.value })}
                required
              />
            </div>
            <div>
              <label className="form-label-title" style={{ fontSize: '11px' }}>Store Manager *</label>
              <input
                type="text"
                className="form-input-control"
                value={storeEditForm.manager}
                onChange={(e) => setStoreEditForm({ ...storeEditForm, manager: e.target.value })}
                required
              />
            </div>
            <div>
              <label className="form-label-title" style={{ fontSize: '11px' }}>Phone *</label>
              <input
                type="tel"
                className="form-input-control"
                value={storeEditForm.phone}
                onChange={(e) => setStoreEditForm({ ...storeEditForm, phone: e.target.value })}
                required
              />
            </div>
            <div>
              <label className="form-label-title" style={{ fontSize: '11px' }}>Capacity (Orders/Morning)</label>
              <input
                type="number"
                className="form-input-control"
                value={storeEditForm.capacityOrders}
                onChange={(e) => setStoreEditForm({ ...storeEditForm, capacityOrders: Number(e.target.value) })}
              />
            </div>
            <div>
              <label className="form-label-title" style={{ fontSize: '11px' }}>Operating Status</label>
              <select
                className="form-input-control"
                value={storeEditForm.status}
                onChange={(e) => setStoreEditForm({ ...storeEditForm, status: e.target.value })}
              >
                <option value="ACTIVE">ACTIVE</option>
                <option value="INACTIVE">INACTIVE</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
            <button
              type="button"
              onClick={() => setIsEditingStore(false)}
              style={{ padding: '7px 14px', borderRadius: '6px', border: '1px solid #CBD5E1', background: '#FFF', fontSize: '12px', cursor: 'pointer' }}
            >
              Cancel
            </button>
            <button
              type="submit"
              style={{ padding: '7px 18px', borderRadius: '6px', border: 'none', background: '#234B3C', color: '#FFF', fontWeight: 800, fontSize: '12px', cursor: 'pointer' }}
            >
              Save Changes
            </button>
          </div>
        </form>
      )}

      {/* Two-Column Enterprise Operational Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(380px, 1fr))', gap: '16px' }}>
        
        {/* COLUMN 1: STORE PEOPLE & DELIVERY STAFF */}
        <div className="admin-table-card" style={{ margin: 0 }}>
          <div className="admin-table-header" style={{ padding: '12px 16px' }}>
            <div>
              <h3 style={{ fontSize: '14px', fontWeight: 800, color: '#0F172A', margin: 0, display: 'flex', alignItems: 'center', gap: '6px' }}>
                <Users size={16} color="#2563EB" />
                <span>Store People Team ({staffList.length})</span>
              </h3>
              <div style={{ fontSize: '11px', color: '#64748B' }}>Managers, dawn dispatch riders & packers</div>
            </div>

            <button
              type="button"
              onClick={() => setIsAddingStaff(!isAddingStaff)}
              style={{
                background: '#EFF6FF',
                border: '1px solid #BFDBFE',
                color: '#1D4ED8',
                padding: '5px 10px',
                borderRadius: '6px',
                fontSize: '11.5px',
                fontWeight: 800,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '4px'
              }}
            >
              <UserPlus size={13} />
              <span>{isAddingStaff ? 'Cancel' : '+ Add Person'}</span>
            </button>
          </div>

          {/* Add Staff Form */}
          {isAddingStaff && (
            <form onSubmit={handleAddStaff} style={{ background: '#F0F9FF', borderBottom: '1px solid #BAE6FD', padding: '12px 16px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '8px' }}>
                <div>
                  <label className="form-label-title" style={{ fontSize: '10.5px' }}>Name *</label>
                  <input
                    type="text"
                    className="form-input-control"
                    placeholder="Staff Full Name"
                    value={newStaff.name}
                    onChange={(e) => setNewStaff({ ...newStaff, name: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <label className="form-label-title" style={{ fontSize: '10.5px' }}>Role in Store *</label>
                  <select
                    className="form-input-control"
                    value={newStaff.role}
                    onChange={(e) => setNewStaff({ ...newStaff, role: e.target.value })}
                  >
                    <option value="Store Manager">Store Manager</option>
                    <option value="Delivery Executive">Delivery Executive</option>
                    <option value="Sorting & Crating Assistant">Sorting & Crating Assistant</option>
                  </select>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.2fr', gap: '8px', marginBottom: '10px' }}>
                <div>
                  <label className="form-label-title" style={{ fontSize: '10.5px' }}>Phone *</label>
                  <input
                    type="tel"
                    className="form-input-control"
                    placeholder="+91 98450..."
                    value={newStaff.phone}
                    onChange={(e) => setNewStaff({ ...newStaff, phone: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <label className="form-label-title" style={{ fontSize: '10.5px' }}>Shift Window</label>
                  <select
                    className="form-input-control"
                    value={newStaff.shift}
                    onChange={(e) => setNewStaff({ ...newStaff, shift: e.target.value })}
                  >
                    <option value="Dawn Dispatch 6:00 AM - 9:30 AM">Dawn (6:00 AM - 9:30 AM)</option>
                    <option value="Morning Full 5:00 AM - 2:00 PM">Morning Full (5:00 AM - 2:00 PM)</option>
                    <option value="Evening Return 4:30 PM - 8:30 PM">Evening Return (4:30 PM - 8:30 PM)</option>
                  </select>
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <button
                  type="submit"
                  style={{
                    background: '#0284C7',
                    color: '#FFF',
                    padding: '5px 14px',
                    borderRadius: '6px',
                    fontSize: '11.5px',
                    fontWeight: 800,
                    border: 'none',
                    cursor: 'pointer'
                  }}
                >
                  Save to Store Team
                </button>
              </div>
            </form>
          )}

          <div style={{ overflowX: 'auto' }}>
            <table className="admin-data-table" style={{ margin: 0 }}>
              <thead>
                <tr>
                  <th>Staff Member</th>
                  <th>Role</th>
                  <th>Shift Window</th>
                  <th style={{ textAlign: 'right' }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {staffList.length === 0 ? (
                  <tr>
                    <td colSpan="4" style={{ textAlign: 'center', padding: '24px', color: '#64748B', fontSize: '12px' }}>
                      No staff assigned yet. Click <strong>+ Add Person</strong> to assign team members.
                    </td>
                  </tr>
                ) : (
                  staffList.map(member => (
                    <tr key={member.id}>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <div style={{ width: '28px', height: '28px', borderRadius: '50%', background: '#DBEAFE', color: '#1D4ED8', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: '11px', flexShrink: 0 }}>
                            {member.name?.[0]?.toUpperCase()}
                          </div>
                          <div>
                            <strong style={{ fontSize: '12.5px', color: '#0F172A' }}>{member.name}</strong>
                            <div style={{ fontSize: '11px', color: '#64748B' }}>{member.phone}</div>
                          </div>
                        </div>
                      </td>
                      <td>
                        <span style={{ fontSize: '11px', fontWeight: 700, background: '#F1F5F9', color: '#334155', padding: '2px 7px', borderRadius: '4px' }}>
                          {member.role}
                        </span>
                      </td>
                      <td>
                        <div style={{ fontSize: '11.5px', color: '#475569' }}>
                          {member.shift || 'Dawn Dispatch'}
                        </div>
                      </td>
                      <td style={{ textAlign: 'right' }}>
                        <button
                          type="button"
                          onClick={() => handleRemoveStaff(member.id)}
                          style={{
                            background: '#FFF1F2',
                            border: '1px solid #FECDD3',
                            padding: '4px 8px',
                            borderRadius: '5px',
                            color: '#E11D48',
                            cursor: 'pointer',
                            fontSize: '11px',
                            fontWeight: 700
                          }}
                          title="Remove staff"
                        >
                          Remove
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* COLUMN 2: MAPPED APARTMENT SOCIETIES & HOSTELS */}
        <div className="admin-table-card" style={{ margin: 0 }}>
          <div className="admin-table-header" style={{ padding: '12px 16px' }}>
            <div>
              <h3 style={{ fontSize: '14px', fontWeight: 800, color: '#0F172A', margin: 0, display: 'flex', alignItems: 'center', gap: '6px' }}>
                <Building2 size={16} color="#059669" />
                <span>Mapped Societies & Hostels ({mappedSocieties.length})</span>
              </h3>
              <div style={{ fontSize: '11px', color: '#64748B' }}>Communities fulfilled by dawn batch delivery from this store</div>
            </div>

            <span style={{ fontSize: '11px', background: '#ECFDF5', color: '#059669', padding: '3px 8px', borderRadius: '5px', fontWeight: 800 }}>
              {mappedSocieties.reduce((acc, s) => acc + (s.totalUnits || 0), 0)} Total Flats
            </span>
          </div>

          <div style={{ overflowX: 'auto' }}>
            <table className="admin-data-table" style={{ margin: 0 }}>
              <thead>
                <tr>
                  <th>Society Name & Address</th>
                  <th>Flats</th>
                  <th>Cashback %</th>
                  <th>Society Lead</th>
                </tr>
              </thead>
              <tbody>
                {mappedSocieties.length === 0 ? (
                  <tr>
                    <td colSpan="4" style={{ textAlign: 'center', padding: '24px', color: '#64748B', fontSize: '12px' }}>
                      No apartment societies currently mapped to this store.
                    </td>
                  </tr>
                ) : (
                  mappedSocieties.map(soc => (
                    <tr key={soc.id}>
                      <td>
                        <strong style={{ fontSize: '12.5px', color: '#0F172A' }}>{soc.name}</strong>
                        <div style={{ fontSize: '11px', color: '#64748B', maxWidth: '220px' }}>
                          {soc.address}
                        </div>
                      </td>
                      <td>
                        <div style={{ fontSize: '12px', fontWeight: 800, color: '#234B3C' }}>
                          {soc.totalUnits || 120} Flats
                        </div>
                      </td>
                      <td>
                        <span style={{ fontSize: '11px', background: '#DCFCE7', color: '#15803D', padding: '2px 6px', borderRadius: '4px', fontWeight: 800 }}>
                          {soc.commissionPercent || 2}%
                        </span>
                      </td>
                      <td>
                        <div style={{ fontSize: '12px', color: '#0F172A', fontWeight: 700 }}>
                          {soc.pocName || 'Resident Lead'}
                        </div>
                        <div style={{ fontSize: '11px', color: '#64748B' }}>
                          {soc.pocPhone || '-'}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
}
