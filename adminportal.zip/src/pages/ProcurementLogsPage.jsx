import React from 'react';
import { Truck, MapPin, FileText, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAdminRole } from '../context/AdminRoleContext';

export default function ProcurementLogsPage() {
  const { store } = useAdminRole();

  const logs = store.procurementLogs || [];

  return (
    <div className="admin-page-container">
      {/* Compact Page Title & Stats */}
      <div className="page-title-header" style={{ marginBottom: '12px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
          <div>
            <h1 style={{ fontSize: '18px', fontWeight: 800, color: '#0F172A', margin: 0 }}>
              Mandi Purchases Audit & Bills Ledger
            </h1>
            <p style={{ fontSize: '12px', color: '#64748B', margin: '2px 0 0' }}>
              Morning APMC transactions, digital receipts & hub routing ledger
            </p>
          </div>

          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
            <span style={{ fontSize: '11.5px', background: '#E2E8F0', color: '#334155', padding: '3px 10px', borderRadius: '6px', fontWeight: 700 }}>
              Bills: {logs.length}
            </span>
            <span style={{ fontSize: '11.5px', background: '#EBF2EE', color: '#234B3C', padding: '3px 10px', borderRadius: '6px', fontWeight: 700 }}>
              Total Paid: ₹{logs.reduce((acc, l) => acc + (l.totalAmountPaid || 0), 0).toLocaleString()}
            </span>
          </div>
        </div>

        <Link
          to="/procurement-entry"
          className="admin-btn-primary"
          style={{ fontSize: '12px', padding: '6px 14px', borderRadius: '6px', height: 'auto', display: 'inline-flex', alignItems: 'center', gap: '6px' }}
        >
          <span>+ Log Mandi Purchase</span>
        </Link>
      </div>

      <div className="admin-table-card">
        <div className="admin-table-header">
          <h3 style={{ fontSize: '15px', color: '#0F172A' }}>Verified Mandi Purchases ({logs.length})</h3>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table className="admin-data-table">
            <thead>
              <tr>
                <th>Log ID</th>
                <th>Mandi Vendor</th>
                <th>Items Procured</th>
                <th>Destination Routing</th>
                <th>Bill / Invoice #</th>
                <th>Payment Mode</th>
                <th>Amount Paid (₹)</th>
              </tr>
            </thead>
            <tbody>
              {logs.map(log => (
                <tr key={log.id}>
                  <td>
                    <strong style={{ fontFamily: 'monospace' }}>{log.id}</strong>
                  </td>
                  <td>
                    <strong>{log.vendorName}</strong>
                    <div style={{ fontSize: '11.5px', color: '#64748B' }}>{log.mandiName}</div>
                  </td>
                  <td>
                    {log.items.map((i, idx) => (
                      <div key={idx} style={{ fontSize: '12.5px' }}>
                        {i.name} — <strong>{i.qty}</strong> @ ₹{i.rate}/unit
                      </div>
                    ))}
                  </td>
                  <td>
                    <span style={{ fontSize: '11.5px', background: '#EBF2EE', color: '#234B3C', fontWeight: 700, padding: '3px 8px', borderRadius: '4px' }}>
                      {log.destinationName}
                    </span>
                  </td>
                  <td>
                    <strong style={{ fontFamily: 'monospace', color: '#0F172A' }}>
                      {log.billNumber}
                    </strong>
                    <div style={{ fontSize: '11px', color: '#059669', fontWeight: 700 }}>
                      ✓ Receipt Attached
                    </div>
                  </td>
                  <td>{log.paymentMode?.replace(/_/g, ' ')}</td>
                  <td>
                    <strong style={{ color: '#234B3C', fontSize: '15px' }}>
                      ₹{log.totalAmountPaid?.toLocaleString()}
                    </strong>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
