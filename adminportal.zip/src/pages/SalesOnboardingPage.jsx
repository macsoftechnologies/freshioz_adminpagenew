import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { 
  Building2, 
  MapPin, 
  Store, 
  CreditCard, 
  Users, 
  CheckCircle2, 
  Send,
  Layers,
  Sparkles
} from 'lucide-react';
import { useAdminRole } from '../context/AdminRoleContext';
import { useToast } from '../context/ToastContext';
import { saveFreshiozStore } from '../shared/freshiozStore';
import AdminLeafletStorePicker from '../components/common/AdminLeafletStorePicker';

export default function SalesOnboardingPage() {
  const { store, currentUser } = useAdminRole();
  const { showToast } = useToast();
  const [searchParams] = useSearchParams();
  const leadId = searchParams.get('leadId');

  const leadReq = leadId ? (store.societyRequests || []).find(r => r.id === leadId) : null;

  const [formData, setFormData] = useState({
    name: 'Prestige Falcon City',
    type: 'APARTMENT', // 'APARTMENT' | 'HOSTEL'
    address: 'Kanakapura Road, Anjanaprabha, Bengaluru',
    lat: 12.8910,
    lng: 77.5580,
    nearestShopId: 'shop-1',
    nearestShopName: 'Indiranagar Fresh Hub (Shop 1)',
    secretaryName: 'Suresh Menon (Secretary)',
    secretaryPhone: '9845088771',
    totalFloors: 24,
    totalUnits: 480,
    totalLiving: 1800,
    bankName: 'Axis Bank',
    accountHolder: 'Prestige Falcon City Apartment Welfare Association',
    accountNumber: '91802004819201',
    ifscCode: 'UTIB0000841',
    branch: 'Kanakapura Branch'
  });

  useEffect(() => {
    if (leadReq) {
      setFormData(prev => ({
        ...prev,
        name: leadReq.societyName || prev.name,
        address: leadReq.address || prev.address,
        lat: leadReq.lat || prev.lat,
        lng: leadReq.lng || prev.lng,
        totalUnits: leadReq.estimatedFlats || prev.totalUnits,
        secretaryName: leadReq.requesterName || prev.secretaryName,
        secretaryPhone: leadReq.requesterPhone || prev.secretaryPhone,
        accountHolder: `${leadReq.societyName} Resident Association`
      }));
    }
  }, [leadId, leadReq]);

  const [submittedSuccess, setSubmittedSuccess] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.address || !formData.secretaryPhone || !formData.accountNumber) {
      showToast('Please fill in all required society and bank fields.', 'error');
      return;
    }

    const newSocietyRecord = {
      id: `soc-${Date.now().toString().slice(-4)}`,
      name: formData.name,
      type: formData.type,
      address: formData.address,
      lat: Number(formData.lat) || 12.8910,
      lng: Number(formData.lng) || 77.5580,
      nearestShopId: formData.nearestShopId,
      secretaryName: formData.secretaryName,
      secretaryPhone: formData.secretaryPhone,
      totalFloors: Number(formData.totalFloors),
      totalUnits: Number(formData.totalUnits),
      unitPlaceholder: formData.type === 'HOSTEL' ? 'e.g. Room 204' : 'e.g. Tower 3 - Flat 502',
      deliveryMode: 'SOCIETY_DESK',
      status: 'PENDING', // Awaiting Admin Approval!
      createdById: currentUser?.id || 'emp-103',
      salesRepName: currentUser?.name || 'Field Sales Rep',
      salesRepPhone: currentUser?.phone || '9845011000',
      convertedLeadId: leadId || null,
      balanceEarned: 0,
      totalOrdersDelivered: 0,
      bankDetails: {
        bankName: formData.bankName,
        accountHolder: formData.accountHolder,
        accountNumber: formData.accountNumber,
        ifscCode: formData.ifscCode,
        branch: formData.branch
      }
    };

    saveFreshiozStore(prev => ({
      ...prev,
      societies: [newSocietyRecord, ...prev.societies],
      societyRequests: leadId ? (prev.societyRequests || []).map(r => r.id === leadId ? {
        ...r,
        status: 'CONVERTED',
        convertedSocietyId: newSocietyRecord.id,
        convertedAt: new Date().toISOString()
      } : r) : (prev.societyRequests || [])
    }));

    showToast('Society onboarded! Awaiting Admin approval at /society-approvals.', 'success');
    setSubmittedSuccess(true);
  };

  return (
    <div className="admin-page-container" style={{ maxWidth: '880px' }}>
      <div className="page-title-header" style={{ marginBottom: '14px' }}>
        <div>
          <h1 style={{ fontSize: '18px', fontWeight: 800, color: '#0F172A', margin: 0 }}>
            Field Sales: Onboard Society / Hostel
          </h1>
          <p style={{ fontSize: '12px', color: '#64748B', margin: '2px 0 0' }}>
            Building demographics, GPS pin, store mapping & settlement bank setup
          </p>
        </div>
      </div>

      {submittedSuccess ? (
        <div style={{
          background: '#FFFFFF',
          borderRadius: '16px',
          border: '1.5px solid #059669',
          padding: '36px 24px',
          textAlign: 'center',
          boxShadow: '0 4px 16px rgba(5, 150, 105, 0.1)'
        }}>
          <div style={{
            width: '64px',
            height: '64px',
            borderRadius: '50%',
            background: '#ECFDF5',
            color: '#059669',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 16px'
          }}>
            <CheckCircle2 size={36} />
          </div>

          <h2 style={{ fontSize: '22px', color: '#065F46', marginBottom: '8px' }}>
            Society Onboarding Submitted Successfully!
          </h2>

          <p style={{ fontSize: '14px', color: '#475569', maxWidth: '540px', margin: '0 auto 20px', lineHeight: '1.6' }}>
            <strong>"{formData.name}"</strong> has been saved with status <span style={{ background: '#FEF3C7', color: '#B45309', fontWeight: 800, padding: '2px 8px', borderRadius: '4px' }}>PENDING ADMIN APPROVAL</span>.
            The Admin verification desk has been notified to review location, bank details, and assign the society commission.
          </p>

          <button
            type="button"
            onClick={() => setSubmittedSuccess(false)}
            className="admin-btn-primary"
            style={{ margin: '0 auto' }}
          >
            + Onboard Another Society / Hostel
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="admin-form-card">
          {leadReq && (
            <div style={{
              background: '#F0FDF4',
              border: '1.5px solid #86EFAC',
              borderRadius: '10px',
              padding: '12px 16px',
              marginBottom: '18px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: '12px'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Sparkles size={18} color="#16A34A" />
                <div>
                  <strong style={{ fontSize: '13px', color: '#166534' }}>
                    Converting Inbound Field Request #{leadReq.id}
                  </strong>
                  <div style={{ fontSize: '11.5px', color: '#15803D' }}>
                    Requested by <strong>{leadReq.requesterName}</strong> (+91 {leadReq.requesterPhone}) • Auto-filled address & GPS pin
                  </div>
                </div>
              </div>
              <span style={{ fontSize: '11px', background: '#DCFCE7', color: '#166534', padding: '2px 8px', borderRadius: '4px', fontWeight: 800 }}>
                LEAD CONVERSION
              </span>
            </div>
          )}

          {/* Section 1: Basic Identity */}
          <div style={{ borderBottom: '1px solid #E2E8F0', paddingBottom: '18px', marginBottom: '18px' }}>
            <h3 style={{ fontSize: '16px', color: '#234B3C', display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '14px' }}>
              <Building2 size={18} />
              <span>1. Society & Community Identity</span>
            </h3>

            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '14px', marginBottom: '14px' }}>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Apartment or Hostel Name *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Prestige Lavender Towers / Stanza Living"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  style={{ width: '100%', height: '42px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px' }}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Category *
                </label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  style={{ width: '100%', height: '42px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px', fontWeight: 700 }}
                >
                  <option value="APARTMENT">Apartment / Gated Society</option>
                  <option value="HOSTEL">Hostel / PG Co-Living</option>
                </select>
              </div>
            </div>

            <div>
              <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                Full Street Address & Landmark *
              </label>
              <input
                type="text"
                placeholder="Door / Plot, Street name, Area, City"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                style={{ width: '100%', height: '42px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px' }}
                required
              />
            </div>
          </div>

          {/* Section 2: OpenStreetMap & Nearest Store Auto-Calculation (As Requested) */}
          <div style={{ borderBottom: '1px solid #E2E8F0', paddingBottom: '18px', marginBottom: '18px' }}>
            <h3 style={{ fontSize: '16px', color: '#234B3C', display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '14px' }}>
              <MapPin size={18} />
              <span>2. Geolocation & Nearest Store Auto-Assignment</span>
            </h3>

            <AdminLeafletStorePicker
              shops={store.shops}
              initialLat={formData.lat}
              initialLng={formData.lng}
              onLocationAndStoreSelect={(result) => {
                setFormData(prev => ({
                  ...prev,
                  lat: result.lat,
                  lng: result.lng,
                  nearestShopId: result.nearestShopId,
                  nearestShopName: result.nearestShopName
                }));
              }}
            />
          </div>

          {/* Section 3: Contact & Scale */}
          <div style={{ borderBottom: '1px solid #E2E8F0', paddingBottom: '18px', marginBottom: '18px' }}>
            <h3 style={{ fontSize: '16px', color: '#234B3C', display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '14px' }}>
              <Users size={18} />
              <span>3. Management Contact & Building Scale</span>
            </h3>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '14px' }}>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Head / President / Warden Name *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Suresh Menon"
                  value={formData.secretaryName}
                  onChange={(e) => setFormData({ ...formData, secretaryName: e.target.value })}
                  style={{ width: '100%', height: '42px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px' }}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Contact Mobile Number *
                </label>
                <input
                  type="tel"
                  placeholder="10-digit mobile"
                  value={formData.secretaryPhone}
                  onChange={(e) => setFormData({ ...formData, secretaryPhone: e.target.value })}
                  style={{ width: '100%', height: '42px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px' }}
                  required
                />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '14px' }}>
              <div>
                <label style={{ fontSize: '12px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Total Floors
                </label>
                <input
                  type="number"
                  placeholder="e.g. 14"
                  value={formData.totalFloors}
                  onChange={(e) => setFormData({ ...formData, totalFloors: e.target.value })}
                  style={{ width: '100%', height: '40px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13px' }}
                />
              </div>

              <div>
                <label style={{ fontSize: '12px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Number of Flats / Rooms
                </label>
                <input
                  type="number"
                  placeholder="e.g. 280"
                  value={formData.totalUnits}
                  onChange={(e) => setFormData({ ...formData, totalUnits: e.target.value })}
                  style={{ width: '100%', height: '40px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13px' }}
                />
              </div>

              <div>
                <label style={{ fontSize: '12px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Approx Residents / Living
                </label>
                <input
                  type="number"
                  placeholder="e.g. 850"
                  value={formData.totalLiving}
                  onChange={(e) => setFormData({ ...formData, totalLiving: e.target.value })}
                  style={{ width: '100%', height: '40px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13px' }}
                />
              </div>
            </div>
          </div>

          {/* Section 4: Bank Details (As Requested by User) */}
          <div style={{ marginBottom: '24px' }}>
            <h3 style={{ fontSize: '16px', color: '#234B3C', display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '14px' }}>
              <CreditCard size={18} />
              <span>4. Society Settlement Bank Details (For Commission Payouts)</span>
            </h3>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '14px' }}>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Bank Name *
                </label>
                <input
                  type="text"
                  placeholder="e.g. HDFC Bank / SBI / ICICI"
                  value={formData.bankName}
                  onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                  style={{ width: '100%', height: '42px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px' }}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Account Holder Name *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Society Association Welfare Fund"
                  value={formData.accountHolder}
                  onChange={(e) => setFormData({ ...formData, accountHolder: e.target.value })}
                  style={{ width: '100%', height: '42px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px' }}
                  required
                />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  Bank Account Number *
                </label>
                <input
                  type="text"
                  placeholder="Account number"
                  value={formData.accountNumber}
                  onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                  style={{ width: '100%', height: '42px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px', fontFamily: 'monospace' }}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: '12.5px', fontWeight: 700, display: 'block', marginBottom: '4px' }}>
                  IFSC Code *
                </label>
                <input
                  type="text"
                  placeholder="e.g. HDFC0001742"
                  value={formData.ifscCode}
                  onChange={(e) => setFormData({ ...formData, ifscCode: e.target.value.toUpperCase() })}
                  style={{ width: '100%', height: '42px', padding: '0 12px', borderRadius: '8px', border: '1.5px solid #CBD5E1', fontSize: '13.5px', fontFamily: 'monospace' }}
                  required
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="admin-btn-primary"
            style={{ width: '100%', padding: '14px', fontSize: '15px', justifyContent: 'center' }}
          >
            <Send size={18} />
            <span>Submit Society for Admin Review & Commission Setup</span>
          </button>
        </form>
      )}
    </div>
  );
}
