import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { MapPin, Navigation, Store, CheckCircle2 } from 'lucide-react';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// Haversine formula to compute distance in kilometers between two lat/lng points
function calculateDistanceKm(lat1, lon1, lat2, lon2) {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Number((R * c).toFixed(2));
}

export default function AdminLeafletStorePicker({
  shops = [],
  initialLat = 12.9716,
  initialLng = 77.5946,
  onLocationAndStoreSelect
}) {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const societyMarkerRef = useRef(null);

  const [coords, setCoords] = useState({ lat: initialLat, lng: initialLng });
  const [selectedShopId, setSelectedShopId] = useState(shops[0]?.id || 'shop-1');
  const [shopDistances, setShopDistances] = useState([]);
  const [isLocating, setIsLocating] = useState(false);

  // Compute distances to all shops and determine nearest
  const updateNearestShop = (lat, lng) => {
    if (!shops.length) return;
    const computed = shops.map(shop => {
      const dist = calculateDistanceKm(lat, lng, shop.lat, shop.lng);
      return { ...shop, distanceKm: dist };
    }).sort((a, b) => a.distanceKm - b.distanceKm);

    setShopDistances(computed);
    const nearest = computed[0];
    setSelectedShopId(nearest.id);

    if (onLocationAndStoreSelect) {
      onLocationAndStoreSelect({
        lat,
        lng,
        nearestShopId: nearest.id,
        nearestShopName: nearest.name,
        distanceKm: nearest.distanceKm
      });
    }
  };

  useEffect(() => {
    if (!mapContainerRef.current) return;

    const map = L.map(mapContainerRef.current).setView([initialLat, initialLng], 12);
    mapInstanceRef.current = map;

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
      maxZoom: 18,
    }).addTo(map);

    // Plot all existing Hub Shops with Store Icons
    shops.forEach(shop => {
      const shopIcon = L.divIcon({
        className: 'hub-shop-pin',
        html: `<div style="
          background: #234B3C;
          color: #FFF;
          padding: 3px 8px;
          border-radius: 6px;
          font-size: 11px;
          font-weight: 800;
          border: 2px solid #FFF;
          box-shadow: 0 2px 8px rgba(0,0,0,0.3);
          white-space: nowrap;
          display: flex;
          align-items: center;
          gap: 4px;
        ">🏪 ${shop.name.split(' (')[0]}</div>`,
        iconSize: [120, 28],
        iconAnchor: [60, 28]
      });

      L.marker([shop.lat, shop.lng], { icon: shopIcon }).addTo(map)
        .bindPopup(`<strong>${shop.name}</strong><br/>${shop.address}`);
    });

    // Plot Draggable Marker for the New Society Location
    const societyIcon = L.divIcon({
      className: 'new-society-pin',
      html: `<div style="
        background: #F28E14;
        color: #FFF;
        width: 38px;
        height: 38px;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        display: flex;
        align-items: center;
        justify-content: center;
        border: 3px solid #FFF;
        box-shadow: 0 4px 12px rgba(0,0,0,0.35);
      ">
        <div style="transform: rotate(45deg); font-weight: 800; font-size: 16px;">🏢</div>
      </div>`,
      iconSize: [38, 38],
      iconAnchor: [19, 38]
    });

    const marker = L.marker([initialLat, initialLng], {
      icon: societyIcon,
      draggable: true
    }).addTo(map);
    societyMarkerRef.current = marker;

    marker.on('dragend', () => {
      const pos = marker.getLatLng();
      const newLat = Number(pos.lat.toFixed(5));
      const newLng = Number(pos.lng.toFixed(5));
      setCoords({ lat: newLat, lng: newLng });
      updateNearestShop(newLat, newLng);
    });

    map.on('click', (e) => {
      const { lat, lng } = e.latlng;
      const newLat = Number(lat.toFixed(5));
      const newLng = Number(lng.toFixed(5));
      marker.setLatLng([newLat, newLng]);
      setCoords({ lat: newLat, lng: newLng });
      updateNearestShop(newLat, newLng);
    });

    updateNearestShop(initialLat, initialLng);

    return () => {
      map.remove();
    };
  }, []);

  const handleAutoGPS = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser');
      return;
    }
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        const newLat = Number(latitude.toFixed(5));
        const newLng = Number(longitude.toFixed(5));
        setCoords({ lat: newLat, lng: newLng });
        setIsLocating(false);

        if (mapInstanceRef.current && societyMarkerRef.current) {
          mapInstanceRef.current.setView([newLat, newLng], 14);
          societyMarkerRef.current.setLatLng([newLat, newLng]);
        }
        updateNearestShop(newLat, newLng);
      },
      (err) => {
        setIsLocating(false);
        console.warn('GPS detection error', err);
        alert('Could not detect GPS. Please click or drag the pin on OpenStreetMap.');
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const handleManualShopChange = (e) => {
    const shopId = e.target.value;
    setSelectedShopId(shopId);
    const shop = shops.find(s => s.id === shopId);
    if (onLocationAndStoreSelect) {
      onLocationAndStoreSelect({
        lat: coords.lat,
        lng: coords.lng,
        nearestShopId: shopId,
        nearestShopName: shop?.name,
        distanceKm: shopDistances.find(d => d.id === shopId)?.distanceKm || 0
      });
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
      {/* Map Action Top Bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '8px' }}>
        <div style={{ fontSize: '13px', fontWeight: 700, color: '#234B3C', display: 'flex', alignItems: 'center', gap: '6px' }}>
          <MapPin size={16} color="#F28E14" />
          <span>Pin Society Coordinates (OpenStreetMap)</span>
        </div>

        <button
          type="button"
          onClick={handleAutoGPS}
          disabled={isLocating}
          style={{
            background: '#EBF2EE',
            color: '#234B3C',
            border: '1px solid #C4D9CD',
            padding: '6px 14px',
            borderRadius: '9999px',
            fontSize: '12px',
            fontWeight: 700,
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            cursor: 'pointer'
          }}
        >
          <Navigation size={13} />
          {isLocating ? 'Detecting GPS...' : 'Auto-Detect Field GPS'}
        </button>
      </div>

      {/* Leaflet Map Canvas */}
      <div
        ref={mapContainerRef}
        style={{
          width: '100%',
          height: '240px',
          borderRadius: '12px',
          border: '1.5px solid #CBD5E1',
          zIndex: 1,
          overflow: 'hidden'
        }}
      />

      {/* Nearest Store Field & Dropdown with Auto Detection */}
      <div style={{
        background: '#FAFBFB',
        border: '1.5px solid #E2E8F0',
        borderRadius: '12px',
        padding: '14px',
        display: 'flex',
        flexDirection: 'column',
        gap: '8px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <label style={{ fontSize: '13px', fontWeight: 800, color: '#0F172A', display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Store size={16} color="#234B3C" />
            <span>Assigned Nearest Hub Store (Auto-calculated):</span>
          </label>
          <span style={{ fontSize: '11px', background: '#ECFDF5', color: '#059669', fontWeight: 800, padding: '2px 8px', borderRadius: '4px' }}>
            ✓ Haversine Proximity
          </span>
        </div>

        <select
          value={selectedShopId}
          onChange={handleManualShopChange}
          style={{
            width: '100%',
            height: '42px',
            padding: '0 12px',
            borderRadius: '8px',
            border: '1.5px solid #CBD5E1',
            background: '#FFF',
            fontSize: '13.5px',
            fontWeight: 700,
            color: '#0F172A',
            outline: 'none',
            cursor: 'pointer'
          }}
        >
          {shopDistances.map((shop, idx) => (
            <option key={shop.id} value={shop.id}>
              {shop.name} — {shop.distanceKm} km away {idx === 0 ? '(Closest Hub)' : ''}
            </option>
          ))}
        </select>

        <div style={{ fontSize: '11.5px', color: '#64748B', display: 'flex', justifyContent: 'space-between' }}>
          <span>Auto-assigned based on street distance; can be manually overridden.</span>
          <span style={{ fontFamily: 'monospace' }}>Lat: {coords.lat}, Lng: {coords.lng}</span>
        </div>
      </div>
    </div>
  );
}
