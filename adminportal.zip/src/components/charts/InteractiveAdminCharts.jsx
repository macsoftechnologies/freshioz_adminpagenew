import React, { useState } from 'react';
import { TrendingUp, DollarSign, BarChart3, PieChart, Layers, CheckCircle2 } from 'lucide-react';

export function RevenueMarginChart() {
  const [hoverIndex, setHoverIndex] = useState(null);

  const data = [
    { day: 'Mon', sales: 42500, procurement: 29800, margin: '29.8%' },
    { day: 'Tue', sales: 48200, procurement: 33100, margin: '31.3%' },
    { day: 'Wed', sales: 45900, procurement: 31200, margin: '32.0%' },
    { day: 'Thu', sales: 53100, procurement: 36400, margin: '31.4%' },
    { day: 'Fri', sales: 61400, procurement: 41900, margin: '31.7%' },
    { day: 'Sat', sales: 74200, procurement: 50100, margin: '32.4%' },
    { day: 'Sun', sales: 82500, procurement: 55800, margin: '32.3%' }
  ];

  const maxVal = 90000;
  const chartHeight = 180;
  const chartWidth = 500;

  return (
    <div style={{
      background: '#FFFFFF',
      border: '1px solid #E2E8F0',
      borderRadius: '16px',
      padding: '22px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.03)'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px', flexWrap: 'wrap', gap: '8px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <TrendingUp size={18} color="#234B3C" />
            <h3 style={{ fontSize: '16px', color: '#0F172A', margin: 0, fontWeight: 800 }}>Daily Sales vs. Mandi Spend</h3>
          </div>
          <p style={{ fontSize: '12px', color: '#64748B', marginTop: '2px' }}>
            Next-day batched retail & wholesale margins over the last 7 days
          </p>
        </div>

        <div style={{ display: 'flex', gap: '14px', fontSize: '12px', fontWeight: 700 }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#234B3C' }}>
            <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#234B3C' }} /> Gross Sales (₹)
          </span>
          <span style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#F28E14' }}>
            <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#F28E14' }} /> Mandi Spend (₹)
          </span>
        </div>
      </div>

      {/* SVG Canvas Chart */}
      <div style={{ position: 'relative', width: '100%', overflowX: 'auto' }}>
        <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} style={{ width: '100%', height: '200px' }}>
          {/* Grid lines */}
          <line x1="40" y1="20" x2={chartWidth - 20} y2="20" stroke="#F1F5F9" strokeWidth="1" />
          <line x1="40" y1="70" x2={chartWidth - 20} y2="70" stroke="#F1F5F9" strokeWidth="1" />
          <line x1="40" y1="120" x2={chartWidth - 20} y2="120" stroke="#F1F5F9" strokeWidth="1" />
          <line x1="40" y1={chartHeight - 30} x2={chartWidth - 20} y2={chartHeight - 30} stroke="#E2E8F0" strokeWidth="1.5" />

          {/* Area fill for Sales */}
          <polygon
            points={`
              ${data.map((d, i) => `${60 + i * 65},${(chartHeight - 30) - (d.sales / maxVal) * (chartHeight - 50)}`).join(' ')}
              ${60 + (data.length - 1) * 65},${chartHeight - 30}
              60,${chartHeight - 30}
            `}
            fill="rgba(35, 75, 60, 0.1)"
          />

          {/* Sales Line */}
          <polyline
            fill="none"
            stroke="#234B3C"
            strokeWidth="3"
            points={data.map((d, i) => `${60 + i * 65},${(chartHeight - 30) - (d.sales / maxVal) * (chartHeight - 50)}`).join(' ')}
          />

          {/* Procurement Spend Line */}
          <polyline
            fill="none"
            stroke="#F28E14"
            strokeWidth="2.5"
            strokeDasharray="4 3"
            points={data.map((d, i) => `${60 + i * 65},${(chartHeight - 30) - (d.procurement / maxVal) * (chartHeight - 50)}`).join(' ')}
          />

          {/* Data Points */}
          {data.map((d, i) => {
            const cx = 60 + i * 65;
            const cySales = (chartHeight - 30) - (d.sales / maxVal) * (chartHeight - 50);
            const cyProc = (chartHeight - 30) - (d.procurement / maxVal) * (chartHeight - 50);

            return (
              <g key={i} onMouseEnter={() => setHoverIndex(i)} onMouseLeave={() => setHoverIndex(null)} style={{ cursor: 'pointer' }}>
                <circle cx={cx} cy={cySales} r={hoverIndex === i ? 6 : 4} fill="#234B3C" stroke="#FFF" strokeWidth="2" />
                <circle cx={cx} cy={cyProc} r={hoverIndex === i ? 5 : 3.5} fill="#F28E14" stroke="#FFF" strokeWidth="1.5" />
                <text x={cx} y={chartHeight - 12} textAnchor="middle" fontSize="11" fill="#64748B" fontWeight="600">
                  {d.day}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Hover Tooltip */}
        {hoverIndex !== null && (
          <div style={{
            position: 'absolute',
            top: '10px',
            left: `${60 + hoverIndex * 65}px`,
            transform: 'translateX(-50%)',
            background: '#0F172A',
            color: '#FFFFFF',
            borderRadius: '8px',
            padding: '8px 12px',
            fontSize: '11.5px',
            boxShadow: '0 4px 12px rgba(0,0,0,0.2)',
            pointerEvents: 'none',
            zIndex: 10
          }}>
            <div style={{ fontWeight: 800, color: '#C3E6B4' }}>{data[hoverIndex].day}: Margin {data[hoverIndex].margin}</div>
            <div>Sales: ₹{data[hoverIndex].sales.toLocaleString()}</div>
            <div>Mandi: ₹{data[hoverIndex].procurement.toLocaleString()}</div>
          </div>
        )}
      </div>
    </div>
  );
}

export function CategoryRevenueDonutChart() {
  const [activeCategory, setActiveCategory] = useState(null);

  const categories = [
    { name: 'Daily Vegetables', pct: 38, amount: '₹1,62,640', color: '#059669', icon: '🍅' },
    { name: 'Orchard Fruits', pct: 32, amount: '₹1,36,960', color: '#D97706', icon: '🍎' },
    { name: 'Leafy Greens', pct: 18, amount: '₹77,040', color: '#234B3C', icon: '🥬' },
    { name: 'Exotic & Salads', pct: 12, amount: '₹51,360', color: '#7C3AED', icon: '🥦' }
  ];

  return (
    <div style={{
      background: '#FFFFFF',
      border: '1px solid #E2E8F0',
      borderRadius: '16px',
      padding: '22px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.03)'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <PieChart size={18} color="#234B3C" />
            <h3 style={{ fontSize: '16px', color: '#0F172A', margin: 0, fontWeight: 800 }}>Category Revenue Split</h3>
          </div>
          <p style={{ fontSize: '12px', color: '#64748B', marginTop: '2px' }}>
            Share of order value across farm produce categories
          </p>
        </div>
        <div style={{ fontSize: '12px', color: '#059669', fontWeight: 800 }}>
          ₹4,28,000 GMV
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', alignItems: 'center' }}>
        {/* Visual Progress Bar Stack */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <div style={{ height: '14px', width: '100%', borderRadius: '9999px', overflow: 'hidden', display: 'flex' }}>
            {categories.map((c, i) => (
              <div 
                key={i} 
                style={{ 
                  width: `${c.pct}%`, 
                  height: '100%', 
                  background: c.color, 
                  transition: 'opacity 0.2s',
                  opacity: activeCategory === null || activeCategory === i ? 1 : 0.4
                }} 
              />
            ))}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {categories.map((cat, i) => (
              <div 
                key={i} 
                onMouseEnter={() => setActiveCategory(i)}
                onMouseLeave={() => setActiveCategory(null)}
                style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'space-between',
                  padding: '6px 8px',
                  borderRadius: '6px',
                  background: activeCategory === i ? '#F8FAFC' : 'transparent',
                  cursor: 'pointer'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12.5px' }}>
                  <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: cat.color }} />
                  <span style={{ fontWeight: 600, color: '#1E293B' }}>{cat.icon} {cat.name}</span>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <span style={{ fontSize: '12.5px', fontWeight: 800, color: '#0F172A' }}>{cat.pct}%</span>
                  <span style={{ fontSize: '11px', color: '#64748B', marginLeft: '6px' }}>({cat.amount})</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Highlight Focus Card */}
        <div style={{
          background: '#F0F9FF',
          border: '1px solid #BAE6FD',
          borderRadius: '12px',
          padding: '16px',
          textAlign: 'center'
        }}>
          <div style={{ fontSize: '11px', color: '#0369A1', fontWeight: 800, textTransform: 'uppercase' }}>
            Top Revenue Producer
          </div>
          <div style={{ fontSize: '28px', margin: '6px 0' }}>🍅</div>
          <div style={{ fontSize: '15px', fontWeight: 800, color: '#0C4A6E' }}>
            Daily Farm Vegetables
          </div>
          <div style={{ fontSize: '20px', fontWeight: 800, color: '#0284C7', marginTop: '2px' }}>
            38% of Total Sales
          </div>
          <div style={{ fontSize: '11.5px', color: '#64748B', marginTop: '4px' }}>
            Direct APMC Kolar tomatoes, onions & capsicum leading demand.
          </div>
        </div>
      </div>
    </div>
  );
}

export function ShopVolumeChart() {
  const shopData = [
    { name: 'Shop 1 (Indiranagar Fresh Hub)', count: 412, capacity: '82%', color: '#234B3C' },
    { name: 'Shop 2 (Whitefield Agro Express)', count: 320, capacity: '64%', color: '#059669' },
    { name: 'Shop 3 (Koramangala Fresh Point)', count: 285, capacity: '57%', color: '#F28E14' },
    { name: 'Shop 4 (HSR Sector 2 Hub Point)', count: 240, capacity: '48%', color: '#2563EB' }
  ];

  const maxOrders = 500;

  return (
    <div style={{
      background: '#FFFFFF',
      border: '1px solid #E2E8F0',
      borderRadius: '16px',
      padding: '22px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.03)'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <BarChart3 size={18} color="#234B3C" />
          <h3 style={{ fontSize: '16px', color: '#0F172A', margin: 0, fontWeight: 800 }}>Hub Shop Fulfillment Volume</h3>
        </div>
        <div style={{ fontSize: '12px', color: '#64748B' }}>
          Max Cap: 500 orders/shop
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
        {shopData.map((shop, i) => (
          <div key={i}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12.5px', fontWeight: 700, marginBottom: '5px' }}>
              <span style={{ color: '#1E293B' }}>{shop.name}</span>
              <span style={{ color: shop.color }}>{shop.count} Orders ({shop.capacity})</span>
            </div>

            <div style={{ width: '100%', height: '10px', background: '#F1F5F9', borderRadius: '9999px', overflow: 'hidden' }}>
              <div style={{
                width: `${(shop.count / maxOrders) * 100}%`,
                height: '100%',
                background: shop.color,
                borderRadius: '9999px',
                transition: 'width 0.4s ease'
              }} />
            </div>
          </div>
        ))}
      </div>

      <div style={{ marginTop: '16px', paddingTop: '12px', borderTop: '1px solid #F1F5F9', fontSize: '12px', color: '#64748B', display: 'flex', justifyContent: 'space-between' }}>
        <span>Batched under Central Agri-Hub North & South</span>
        <strong style={{ color: '#234B3C' }}>1,257 Total Orders Locked</strong>
      </div>
    </div>
  );
}
