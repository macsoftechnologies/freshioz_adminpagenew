import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  CheckCircle, 
  Coins, 
  Warehouse, 
  FilePlus, 
  Building2, 
  ClipboardList, 
  Truck 
} from 'lucide-react';
import { useAdminRole } from '../../context/AdminRoleContext';

export default function AdminMobileDock() {
  const { currentRoleId, store } = useAdminRole();
  const location = useLocation();
  const isWarehouseRoute = location.pathname.startsWith('/warehouse');

  const pendingCount = (store.societies || []).filter(s => s.status === 'PENDING').length;

  return (
    <nav className="admin-mobile-dock" aria-label="Admin Mobile Navigation">
      {/* Super Admin Tabs */}
      {currentRoleId === 'SUPER_ADMIN' && (
        <>
          <NavLink to="/dashboard" className={({ isActive }) => `admin-dock-item ${isActive ? 'active' : ''}`}>
            <LayoutDashboard size={18} />
            <span>Dashboard</span>
          </NavLink>
          <NavLink to="/approvals" className={({ isActive }) => `admin-dock-item ${isActive ? 'active' : ''}`}>
            <CheckCircle size={18} />
            <span>Approvals {pendingCount > 0 ? `(${pendingCount})` : ''}</span>
          </NavLink>
          <NavLink to="/payouts" className={({ isActive }) => `admin-dock-item ${isActive ? 'active' : ''}`}>
            <Coins size={18} />
            <span>Payouts</span>
          </NavLink>
          <NavLink to="/warehouse-settings" className={({ isActive }) => `admin-dock-item ${isActive || isWarehouseRoute ? 'active' : ''}`}>
            <Warehouse size={18} />
            <span>Warehouse</span>
          </NavLink>
        </>
      )}

      {/* Field Sales Officer Tabs */}
      {currentRoleId === 'SALES_OFFICER' && (
        <>
          <NavLink to="/sales-onboarding" className={({ isActive }) => `admin-dock-item ${isActive ? 'active' : ''}`}>
            <FilePlus size={18} />
            <span>+ Onboard</span>
          </NavLink>
          <NavLink to="/sales-my-societies" className={({ isActive }) => `admin-dock-item ${isActive ? 'active' : ''}`}>
            <Building2 size={18} />
            <span>My Societies</span>
          </NavLink>
          <NavLink to="/inbound-leads" className={({ isActive }) => `admin-dock-item ${isActive ? 'active' : ''}`}>
            <ClipboardList size={18} />
            <span>Leads</span>
          </NavLink>
        </>
      )}

      {/* Procurement Officer Tabs */}
      {currentRoleId === 'PROCUREMENT_OFFICER' && (
        <>
          <NavLink to="/procurement-demand" className={({ isActive }) => `admin-dock-item ${isActive ? 'active' : ''}`}>
            <ClipboardList size={18} />
            <span>Mandi Demand</span>
          </NavLink>
          <NavLink to="/procurement-entry" className={({ isActive }) => `admin-dock-item ${isActive ? 'active' : ''}`}>
            <FilePlus size={18} />
            <span>Log Purchase</span>
          </NavLink>
          <NavLink to="/procurement-logs" className={({ isActive }) => `admin-dock-item ${isActive ? 'active' : ''}`}>
            <Truck size={18} />
            <span>My Bills</span>
          </NavLink>
        </>
      )}

      {/* Warehouse Manager Tabs */}
      {currentRoleId === 'WAREHOUSE_MANAGER' && (
        <>
          <NavLink to="/warehouse-settings" className={({ isActive }) => `admin-dock-item ${isActive || isWarehouseRoute ? 'active' : ''}`}>
            <Warehouse size={18} />
            <span>Cut-Off Rules</span>
          </NavLink>
          <NavLink to="/warehouse-crating" className={({ isActive }) => `admin-dock-item ${isActive ? 'active' : ''}`}>
            <ClipboardList size={18} />
            <span>Crating Desk</span>
          </NavLink>
        </>
      )}
    </nav>
  );
}
