import React from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut } from 'lucide-react';
import FreshiozLogo from '../common/FreshiozLogo';
import { useAdminRole, ROLES } from '../../context/AdminRoleContext';
import { useToast } from '../../context/ToastContext';

export default function AdminMobileHeader() {
  const navigate = useNavigate();
  const { currentRoleId, setRole, logout } = useAdminRole();
  const { showToast } = useToast();

  const handleLogout = () => {
    logout();
    showToast('Logged out of operations session', 'info');
    navigate('/login', { replace: true });
  };

  return (
    <header className="admin-mobile-header">
      <FreshiozLogo height={30} showTagline={false} />

      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
        <select
          value={currentRoleId}
          onChange={(e) => setRole(e.target.value)}
          style={{
            background: '#F1F5F9',
            border: '1px solid #CBD5E1',
            borderRadius: '9999px',
            padding: '4px 8px',
            fontSize: '11px',
            fontWeight: 800,
            color: '#234B3C',
            outline: 'none',
            maxWidth: '140px'
          }}
        >
          {Object.values(ROLES).map(r => (
            <option key={r.id} value={r.id}>
              {r.label}
            </option>
          ))}
        </select>

        <button
          type="button"
          onClick={handleLogout}
          title="Sign out of operations session"
          style={{
            background: '#FEE2E2',
            border: '1px solid #FECACA',
            color: '#B91C1C',
            width: '32px',
            height: '32px',
            borderRadius: '8px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer'
          }}
        >
          <LogOut size={15} />
        </button>
      </div>
    </header>
  );
}
