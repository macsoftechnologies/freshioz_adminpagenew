import React from 'react';
import { useNavigate } from 'react-router-dom';
import { UserCheck, Clock, LogOut, User } from 'lucide-react';
import FreshiozLogo from '../common/FreshiozLogo';
import { useAdminRole, ROLES } from '../../context/AdminRoleContext';
import { useToast } from '../../context/ToastContext';

export default function AdminTopBar({ onMobileMenuClick }) {
  const navigate = useNavigate();
  const { currentRoleId, setRole, store, currentUser, logout } = useAdminRole();
  const { showToast } = useToast();

  const handleLogout = () => {
    logout();
    showToast('Logged out of operations session', 'info');
    navigate('/login', { replace: true });
  };

  return (
    <header className="admin-topbar">
      <div className="topbar-left" style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
        <FreshiozLogo height={32} showTagline={false} />
        <div style={{ borderLeft: '1.5px solid #CBD5E1', paddingLeft: '12px' }}>
          <div style={{ fontSize: '10px', textTransform: 'uppercase', color: '#64748B', fontWeight: 800, letterSpacing: '0.5px' }}>
            Freshioz Operations Desk
          </div>
          <div style={{ fontSize: '14px', fontWeight: 800, color: '#234B3C', lineHeight: 1.2 }}>
            {ROLES[currentRoleId]?.label} Desk
          </div>
        </div>
      </div>

      <div className="topbar-right" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        {/* Dynamic Role Switcher Pill */}
        <div className="role-switcher-box" title="Switch role to experience Sales, Procurement, Warehouse or Admin desks">
          <UserCheck size={15} color="#234B3C" />
          <span style={{ fontSize: '11px', color: '#64748B', fontWeight: 700 }}>Role:</span>
          <select
            className="role-select-input"
            value={currentRoleId}
            onChange={(e) => setRole(e.target.value)}
          >
            {Object.values(ROLES).map(r => (
              <option key={r.id} value={r.id}>
                {r.label}
              </option>
            ))}
          </select>
        </div>

        {/* Current User Chip */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          background: '#F8FAFC',
          border: '1px solid #E2E8F0',
          borderRadius: '9999px',
          padding: '3px 10px 3px 4px'
        }}>
          <div style={{
            width: '26px',
            height: '26px',
            borderRadius: '50%',
            background: '#234B3C',
            color: '#FFF',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '11px',
            fontWeight: 800
          }}>
            {currentUser?.avatar || 'VR'}
          </div>
          <div style={{ fontSize: '12px', fontWeight: 700, color: '#0F172A', maxWidth: '120px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {currentUser?.name?.split(' ')[0] || 'User'}
          </div>
        </div>

        {/* Logout Button */}
        <button
          type="button"
          onClick={handleLogout}
          title="Sign out of operations session"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '5px',
            padding: '6px 12px',
            borderRadius: '8px',
            background: '#FEE2E2',
            color: '#B91C1C',
            fontSize: '12px',
            fontWeight: 700,
            border: '1px solid #FECACA',
            cursor: 'pointer',
            transition: 'background 0.2s'
          }}
        >
          <LogOut size={13} />
          <span>Logout</span>
        </button>
      </div>
    </header>
  );
}
