import React from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import AdminSidebar from './components/layout/AdminSidebar';
import AdminTopBar from './components/layout/AdminTopBar';
import AdminMobileHeader from './components/layout/AdminMobileHeader';
import AdminMobileDock from './components/layout/AdminMobileDock';

import AdminLoginPage from './pages/AdminLoginPage';
import AdminForgotPasswordPage from './pages/AdminForgotPasswordPage';
import AdminDashboardPage from './pages/AdminDashboardPage';
import EmployeeManagementPage from './pages/EmployeeManagementPage';
import MasterDataPage from './pages/MasterDataPage';
import WarehouseShopsPage from './pages/WarehouseShopsPage';
import OrdersFulfillmentPage from './pages/OrdersFulfillmentPage';
import SocietyApprovalsPage from './pages/SocietyApprovalsPage';
import DailyPricingPage from './pages/DailyPricingPage';
import SocietyPayoutsPage from './pages/SocietyPayoutsPage';
import SalesOnboardingPage from './pages/SalesOnboardingPage';
import SalesMySocietiesPage from './pages/SalesMySocietiesPage';
import ProcurementDemandPage from './pages/ProcurementDemandPage';
import ProcurementEntryPage from './pages/ProcurementEntryPage';
import ProcurementLogsPage from './pages/ProcurementLogsPage';
import InboundLeadsPage from './pages/InboundLeadsPage';
import WarehouseCratingPage from './pages/WarehouseCratingPage';
import WarehouseStoresPage from './pages/WarehouseStoresPage';
import StoreDetailsPage from './pages/StoreDetailsPage';
import ScrollToTop from './components/common/ScrollToTop';
import { useAdminRole } from './context/AdminRoleContext';

export default function App() {
  const { currentRoleId, isAuthenticated } = useAdminRole();
  const location = useLocation();

  // Determine home fallback route per role
  const getHomeRoute = () => {
    switch (currentRoleId) {
      case 'SALES_OFFICER': return '/sales-onboarding';
      case 'PROCUREMENT_OFFICER': return '/procurement-demand';
      case 'WAREHOUSE_MANAGER': return '/warehouse-settings';
      default: return '/dashboard';
    }
  };

  const isAuthRoute = location.pathname === '/login' || location.pathname === '/forgot-password';

  // Render standalone login & password recovery screens when unauthenticated
  if (isAuthRoute) {
    if (isAuthenticated) {
      return <Navigate to={getHomeRoute()} replace />;
    }
    return (
      <Routes>
        <Route path="/login" element={<AdminLoginPage />} />
        <Route path="/forgot-password" element={<AdminForgotPasswordPage />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    );
  }

  // Guard all operational desks if session is not authenticated
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="admin-layout-wrapper">
      {/* Smooth Scroll to Top on Page Navigation & Floating Top Button */}
      <ScrollToTop />

      {/* Desktop Left Sidebar */}
      <AdminSidebar />

      {/* Main Operations Workdesk */}
      <div className="admin-main-panel">
        {/* Mobile Top Header */}
        <AdminMobileHeader />

        {/* Desktop Topbar with User Chip, Role Switcher & Logout */}
        <AdminTopBar />

        {/* Page Routes */}
        <Routes>
          <Route path="/dashboard" element={<AdminDashboardPage />} />
          <Route path="/employees" element={<EmployeeManagementPage />} />
          <Route path="/master-data" element={<MasterDataPage />} />
          <Route path="/warehouse-settings" element={<WarehouseShopsPage />} />
          <Route path="/warehouse/:warehouseId/stores" element={<WarehouseStoresPage />} />
          <Route path="/warehouse/:warehouseId/store/:storeId" element={<StoreDetailsPage />} />
          <Route path="/orders-fulfillment" element={<OrdersFulfillmentPage />} />
          <Route path="/approvals" element={<SocietyApprovalsPage />} />
          <Route path="/daily-pricing" element={<DailyPricingPage />} />
          <Route path="/payouts" element={<SocietyPayoutsPage />} />
          <Route path="/sales-onboarding" element={<SalesOnboardingPage />} />
          <Route path="/sales-my-societies" element={<SalesMySocietiesPage />} />
          <Route path="/procurement-demand" element={<ProcurementDemandPage />} />
          <Route path="/procurement-entry" element={<ProcurementEntryPage />} />
          <Route path="/procurement-logs" element={<ProcurementLogsPage />} />
          <Route path="/inbound-leads" element={<InboundLeadsPage />} />
          <Route path="/warehouse-crating" element={<WarehouseCratingPage />} />
          
          <Route path="/login" element={<Navigate to={getHomeRoute()} replace />} />
          <Route path="/forgot-password" element={<Navigate to={getHomeRoute()} replace />} />
          <Route path="/" element={<Navigate to={getHomeRoute()} replace />} />
          <Route path="*" element={<Navigate to={getHomeRoute()} replace />} />
        </Routes>

        {/* Mobile Bottom Navigation Dock */}
        <AdminMobileDock />
      </div>
    </div>
  );
}
